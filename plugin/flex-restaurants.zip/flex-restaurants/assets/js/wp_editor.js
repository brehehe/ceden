/**
 * Created by Manhn on 31/5/2017.
 */
(function () {
    tinymce.create('tinymce.plugins.flexrestaurants', {
        init: function (ed, url) {
            var fs_code = [];
            for (var index in fs_restaurant_codes) {
                fs_code.push(handle_shortcode(index,fs_restaurant_codes[index]));
            }
            function handle_shortcode(index,shortcode) {
                var temp;
                if (typeof  shortcode.fields === "object") {
                    temp = {
                        text: shortcode.title,
                        onclick: function () {
                            ed.windowManager.open({
                                title: shortcode.title,
                                body: get_form(shortcode.fields),
                                onsubmit: function (e) {
                                    var args = "";
                                    for (var i in e.data) {
                                        args += i + '="' + e.data[i] + '" ';
                                    }
                                    ed.insertContent('[' + index + ' ' + args + ']');
                                }
                            });
    
                            console.log(shortcode);
                        }
                    };
                }else {
                    temp = {
                        text: shortcode.title,
                        onclick: function () {
                            ed.insertContent('['+index+']');
                        }
                    };
                }
                return temp;
            }
            function get_form(fields) {
                var form   = [];
                for (var id in fields) {
                    var temp = {
                        type: fields[id].type,
                        name: fields[id].name,
                        label: fields[id].label,
                        value: fields[id].value,
                        values: fields[id].values
                    }
                    form.push(temp);
                }
                return form;
            }
            ed.addButton('flexrestaurants', {
                text: 'Flex Restaurants',
                icon: false,
                type: 'menubutton',
                menu: fs_code
            });
            
        }
    });
    tinymce.PluginManager.add('flexrestaurants', tinymce.plugins.flexrestaurants);
})();