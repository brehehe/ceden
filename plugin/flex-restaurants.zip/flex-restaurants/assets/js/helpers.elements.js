var initElements = {
    select_hidden: {
        init: function () {
            this.objSelect = $('.select_hidden');
            this.objField = $('.select_hidden_field');
            this.objBodySelect = $('.body_select_hidden');
            this.event();
            this.build();
        },
        build: function () {

            initElements.select_hidden.objSelect.each(function () {
               var id = $(this).find('.select_hidden_field option:selected').val();
               console.log(id);
                if(id !== undefined && id != '') {
                    $(this).find('.body_select_hidden .item').slideUp();
                    $(this).find('.body_select_hidden .item#' + id).slideDown();
                } else {
                    $(this).find('.body_select_hidden .item').slideUp();
                }
            });
            return false;
        },
        event: function () {
            var $this = this;
            $(document).on('change', '.select_hidden_field', function (e) {
                e.preventDefault();
                $this.handleChange($(this));
                return false;
            });
        },
        handleChange: function (obj) {
            var parent = obj.parents('.select_hidden');
            var id = obj.val();
            if(id !== undefined && id != '') {
                parent.find('.body_select_hidden .item').slideUp();
                parent.find('.body_select_hidden .item#' + id).slideDown();
            } else {
                parent.find('.body_select_hidden .item').slideUp();
            }
        }
    }
};