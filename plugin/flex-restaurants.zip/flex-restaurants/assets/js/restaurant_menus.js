/**
 * Created by Manhn on 22/5/2017.
 */
jQuery(document).ready(function($){
    
    if ($('.menu-items').length) {
        var defaultFilter = $('.tagsort-active').attr('data-filter');
        var $grid3        = $('.menu-items').isotope({
            itemSelector: '.menu-item',
            layoutMode: 'fitRows',
            filter: defaultFilter
        });
        $('.menu-tags').on('click', 'span', function () {
            $('.menu-tags span').removeClass('tagsort-active');
            $(this).toggleClass('tagsort-active');
            var filterValue = $(this).attr('data-filter');
            $grid3.isotope({filter: filterValue});
        });
    }
});