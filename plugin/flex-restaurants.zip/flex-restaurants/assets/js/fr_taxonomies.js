/**
 * Created by Manhn on 10/6/2017.
 */
jQuery(document).ready(function ($) {
    if (!$('.wp-list-table').length) {
        return;
    }
    $('.wp-list-table').addClass('ui-sortable');
    $('.ui-sortable tbody').sortable({
        start:function () {
            $(this).css('cursor','move');
        },
        stop: function () {
            var data = [];
            $(this).children().each(function () {
                var id = $(this).attr('id');
                id     = id.substr(4);
                data.push(id);
            });
            $.ajax({
                url: fs_ajax.url,
                type: "post",
                data: {
                    action: fs_ajax.action,
                    data: data
                },
                dataType: 'json'
            }).done(function (response) {
                if (response == 1) {
                    console.log(response);
                } else {
                    $('.ui-sortable tbody').sortable('cancel');
                }
            }).fail(function (response) {
                $('.ui-sortable tbody').sortable('cancel');
            }).always(function () {
            });
    
            $(this).css('cursor','auto');
        }
    });
});