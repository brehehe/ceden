jQuery(function ($) {
    var price_type_data = {};
    
    var restaurantSettings = {
        init: function () {
            this.price_type.init();
            this.tab_processer.init();
            this.libs_init();
        },
        price_type: {
            init: function () {
                this.globalVars();
                this.initFromOldData();
                this.eventDefine();
            },
            globalVars: function () {
                this.objBtnCategory          = $(document).find('#add_price_category');
                this.objSampleDOM            = $(document).find('.sample_price_type');
                this.objSamplePriceType      = this.objSampleDOM.find('.price_type');
                this.objSampleCategoryHeader = this.objSampleDOM.find('.category_header a');
                this.objSampleCategoryGroup  = this.objSampleDOM.find('.category_group');
                this.objBodyTab              = $(document).find('.inner_price_types');
                this.objHeaderTab            = $(document).find('.inner_categories');
                this.emptyIcon               = $(document).find('.inner_price_types .empty_list');
                
            },
            eventDefine: function () {
                var $this = this;
                $(document).on('click', '#add_price_category', function (e) {
                    e.preventDefault();
                    $this.handleAddCategory($(this));
                });
                
                // Update header category
                $(document).on('change', '.header_input', function (e) {
                    e.preventDefault();
                    $this.handleUpdateHeaderCat($(this));
                });
                // Remove add price
                $(document).on('click', '.add_price', function (e) {
                    e.preventDefault();
                    $this.handleAddPriceType($(this));
                });
                
                // Remove price type
                $(document).on('click', '#remove_price_type', function (e) {
                    e.preventDefault();
                    $this.handleRemovePriceType($(this));
                });
                
                // Remove cat
                $(document).on('click', '#remove_cat', function (e) {
                    e.preventDefault();
                    $this.handleRemoveCategory($(this));
                });
                
                $(document).on('change', '#id_price, #price_name', function () {
                    $this.handleUpdatePriceType($(this));
                });
            },
            initFromOldData: function () {
                var oldVal = $(document).find('#fc_price_type_data').val();
                
                if (oldVal == null || oldVal == '') {
                    this.emptyIcon.show();
                    return false;
                }
                
                try {
                    price_type_data = JSON.parse(oldVal);
                } catch (err) {
                    console.log(error);
                    this.emptyIcon.show();
                    return false;
                }
                
                if (restaurantSettings.countObj(price_type_data) == 0) {
                    this.emptyIcon.show();
                    return false;
                }
                
                count = 0;
                for (cat_slug in price_type_data) {
                    var cat_name = price_type_data[cat_slug]['name'];
                    this.addNewCategory(cat_slug, cat_name);
                    for (price_type_id in price_type_data[cat_slug]['price_types']) {
                        this.addNewPriceType(cat_slug, price_type_id, price_type_data[cat_slug]['price_types'][price_type_id]);
                    }
                    if (count == 0) {
                        // Active Category
                        restaurantSettings.tab_processer.handleActive(this.objHeaderTab.parents('.tab_processer'), cat_slug);
                    }
                    count++;
                }
            },
            // Handlers
            handleAddCategory: function (obj) {
                var parent        = obj.parents('#price_type_modal'),
                    category_slug = parent.find('#input_category_slug').val(),
                    category_name = parent.find('#input_category_name').val();
                
                if (category_slug == '' || category_slug == null || category_name == '' || category_name == null) {
                    alert('Please fill all the field');
                    return false
                }
                
                if (price_type_data[category_slug]) {
                    alert('This category slug already existed. Please choose another slug name!');
                    return false;
                }
                // HANDLE DATA
                category_slug                  = category_slug.toLowerCase()
                    .replace(/\s+/g, '-')           // Replace spaces with -
                    .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
                    .replace(/\-\-+/g, '-')         // Replace multiple - with single -
                    .replace(/^-+/, '')             // Trim - from start of text
                    .replace(/-+$/, '');            // Trim - from end of text
                price_type_data[category_slug] = {'name': category_name, price_types: {}};
                
                // Assign to the new group
                this.addNewCategory(category_slug, category_name);
                this.addNewPriceType(category_slug, '', '');
                // Active Category
                restaurantSettings.tab_processer.handleActive(this.objHeaderTab.parents('.tab_processer'), category_slug);
                
                // Modal Hide and reset
                $('#price_type_modal').modal('hide');
                parent.find('#input_category_slug').val('');
                parent.find('#input_category_name').val('');
                
                this.printPriceTypesData();
            },
            handleAddPriceType: function (obj) {
                var category        = obj.parents('.category_group'),
                    cat_slug        = category.attr('id'),
                    price_type_list = category.find('.price_type_list');
                this.addNewPriceType(cat_slug, '', '');
            },
            handleUpdatePriceType: function (obj) {
                var category          = obj.parents('.category_group'),
                    price_list_wapper = category.find('.price_type_list'),
                    category_id       = category.attr('id'),
                    parent_price_type = obj.parents('.price_type');
                
                price_type_data[category_id]['price_types'] = {};
                
                price_list_wapper.find('.price_type').each(function () {
                    var id_price   = $(this).find('#id_price').val(),
                        price_name = $(this).find('#price_name').val();
                    if (id_price != '' && price_name != '') {
                        id_price                                              = id_price.toLowerCase()
                            .replace(/\s+/g, '-')           // Replace spaces with -
                            .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
                            .replace(/\-\-+/g, '-')         // Replace multiple - with single -
                            .replace(/^-+/, '')             // Trim - from start of text
                            .replace(/-+$/, '');            // Trim - from end of text
                        price_type_data[category_id]['price_types'][id_price] = price_name;
                    }
                });
                this.printPriceTypesData();
            },
            handleUpdateHeaderCat: function (obj) {
                var parent_cat    = obj.parents('.category_group'),
                    parent_cat_id = parent_cat.attr('id'),
                    new_header    = obj.val();
                
                if (new_header == '' || new_header == null) {
                    alert('The header can not null');
                    obj.focus();
                    return false;
                }
                // Data change
                if (price_type_data[parent_cat_id]) price_type_data[parent_cat_id]['name'] = new_header;
                // Header change
                this.objHeaderTab.find('.item[data-target="' + parent_cat_id + '"] .name').html(new_header);
                this.printPriceTypesData();
            },
            handleRemoveCategory: function (obj) {
                if (!confirm('Are you sure you want to delete this category?')) return false;
                var parent_cat = obj.parents('.item'),
                    cat_id     = parent_cat.attr('data-target');
                // Data remove
                if (!price_type_data[cat_id]) {
                    alert('This cat doesnt existed in data. Please check it again!');
                    return false;
                }
                delete( price_type_data[cat_id]);
                // Remove DOM
                parent_cat.remove();
                this.objBodyTab.find('.item[id="' + cat_id + '"]').remove();
                this.printPriceTypesData();
                //this.removePrice(obj);
            },
            handleRemovePriceType: function (obj) {
                if (!confirm('Are you sure you want to delete this price type?')) return false;
                
                var parent_price_type = obj.parents('.price_type'),
                    cat_slug          = obj.parents('.category_group').attr('id'),
                    price_id          = parent_price_type.find('#id_price').val();
                
                obj.parents('.price_type').hide('slow').remove();
                
                this.removePriceType(cat_slug, price_id);
            },
            //Helpers
            printPriceTypesData: function () {
                $(document).find('#fc_price_type_data').val(JSON.stringify(price_type_data));
            },
            addNewCategory: function (cat_slug, cat_name) {
                var wrap_cat_group = this.objSampleCategoryGroup.clone(),
                    cat_header     = this.objSampleCategoryHeader.clone();
                this.emptyIcon.hide();
                
                // Assign to the new group
                wrap_cat_group.find('.slug_name').html(cat_slug);
                wrap_cat_group.find('.header_input').val(cat_name);
                wrap_cat_group.attr('id', cat_slug);
                cat_header.find('.name').html(cat_name);
                cat_header.attr('data-target', cat_slug);
                // Append to DOM
                this.objBodyTab.append(wrap_cat_group.hide());
                this.objHeaderTab.append(cat_header);
                
                this.printPriceTypesData();
            },
            addNewPriceType: function (cat_slug, price_id, price_name) {
                
                var sample              = this.objSamplePriceType.clone(),
                    category_wrapper    = this.objBodyTab.find('.item#' + cat_slug),
                    category_price_list = category_wrapper.find('.price_type_list');
                
                sample.attr('id', price_id);
                sample.find('#id_price').val(price_id);
                sample.find('#price_name').val(price_name);
                sample.appendTo(category_price_list);
                
                this.printPriceTypesData();
            },
            removePriceType: function (cat_slug, price_id) {
                if (price_type_data[cat_slug]['price_types'][price_id]) delete(price_type_data[cat_slug]['price_types'][price_id]);
                this.printPriceTypesData();
            },
            // Handler
            countObjectLength: function (obj) {
                count = 0;
                for (key in obj) {
                    count += 1;
                }
                return count;
            }
        },
        tab_processer: {
            init: function () {
                var $this = this;
                $('.tab_processer').each(function () {
                    var objTabProcesser = $(this);
                    $(this).find('.body_tab_processer .item').hide();
                    var obj_actived_tab = $(this).find('.header_tab_processer .item.active');
                    if (obj_actived_tab.length > 0) {
                        var target_actived   = obj_actived_tab.attr('data-target');
                        var obj_body_actived = $(this).find('.body_tab_processer .item#' + target_actived);
                        if (obj_body_actived.length > 0) {
                            obj_body_actived.show();
                        }
                    }
                    // Define event
                    $(document).on('click', '.header_tab_processer .item', function (e) {
                        e.preventDefault();
                        $this.handleActive($(this).parents('.tab_processer'), $(this).attr('data-target'));
                    });
                });
            },
            event: function () {
            
            },
            handleActive: function (objTabWrapper, tar_get_active) {
                objTabWrapper.find('.header_tab_processer').find('.item.active').removeClass('active');
                
                objTabWrapper.find('.header_tab_processer').find('.item[data-target="' + tar_get_active + '"]').addClass('active');
                objTabWrapper.find('.body_tab_processer .item').slideUp();
                objTabWrapper.find('.body_tab_processer .item#' + tar_get_active).slideDown();
            }
        },
        libs_init: function () {
            $('.js-modal-buttons').on('click', function () {
                var color = $(this).data('color');
                $('#price_type_modal .modal-content').removeAttr('class').addClass('modal-content modal-col-' + color);
                $('#price_type_modal').modal('show');
            });
        },
        countObj: function (obj) {
            count = 0;
            for (key in obj) {
                count++;
            }
            return count;
        }
    };
    restaurantSettings.init();
});