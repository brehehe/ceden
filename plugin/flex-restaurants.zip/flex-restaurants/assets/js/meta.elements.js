jQuery(function ($) {
    // calling out helpers
    initElements.select_hidden.init();

    var initMeta = {
        init: function () {

        }
    };
    initMeta.init();
});