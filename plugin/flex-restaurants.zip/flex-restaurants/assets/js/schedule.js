jQuery(document).ready(function($) {
    var Schedule = {
        init: function() {
            this.domScheduleBody = $('#schedule-body')
            this.buttonAddSchedule = $('#add-schedule');
            this.domScheduleData = $('#data-schedule');
            this.domScheduleClone = $('#schedule-clone').children();
            this.buttonAddPost = $('button.add-post');
            this.domSelectClone = $('#select-clone').children();
            this.domSelectBody = null;
            this.objData = {};
            this.getData();
            this.clickAddNewSchedule();
        },
        getData: function() {
            if (this.domScheduleData.val()) {
                this.objData = JSON.parse(this.domScheduleData.val());
            }
        },
        clickAddNewSchedule: function() {
            $this = this;
            $this.buttonAddSchedule.click(function(event) {
                event.preventDefault();
                $this.addNewSchedule();
            });
        },
        addNewSchedule: function() {
            $s_clone = this.domScheduleClone.clone();
            this.buttonAddSchedule.parent().after($s_clone);
            this.handlerAddNewSchedule($s_clone);
        },
        handlerAddNewSchedule: function(clone) {
            $this = this;
            var $numschedule = this.getNumberSchedule() + 1;
            clone.find('#clone').attr('id', "schedule-" + $numschedule);
            clone.find('.select-post').attr({
                'id': "select-" + $numschedule,
                'data-scheduleid': $numschedule
            });
            clone.find('.add-post').attr({
                'id': "add-post-" + $numschedule,
                'data-scheduleid': $numschedule
            });
            if(!$this.objData.hasOwnProperty($numschedule)){
                $this.objData[$numschedule] = {
                    from: null,
                    to: null,
                    post: {}
                };
            }
            clone.find(".flatpickr").flatpickr({
                mode: "range",
                weekNumbers: true,
                appendTo:{
                    contains :function () {
                        return $('body');
                    }
                },
                dateFormat: format_date,
                onClose: function(data) {
                    console.log(data);
                    $this.getData();
                    if(data[0] == "" || data[1] == "" || data[0] == null || data[1] == null){
                        return false;
                    }
                    var $from = data[0].toDateString();
                    var $to = data[1].toDateString();
                    
                    $temp = $this.objData[$numschedule].post;
                    $this.objData[$numschedule] = {
                        from: $from,
                        to: $to,
                        post: $temp
                    };
                    $this.showData();
                }
            });
            $this.showData();
        },
        getNumberSchedule: function() {
            $schedules = this.objData;
            $count = 0;
            $.each($schedules,function(index, el) {
                $count = index;
            });
            return parseInt($count);
        },
        showData: function() {
            var data = JSON.stringify(this.objData);
            this.domScheduleData.val(data);
        }
    };
    Schedule.init();
    
    var SelectPost = {
        init:function(){
            this.buttonAddPost = 'button.add-post';
            this.domSelectClone = $('#select-clone').children();
            this.domSelectBody = null;
            this.clickAddNewPost();
        },
        clickAddNewPost: function() {
            $post = this;
            $(document).on('click',$post.buttonAddPost,function(event) {
                event.preventDefault();
                $post.addNewPost($(this));
            });
        },
        addNewPost: function(button) {
            $p_clone = this.domSelectClone.clone();
            $p_clone.insertBefore(button.parent());
            Schedule.getData()
            this.handlerAddNewPost(button,$p_clone);
        },
        handlerAddNewPost: function(button,clone) {
            $post = this;
            $scheduleid = button.parents('.select-post').data('scheduleid');
            var $numpost = this.getNumberPost($scheduleid) + 1;
            clone.find('#clone-post').attr({
                'id': "select-post-" + $numpost,
            });
            clone.attr({
                'data-postid':$numpost
            });
            var select = clone.find("select");
            select.selectpicker({
                liveSearch: true,
                showTick: true,
            });
            select.on('change', function() {
                $postid = $(this).parents('div.select').data('postid');
                $scheduleid = $(this).parents('.select-post').data('scheduleid');
                if(!Schedule.objData.hasOwnProperty($scheduleid)){
                    $temp = {};
                    $temp[$postid] = $(this).val()
                    Schedule.objData[$scheduleid] = {
                        from:null,
                        to:null,
                        post:$temp
                    }
                }else{
                    $temp = Schedule.objData[$scheduleid].post;
                    $temp[$postid] = $(this).val();
                    Schedule.objData[$scheduleid] = {
                        from:Schedule.objData[$scheduleid].from,
                        to:Schedule.objData[$scheduleid].to,
                        post:$temp,
                    }
                }
                Schedule.showData()
            });
        },
        getNumberPost: function(scheduleid) {
            $count = 0;
            $posts = Schedule.objData[scheduleid].post;
            $.each($posts,function(index, el) {
                $count++;
            });
            return parseInt($count);
        }
    };
    SelectPost.init();
    
    $(".flatpickr").flatpickr({
        mode: "range",
        dateFormat: format_date,
        appendTo:{
            contains :function () {
                return $('body');
            }
        },
        weekNumbers : true,
        onClose: function(selectedDates, dateStr, instance) {
            Schedule.getData();
            // console.log($(instance.input,this));
            $scheduleid = $(instance.input,this).parents('.sub-schedule').find('.select-post').data('scheduleid');
            if(selectedDates[0] == "" || selectedDates[1] == "" || selectedDates[0] == null || selectedDates[1] == null){
                return false;
            }
            var $from = selectedDates[0].toDateString();
            var $to = selectedDates[1].toDateString();
            $temp = Schedule.objData[$scheduleid].post;
            Schedule.objData[$scheduleid] = {
                from: $from,
                to: $to,
                post: $temp
            };
            Schedule.showData();
        }
    });
    
    $(".select select").on('change', function(event) {
        event.preventDefault();
        Schedule.getData();
        $postid = $(this).parents('div.select').data('postid');
        $scheduleid = $(this).parents('.select-post').data('scheduleid');
        
        $temp = Schedule.objData[$scheduleid].post;
        $temp[$postid] = $(this).val();
        
        Schedule.objData[$scheduleid] = {
            from:Schedule.objData[$scheduleid].from,
            to:Schedule.objData[$scheduleid].to,
            post:$temp,
        };
        Schedule.showData();
    });
    
    $(document).on('click', '.delete-schedule', function(event) {
        event.preventDefault();
        if (!window.confirm("Are you sure you want to delete this schedule?")) {
            return false;
        }
        Schedule.getData();
        $dom = $(this).parents('.sub-schedule');
        $scheduleid = $dom.find('.select-post').data('scheduleid');
        delete Schedule.objData[$scheduleid];
        $dom.remove();
        Schedule.showData();
    });
    
});