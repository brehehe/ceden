/**
 * Created by Manhn on 26/5/2017.
 */

jQuery(document).ready(function ($) {
    
    if ($('.schedule-items').length) {
        $('.schedule-items .owl-carousel').owlCarousel({
            margin: 10,
            loop: true,
            autoplay: true,
            autoplayTimeout: 3000,
            items: 1,
            smartSpeed:2000
        });
    }
});