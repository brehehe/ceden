<?php
	
	/**
	 * Plugin Name: Flex Restaurants
	 * Plugin URI:
	 * Description: A powerful Wordpress plugin for restaurant
	 * Version: 1.0.5
	 * Author: FSFLEX TEAM
	 * Author URI: https://fsflex.com
	 * License: GPLv2 or later
	 * Text Domain: flex-restaurants
	 *
	 */
	if ( ! defined( 'ABSPATH' ) ) {
		die( '-1' );
	}
	$dev_mode = true;;
	$textdomain = 'flex-restaurants';
	
	$plugin_folder_name = dirname( plugin_basename( __FILE__ ) );
	require_once 'flexRestaurants-install.php';
	
	if ( ! class_exists( 'FlexRestaurants' ) ) {
		final class FlexRestaurants extends fs_boot {
			/**
			 * @var Singleton The reference to *Singleton* instance of this class
			 */
			private static $instance;
			
			public $currency = array();
			public $format_date = array();
			public $folder_name;
			// public $dev_mode = true;
			
			/**
			 * Main Instance
			 *
			 * Insures that only one instance of myMaps exists in memory at any one
			 * time. Also prevents needing to define globals all over the place.
			 *
			 * @since     1.0.0
			 * @staticvar object $instance
			 * @uses      FlexRestaurants::setup_globals() Setup the globals needed
			 * @uses      FlexRestaurants::includes() Include the required files
			 * @uses      FlexRestaurants::setup_actions() Setup the hooks and actions
			 * @return The one true myMaps
			 */
			public static function instance() {
				if ( null === static::$instance ) {
					static::$instance = new static();
					static::$instance->global_vars();
					static::$instance->include_files();
					
				}
				
				return static::$instance;
			}
			
			private function global_vars() {
				$this->plugin_dir = plugin_dir_path( __FILE__ );
				$this->plugin_url = plugins_url();
			}
			
			/**
			 * Include core file
			 */
			private function include_files() {
				global $plugin_folder_name;
				$plugin_folder_name = dirname( plugin_basename( __FILE__ ) );
				$this->init( $plugin_folder_name );
				$this->requireFolder( 'core.configuration' );
				$this->requireFolder( 'core.admin' );
				$this->requireFolder( 'core' );
				$this->requireFolder( 'core.helpers' );
				$this->requireFolder( 'core.api' );
			}
			
		}
		
		/**
		 * The main function responsible for returning the one true rlProducts Instance
		 * to functions everywhere.
		 *
		 * Use this function like you would a global variable, except without needing
		 * to declare the global.
		 *
		 *
		 * @return The one true rlProducts Instance
		 */
		
		if ( ! function_exists( 'FlexRestaurants' ) ) {
			function FlexRestaurants() {
				return FlexRestaurants::instance();
			}
		}
		
		/**
		 * Hook declare_mymaps early onto the 'plugins_loaded' action.
		 *
		 * This gives all other plugins the chance to load before myMaps, to get their
		 * actions, filters, and overrides setup without tabCarousel being in the way.
		 */
		if ( defined( 'FlexRestaurants_LATE_LOAD' ) ) {
			add_action( 'plugins_loaded', 'FlexRestaurants', (int) FlexRestaurants_LATE_LOAD );
		} else {
			FlexRestaurants();
		}
		
		add_action( 'plugins_loaded', function () {
			do_action( 'flex-restaurant_init' );
		} );
		
	}
	
