<?php

if(isset($fc_price_type_data)) {
    $fc_price_type_data = json_decode(stripslashes($fc_price_type_data), true);
    $cat_value = get_post_meta($post_id, 'categories_price', true);
}
if(empty($fc_price_type_data)){
    $fc_price_type_data = array();
    $cat_value = '';
}
?>
<div class="row clearfix">
    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
        <label for="xcvzxc"><?php esc_html_e('Categories Price', FlexRestaurants()->app->domain) ?></label>
    </div>
    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
        <div class="custom_card category_price_wrapper select_hidden" style="margin:0;">
            <div class="header bg-light-blue">
                <select style="background:none" name="fr_extra_categories_price" class="form-control show-tick select_hidden_field" data-live-search="true">
                    <option value=""><?php esc_html_e('No item selected', FlexRestaurants()->app->domain) ?></option>
                    <?php foreach ($fc_price_type_data as $slug => $value): ?>
                        <option value="<?php echo $slug ?>"
                        <?php if($cat_value == $slug): ?>
                            selected="selected"
                        <?php endif ?>
                        ><?php echo $value['name'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
               <div class="body_select_hidden">
                   <?php foreach ($fc_price_type_data as $slug => $value): ?>
                       <div class="item price_types" id="<?php echo $slug ?>" style="display:none">
                           <div class="body">
                               <?php foreach ($value['price_types'] as $slug_price => $price_type): ?>
                                   <?php
                                   $value_meta = get_post_meta($post_id, $slug_price, true);
                                   echo $this->generate_field(array(
                                       'type'   => 'text',
                                       'value' => $value_meta,
                                       'name'   => 'fr_extra_' . $slug_price,
                                       'id'     => $slug_price,
                                       'label'  => $price_type . ' (' . $currency['character'] . ')',
                                       'layout' => 'horizontal'
                                   ));
                                   ?>
                               <?php endforeach; ?>
                           </div>
                       </div>
                   <?php endforeach; ?>
               </div>
        </div>
    </div>
</div>
