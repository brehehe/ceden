<div class="row tab_processer">
    <div class="col-lg-12">
        <h4><?php esc_html_e('Price Types Configuration', FlexRestaurants()->app->domain)?></h4>
    </div>

    <div class="col-lg-6">
        <div class="list-group list_categories_price">
            <div class="inner_categories header_tab_processer"></div>
            <a class="list-group-item list-group-item-info js-modal-buttons cursor-pointer" data-toggle="modal" data-target="#smallModal">
                <i class="material-icons" style="font-size:20px;vertical-align: middle;">add</i>
                <?php esc_html_e('New Category', FlexRestaurants()->app->domain) ?>
            </a>
        </div>
    </div>

    <div class="col-lg-6 body_tab_processer inner_price_types">
        <div class="empty_list noselect">
            <img src="<?php echo FlexRestaurants()->plugin_url . '/images/search-512.png' ?>" alt="">
            <center><?php esc_html_e('NO PRICE TYPE NOT FOUND', 'flex-restaurants') ?></center>
        </div>
    </div>
</div>

<div class="sample_price_type" style="display:none">
    <li class="list-group-item price_type" id="">
        <div class="form-horizontal">
            <div class="row clearfix">
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                    <label for="id_price">ID</label>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" id="id_price" class="form-control"
                                   placeholder="<?php esc_html_e('Enter the unique id', 'flex-restaurants') ?>"
                                   autocomplete="off">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                    <label for="price_name"><?php esc_html_e('Price name', 'flex-restaurants') ?></label>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" id="price_name" class="form-control"
                                   placeholder="<?php esc_html_e('Enter the price name', 'flex-restaurants') ?>"
                                   autocomplete="off">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
    </li>
    <div class="category_header">
        <a class="item list-group-item "><span class="name"></span><img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_cat" style=""></a>
    </div>
    <div class="category_group item" id="{{category_slug}}">
        <div class="body-card">
            <div class="header bg-light-blue">
                <p><i>#<span id="span" class="slug_name">{{slug_name}}</span></i></p>
                <h2 style="with:100%">
                    <input type="text" class="header_input" value="Category 1"
                           style="width:100%;background:none;border:none;box-shadow:none;color:white;border-left:2px solid white"
                           placeholder="<?php esc_html_e('Enter Your Price Type', 'flexrestuarants') ?>">
                </h2>
            </div>
            <div class="body" style="padding:0;">
                <ul class="list-group price_type_list">
                </ul>
                <button type="button" class="btn btn-block btn-lg btn-info waves-effect btn-sm add_price"><i
                        class="material-icons"
                        style="font-size:20px;vertical-align: middle;">add</i> <?php esc_html_e('New Price', 'flex-restaurants') ?>
                </button>
            </div>
        </div>
    </div>
</div>
<textarea name="fc_price_type_data" id="fc_price_type_data" style="width:100%;height:500px;display:none;"><?php echo stripslashes($settings_option['fc_price_type_data']) ?></textarea>

<div class="modal fade in" id="price_type_modal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content" style="top:20px">
            <div class="modal-header">
                <h4 class="modal-title" id="smallModalLabel"><?php esc_html_e('New price type category', 'flex-restaurants') ?></h4>
            </div>
            <div class="modal-body">
                <p><?php esc_html_e('The slug can not be changed after you created. Please choose a right slug before you decide to fill in. The slug must follow this format: ', 'flex-restaurants')?><b>your_slug_name</b></p>
                <div class="form-horizontal">
                    <div class="row clearfix">
                        <div class="col-lg-12 form-control-label">
                            <p>
                            <div class="form-group" style="margin:0;padding:0">
                                <div class="form-line">
                                    <input type="text" id="input_category_slug" class="form-control" placeholder="<?php esc_html_e('Enter category slug', 'flex-restaurants') ?>" autocomplete="off">
                                </div>
                            </div>
                            </p>
                            <p>
                            <div class="form-group" style="margin:0;padding:0">
                                <div class="form-line">
                                    <input type="text" id="input_category_name" class="form-control" placeholder="<?php esc_html_e('Enter category name', 'flex-restaurants') ?>" autocomplete="off">
                                </div>
                            </div>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" id="add_price_category">SAVE CHANGES</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
            </div>
        </div>
    </div>
</div>