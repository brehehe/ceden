<div class="wrap">
    <div class="block-header">
        <h1>Schedule Config</h1>
    </div>
    <div class="col-md-12 col-lg-12">
		<?php echo $this->autoCheckNotice(); ?>
    </div>
    <div class="col-md-12">
        <div class="custom_card">
            <div class="header">
                <h2>Schedule
                    <small>Show your specific menu by specific time.</small>
                </h2>
            </div>
            <div class="body">
                <form method="post" accept-charset="utf-8">
                    <div class="row materialize">
                        <div id="schedule-body">
                            <div class="col-md-12">
                                <button class="btn btn-primary add-schedule" id="add-schedule">
                                    <i class="fa fa-plus"></i> Add Schedule
                                </button>
                                <button type="submit" name="submit" class="btn btn-primary pull-right">
                                    <i class="fa fa-floppy-o"></i> Save
                                </button>
                            </div>
							<?php
								if ( is_array( $schedules ) ) {
									foreach ( $schedules as $key => $sche ): ?>
                                        <div class="col-md-12">
                                            <div class="custom_card sub-schedule">
                                                <div class="header bg-orange">
                                                    <div class="row">
                                                        <div class="col-md-10 col-sm-10 col-lg-10 col-xs-10">
                                                            <input
                                                                    class="flatpickr flatpickr-custom pull-left"
                                                                    type="text"
                                                                    placeholder="Select Date.."
                                                                    data-default-date="<?php echo fr_convert_time( $sche['from'] ) . ' to ' . fr_convert_time( $sche['to'] ) ?>">
                                                        </div>
                                                        <div class="col-md-2 col-sm-2 col-lg-2 col-xs-2">
                                                            <a href="javascript:void(0);" class="delete-schedule pull-right" title="Delete this schedule...">
                                                                <i class="material-icons">delete_forever</i> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="body select-post row" id="select-<?php echo $key; ?>" data-scheduleid="<?php echo $key; ?>">
													<?php
														if ( ! empty( $sche['post'] ) ) {
															foreach ( $sche['post'] as $p => $post ) { ?>
                                                                <div class="col-md-6 select" data-postid="<?php echo $p; ?>">
																	<?php
																		echo $this->generate_field( [
																			'name'         => 'select[]',
																			'type'         => 'select_search',
																			'id'           => 'select-post-' . $p,
																			'value'        => $post,
																			'show_content' => true,
																			'options'      => $posts,//list post
																		] );
																	?>
                                                                </div>
																<?php
															}
														}
													?>
                                                    <div class="col-md-12 add-select" style="margin: 10px;">
                                                        <button class="btn add-post" id="add-post">
                                                            <i class="fa fa-plus"></i> Add
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
										<?php
									endforeach;
								}
							?>
                            <div class="equals hidden">
                                <textarea class="form-control" name="data_schedule" id="data-schedule"><?php echo $options; ?></textarea>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" name="submit" class="btn btn-primary">
                                    <i class="fa fa-floppy-o"></i> Save
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="clone hidden materialize">
            <div id="select-clone">
                <div class="col-md-6 select" data-postid="">
					<?php
						echo $this->generate_field( [
							'name'    => 'select[]',
							'type'    => 'select_search',
							'id'      => 'clone-post',
							'class'   => 'ms',
							'value'   => array(),
							'show_content' => true,
							'options' => $posts,//list post
						] );
					?>
                </div>
            </div>
            <div id="schedule-clone">
                <div class="col-md-12">
                    <div class="custom_card sub-schedule">
                        <div class="header bg-orange">
                            <div class="row">
                                <div class="col-md-10 col-sm-10 col-lg-10 col-xs-10">
                                    <input id="clone"
                                           class="flatpickr flatpickr-input flatpickr-custom pull-left"
                                           type="text" placeholder="Select Date.."
                                           data-date="">
                                </div>
                                <div class="col-md-2 col-sm-2 col-lg-2 col-xs-2">
                                    <a href="javascript:void(0);" class="delete-schedule pull-right" title="Delete this schedule...">
                                        <i class="material-icons">delete_forever</i> </a>
                                </div>
                            </div>
                        </div>
                        <div class="body select-post row">
                            <!--append post here-->
                            <div class="col-md-12 add-select" style="margin: 10px;">
                                <button class="btn add-post" id="add-post"><i class="fa fa-plus"></i> Add</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>