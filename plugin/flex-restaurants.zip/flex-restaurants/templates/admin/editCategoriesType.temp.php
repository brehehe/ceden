<?php
$tbody = array();

if ( is_array( $taxonomies ) ) {
    foreach ( $taxonomies as $key => $value ) {
        $slug = $value['slug'];

        $action = "";
        if ( $value['slug'] == 'stores' ) {
            $action = '';
        }
        $tbody[$key] = array(
            'name'   => $value['name'],
            'slug'   => $value['slug'],
            'action' => $action
        );
    }
}
?>
<div class="wrap materialize">
    <div class="block-header">
        <h1>Categories Types</h1>
    </div>
    <div class="col-md-12 col-lg-12">
        <?php echo $this->autoCheckNotice(); ?>
    </div>
    <div class="col-md-4 col-lg-4">
        <div class="custom_card">
            <div class="header">
                <h2>Edit Category</h2>
            </div>
            <div class="body">
                <p>
                    <i> <?php esc_html_e( 'This page allows you to add various items of your coupons', FlexRestaurants()->app->domain ) ?></i>
                </p>
                <p><i> <?php esc_html_e( 'Note: You can modify this after created.', FlexRestaurants()->app->domain ) ?></i></p>

                <form method="POST" >

                    <div class="form-group">
                        <div class="form-line">
                            <?php wp_nonce_field( 'add_review_form', 'br_user_form' ); ?>
                            <label for="fr_cattype_name"><?php esc_html_e( 'Name', FlexRestaurants()->app->domain ); ?></label>
                            <?php echo $this->generate_field( array( 'name' => 'name', 'id' => 'name', 'value' => $current_taxonomy['name'] )  ); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <label for="fr_cattype_name"><?php esc_html_e( 'Slug', FlexRestaurants()->app->domain ); ?></label>
                            <?php echo $this->generate_field( array('name' => 'slug' , 'id' => 'slug', 'value' => $current_taxonomy['slug']) ); ?>
                        </div>
                    </div>

                    <label for="type"><?php esc_html_e( 'Type', FlexRestaurants()->app->domain ) ?></label>
                    <div class="form-group">
                        <?php echo $this->generate_field( array(
                            'type'    => 'select',
                            'options' => array(
                                'select' => esc_html__( 'Select', FlexRestaurants()->app->domain ),
                                'tags' => esc_html__( 'Tags', FlexRestaurants()->app->domain )
                            ),
                            'name'    => 'type',
                            'id'      => 'type',
                            'value'   => array($current_taxonomy['type']),
                            'label'   => esc_html__( 'Type', FlexRestaurants()->app->domain )
                        ) ); ?>
                        <p class="description"><?php esc_html_e( 'Determines how you select category type for products..', FlexRestaurants()->app->domain ) ?></p>
                    </div>

                    <label for="description"><?php esc_html_e( 'Description', FlexRestaurants()->app->domain ) ?></label>
                    <div class="form-group">
                        <?php echo $this->generate_field( array(
                            'type'    => 'textarea',
                            'name'    => 'description',
                            'id'      => 'description',
                            'value'   => $current_taxonomy['description'],
                            'label'   => esc_html__( 'Description', FlexRestaurants()->app->domain )
                        ) ); ?>
                        <p class="description"><?php esc_html_e( 'The description is not prominent by default. However, some themes may show it.', FlexRestaurants()->app->domain ) ?></p>
                    </div>

                    <label><?php esc_html_e( 'Layout Images', FlexRestaurants()->app->domain ) ?></label>
                    <div class="thumbnails">

                        <div class="thumbnails_button materialize">
                            <a class="btn btn-success waves-effect button_thumbnail"
                               data-title="<?php esc_html_e('Choose or Upload Image', FlexRestaurants()->app->domain) ?>"
                               data-button="<?php esc_html_e('Use this image', FlexRestaurants()->app->domain) ?>"
                               data-multiple="true"> <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e('Add images', FlexRestaurants()->app->domain) ?></a>
                        </div>
                        <div class="thumbnails_images_container">
                            <ul class="thumbnails_images ui-sortable">
                                <?php
                                $image_ids = array_filter(explode(',', $current_taxonomy['layout']));
                                foreach ($image_ids as $key => $id) {
                                    ?>
                                    <li class="image" data-attachment_id="<?php echo $id; ?>">
                                        <div class="picture"><?php echo wp_get_attachment_image($id, array(78, 78)); ?></div>
                                        <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                            <input type="hidden" name="layout" class="image_id" value=""/>
                        </div>
                        <div class="clearfix"></div>
                        <div class="sample" style="display:none">
                            <li class="image" data-attachment_id="">
                                <div class="picture"><img src="" alt=""></div>
                                <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                            </li>
                        </div>
                    </div>

                    <label><?php esc_html_e( 'Background Image', FlexRestaurants()->app->domain ) ?></label>
                    <div class="thumbnails">

                        <div class="thumbnails_button materialize">
                            <a class="btn btn-success waves-effect button_thumbnail"
                               data-title="<?php esc_html_e('Choose or Upload Image', FlexRestaurants()->app->domain) ?>"
                               data-button="<?php esc_html_e('Use this image', FlexRestaurants()->app->domain) ?>"
                               data-multiple="false"> <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e('Add images', FlexRestaurants()->app->domain) ?></a>
                        </div>
                        <div class="thumbnails_images_container">
                            <ul class="thumbnails_images ui-sortable">
                                <?php if(!empty($current_taxonomy['background'])):?>
                                    <li class="image" data-attachment_id="<?php echo $current_taxonomy['background']; ?>">
                                        <div class="picture"><?php echo wp_get_attachment_image($current_taxonomy['background'], array(78, 78)); ?></div>
                                        <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                                    </li>
                                    <?php
                                endif
                                ?>
                            </ul>
                            <input type="hidden" name="background" class="image_id" value=""/>
                        </div>
                        <div class="clearfix"></div>
                        <div class="sample" style="display:none">
                            <li class="image" data-attachment_id="">
                                <div class="picture"><img src="" alt=""></div>
                                <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                            </li>
                        </div>
                    </div>

                    <div class="input-group">
                        <div>
                            <?php echo $this->generate_field( array(
                            'name'      => 'show_in_menu',
                            'id'        => 'show_in_menu',
                            'checked'   => (!$current_taxonomy['show_in_menu']) ? false : true,
                            'value'     => 'true',
                            'type'      => 'checkbox',
                            'label'     => esc_html__( 'Show in menu', FlexRestaurants()->app->domain )
                        ) ); ?>
                        </div>
                    </div>
                    <button type="submit" name="update_cat" class="btn btn-primary waves-effect"><?php esc_html_e('Update Category', FlexRestaurants()->app->domain); ?></button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-8 col-lg-8">
        <div class="custom_card">
            <div class="header">
                <h2>List Category</h2>
            </div>
            <div class="body">
                <table class="table table-striped table-hover ">
                    <thead>
                    <tr>
                        <th width="5%"><?php esc_html_e( 'ID', FlexRestaurants()->app->domain ); ?></th>
                        <th width="20%"><?php esc_html_e( 'Name', FlexRestaurants()->app->domain ); ?></th>
                        <th width="20%"><?php esc_html_e( 'Slug', FlexRestaurants()->app->domain ); ?></th>
                        <th width="50%"><?php esc_html_e( 'Terms', FlexRestaurants()->app->domain ); ?></th>
                        <th width="5%"><?php esc_html_e( 'Options', FlexRestaurants()->app->domain ); ?></th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th><?php esc_html_e( 'ID', FlexRestaurants()->app->domain ); ?></th>
                        <th><?php esc_html_e( 'Name', FlexRestaurants()->app->domain ); ?></th>
                        <th><?php esc_html_e( 'Slug', FlexRestaurants()->app->domain ); ?></th>
                        <th><?php esc_html_e( 'Terms', FlexRestaurants()->app->domain ); ?></th>
                        <th><?php esc_html_e( 'Options', FlexRestaurants()->app->domain ); ?></th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php if ( is_array( $tbody ) ): ?>
                        <?php foreach ( $tbody as $key => $value ): ?>
                            <?php
                            $terms = get_terms( array(
                                'taxonomy'   => $value['slug'],
                                'hide_empty' => false,
                            ) ); ?>

                            <tr <?php echo ($value['slug'] == $current_taxonomy['slug']) ? 'style=" background-color: #fce4ba;"' :'' ?>>
                                <td><?php echo $key; ?></td>
                                <td>

                                    <a href="<?php echo add_query_arg( array(
												'post_type' => 'flexrestaurants',
												'page'      => 'fr_update_category',
												'id'        => $key
											), 'edit.php' ) ?>">
                                        <strong><?php echo $value['name']; ?></strong>
                                    </a>
                                    
                                </td>
                                <td><?php echo $value['slug']; ?></td>
                                <td>
                                    <?php foreach ( $terms as $term ): ?>
                                        <?php if ( isset( $term->name ) ): ?>
                                            <span class="badge bg-cyan"><?php echo $term->name; ?></span>
                                        <?php endif ?>
                                    <?php endforeach; ?>
                                </td>
                                <td>

                                    <a href="<?php echo add_query_arg( array(
                                        'post_type' => 'flexrestaurants',
                                        'taxonomy'  => $value['slug']
                                    ), 'edit-tags.php' ) ?>" class="btn bg-orange waves-effect btn-xs" name="fr_save"
                                       data-toggle="tooltip"
                                       data-original-title="<?php echo $value['name'] ?> <?php esc_html_e( 'Management', FlexRestaurants()->app->domain ) ?>">
                                        <span class="dashicons dashicons-admin-generic" style="font-size: 18px"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>