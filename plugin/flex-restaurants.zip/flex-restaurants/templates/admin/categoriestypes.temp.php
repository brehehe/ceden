<div class="wrap materialize">
	<div class="block-header">
		<h1>Categories Types</h1>
	</div>

	
	<div class="col-md-12 col-lg-12">
		<?php echo $this->autoCheckNotice(); ?>
	</div>
	<div class="col-lg-4">
		<div class="custom_card">
			<div class="header">
				<h2>Add New Category</h2>
			</div>
			<div class="body">
				<p>
					<i> <?php esc_html_e( 'This page allows you to add various items of your restaurant.', FlexRestaurants()->app->domain ) ?></i>
				</p>
				<p><i> <?php esc_html_e( 'Note: You can modify this after created.', FlexRestaurants()->app->domain ) ?></i></p>

				<form method="post">
					<label for="name"><?php esc_html_e( 'Name', FlexRestaurants()->app->domain ); ?></label>
					<div class="input-group">
						<div class="form-line">
							<?php wp_nonce_field( 'add_review_form', 'br_user_form' ); ?>
							<?php echo $this->generate_field( array( 'name' => 'name', 'id' => 'name' ) ); ?>
						</div>
					</div>

					<label for="slug"><?php esc_html_e( 'Slug', FlexRestaurants()->app->domain ); ?></label>

					<div class="input-group">
						<div class="form-line">
							<?php echo $this->generate_field( array( 'name' => 'slug', 'id' => 'slug' ) ); ?>
						</div>
					</div>
					<label for="type"><?php esc_html_e( 'Type', FlexRestaurants()->app->domain ) ?></label>
					<div class="input-group">
						<?php echo $this->generate_field( array(
							'type'    => 'select',
							'options' => array(
								'select' => esc_html__( 'Select', FlexRestaurants()->app->domain ),
								'tags' => esc_html__( 'Tags', FlexRestaurants()->app->domain )
							),
							'name'    => 'type',
							'id'      => 'type',
							'label'   => esc_html__( 'Type', FlexRestaurants()->app->domain )
						) ); ?>
						<p class="description"><?php esc_html_e( 'Determines how you select category type for menu.', FlexRestaurants()->app->domain ) ?></p>
					</div>

                    <label for="description"><?php esc_html_e( 'Description', FlexRestaurants()->app->domain ) ?></label>
                    <div class="form-group">
                        <?php echo $this->generate_field( array(
                            'type'    => 'textarea',
                            'name'    => 'description',
                            'id'      => 'description',
                            'value'   => '',
                            'label'   => esc_html__( 'Description', FlexRestaurants()->app->domain )
                        ) ); ?>
                        <p class="description"><?php esc_html_e( 'The description is not prominent by default. However, some themes may show it.', FlexRestaurants()->app->domain ) ?></p>
                    </div>
					<label><?php esc_html_e( 'Layout Images', FlexRestaurants()->app->domain ) ?></label>
                    <div class="thumbnails">

                        <div class="thumbnails_button materialize">
                            <a class="btn btn-success waves-effect button_thumbnail"
                                       data-title="<?php esc_html_e('Choose or Upload Image', FlexRestaurants()->app->domain) ?>"
                                       data-button="<?php esc_html_e('Use this image', FlexRestaurants()->app->domain) ?>"
                                       data-multiple="true"> <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e('Add images', FlexRestaurants()->app->domain) ?></a>
                        </div>
                        <div class="thumbnails_images_container">
                            <ul class="thumbnails_images ui-sortable">
                            </ul>
                            <input type="hidden" name="layout" class="image_id" value=""/>
                        </div>
                        <div class="clearfix"></div>
                        <div class="sample" style="display:none">
                            <li class="image" data-attachment_id="">
                                <div class="picture"><img src="" alt=""></div>
                                <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                            </li>
                        </div>
                    </div>

					<label><?php esc_html_e( 'Background Image', FlexRestaurants()->app->domain ) ?></label>
                    <div class="thumbnails">

                        <div class="thumbnails_button materialize">
                            <a class="btn btn-success waves-effect button_thumbnail"
                               data-title="<?php esc_html_e('Choose or Upload Image', FlexRestaurants()->app->domain) ?>"
                               data-button="<?php esc_html_e('Use this image', FlexRestaurants()->app->domain) ?>"
                               data-multiple="true"> <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e('Add images', FlexRestaurants()->app->domain) ?></a>
                        </div>
                        <div class="thumbnails_images_container">
                            <ul class="thumbnails_images ui-sortable">
                            </ul>
                            <input type="hidden" name="background" class="image_id" value=""/>
                        </div>
                        <div class="clearfix"></div>
                        <div class="sample" style="display:none">
                            <li class="image" data-attachment_id="">
                                <div class="picture"><img src="" alt=""></div>
                                <img src="<?php echo flexRestaurants()->plugin_url. 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                            </li>
                        </div>
                    </div>
					
					<div class="input-group">
						<?php echo $this->generate_field( [
							'name'  => 'show_in_menu',
							'id'    => 'show_in_menu',
							'type'  => 'checkbox',
							'value' => 'true',
							'label' => esc_html__( 'Show in menu', FlexRestaurants()->app->domain )
						] ); ?>
					</div>
					<button type="submit" name="save_cat" class="btn btn-primary waves-effect"><?php esc_html_e( 'Save', FlexRestaurants()->app->domain ) ?></button>
				</form>
			</div>
		</div>
	</div>
	<div class="col-lg-8">
		<div class="custom_card">
			<div class="header">
				<h2>List Category</h2>
			</div>
			<div class="body">
				<?php if ( is_array( $taxonomies ) && ! empty( $taxonomies ) ): ?>
					<table class="table table-striped table-hover ">
						<thead>
							<tr>
								<th width="5%"><?php esc_html_e( 'ID', FlexRestaurants()->app->domain ); ?></th>
								<th width="20%"><?php esc_html_e( 'Name', FlexRestaurants()->app->domain ); ?></th>
								<th width="20%"><?php esc_html_e( 'Slug', FlexRestaurants()->app->domain ); ?></th>
								<th width="50%"><?php esc_html_e( 'Terms', FlexRestaurants()->app->domain ); ?></th>
								<th width="5%"><?php esc_html_e( 'Options', FlexRestaurants()->app->domain ); ?></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $taxonomies as $key => $value ): ?>
							<?php
							$terms = get_terms( array(
								'taxonomy'   => $value['slug'],
								'hide_empty' => false,
							) );
							?>

							<tr>
								<td><?php echo $key; ?></td>
								<td>

									<a href="<?php echo add_query_arg( array(
										'post_type' => 'flexrestaurants',
										'taxonomy'  => $value['slug']
									), 'edit-tags.php' ) ?>">
										<strong><?php echo $value['name']; ?></strong>
									</a>
									<div class="row-actions">
										<span class="edit"><a href="<?php echo add_query_arg( array(
												'post_type' => 'flexrestaurants',
												'page'      => 'fr_update_category',
												'id'        => $key
											), 'edit.php' ) ?>"
										                      aria-label="<?php esc_html_e( 'Edit “(no title)”', FlexRestaurants()->app->domain ) ?>"><?php esc_html_e( 'Edit', FlexRestaurants()->app->domain ) ?></a> | </span>
										<span class="trash">
                                            <a class="delete" href="<?php echo add_query_arg( array(
	                                            'post_type' => 'flexrestaurants',
	                                            'page'      => 'flexCategoriesType',
	                                            'id'        => $key,
	                                            'action'    => 'delete'
                                            ), 'edit.php' ) ?>" class="submitdelete"
                                               aria-label="<?php esc_html_e( 'Delete this category type forever', FlexRestaurants()->app->domain ) ?>"><?php esc_html_e( 'Delete', FlexRestaurants()->app->domain ) ?></a>
                                        </span>
									</div>
								</td>
								<td><?php echo $value['slug']; ?></td>
								<td>
									<?php foreach ( $terms as $term ): ?>
										<?php if ( isset( $term->name ) ): ?>
											<span class="badge bg-cyan"><?php echo $term->name; ?></span>
										<?php endif ?>
									<?php endforeach; ?>
								</td>
								<td>
									<a href="<?php echo add_query_arg( array(
										'post_type' => 'flexrestaurants',
										'taxonomy'  => $value['slug']
									), 'edit-tags.php' ) ?>" class="btn bg-orange waves-effect btn-xs" name="fr_save"
									   data-toggle="tooltip"
									   data-original-title="<?php echo $value['name'] ?> <?php esc_html_e( 'Management', FlexRestaurants()->app->domain ) ?>">
										<span class="dashicons dashicons-admin-generic" style="font-size: 18px"></span>
									</a>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
						<tfoot>
						<td><?php esc_html_e( 'ID', FlexRestaurants()->app->domain ); ?></td>
						<td><?php esc_html_e( 'Name', FlexRestaurants()->app->domain ); ?></td>
						<td><?php esc_html_e( 'Slug', FlexRestaurants()->app->domain ); ?></td>
						<td><?php esc_html_e( 'Terms', FlexRestaurants()->app->domain ); ?></td>
						<td><?php esc_html_e( 'Options', FlexRestaurants()->app->domain ); ?></td>
						</tfoot>
					</table>

				<?php else: ?>
					<center><?php esc_html_e( 'Empty List', FlexRestaurants()->app->domain ) ?></center>
				<?php endif ?>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	/* <![CDATA[ */

	jQuery('a.delete').click(function () {
		if (window.confirm(' <?php esc_html_e( "Are you sure you want to delete this category type?", FlexRestaurants()->app->domain ) ?>')) {
			return true;
		}
		return false;
	});

	/* ]]> */
</script>