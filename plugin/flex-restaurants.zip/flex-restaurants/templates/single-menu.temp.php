<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 11/6/2017
	 * Time: 9:17 PM
	 */
	
	get_header();
	
	if ( have_posts() ) {
		$pre_menu  = get_previous_post();
		$next_menu = get_next_post();
		$content   = get_the_content();
		$content   = ( strlen( $content ) <= 50 ) ? $content : ( substr( $content, 0, 50 ) . '...' );
		?>
        <style>
            
            .fs-page-single .menu-single .thumbnail {
            
            }

            .fs-page-single .menu-single .thumbnail .image {
                height: 330px;
                background-size: cover !important;
                background-position: center center;
            }

            .fs-page-single .menu-single .body {
                padding: 20px 0;
            }

            .fs-page-single .menu-single .body .title {
                text-transform: uppercase;
                font-size: 1.5em;
                text-align: left;
                font-weight: 600;
            }
            
            .menu-archive .menu-single .body .content {
                text-transform: capitalize;
                text-align: left;
                line-height: 32px;
            }
            
            .menu-archive .menu-single .body .price {
                text-align: right;
            }
            
            .menu-single .body .price .regular-price {
            
            }
            
            .menu-single .body .price .sale-price {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px 8px;
            }
            
            .menu-single .more {
            
            }
            
            .menu-single .more .button {
                padding: 15px 20px;
                background-color: #985f0d;
                color: #fff;
                text-transform: uppercase;
                font-weight: 600;
            }
        </style>
        <div class="fs-page-single">
            <section class="section bg-light">
                <div class="container">
                    <div class="carousel">
                        <!-- Special Offer -->
                        <div class="special-offer">
                            <img src="<?php echo esc_url( get_the_post_thumbnail_url( null, 'full' ) ) ?>" alt="<?php the_title() ?>" class="special-offer-image">
                            <div class="special-offer-content">
                                <h2 class="mb-2"><?php the_title() ?></h2>
                                <h5 class="text-muted mb-5"><?php esc_html_e( ( strlen( $post->post_content ) <= 50 ) ? $post->post_content : ( substr( $post->post_content, 0, 50 ) . '...' ), FlexRestaurants()->app->domain ) ?></h5>
                                <ul class="list-check text-lg mb-0">
                                    <li><?php fr_the_price( null, false ) ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="col-sm-6">
                <div class="pagination">
                        <?php if ( ! empty( $pre_menu ) ): ?>
                            <a class="previous" href="<?php echo esc_url( get_permalink( $pre_menu->ID ) ) ?>">&#11164; <?php echo esc_attr( $pre_menu->post_title ) ?></a>
                        <?php endif; ?>

                        <?php if ( ! empty( $next_menu ) ): ?>
                            <a class="next" href="<?php echo esc_url( get_permalink( $next_menu->ID ) ) ?>"><?php echo esc_attr( $next_menu->post_title ) ?> &#11166;</a>
                        <?php endif; ?>
                </div>
            </div>
        </div>
		<?php
	}
	get_footer();