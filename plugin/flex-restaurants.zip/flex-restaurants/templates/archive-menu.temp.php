<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 11/6/2017
	 * Time: 9:17 PM
	 */
	
	get_header();
	
	if ( have_posts() ) {
		global $wp_query;
		?>
        <style>
            .fs-page-archive .menu-archive {
            
            }
            
            .fs-page-archive .menu-archive .menu-single {
                /*width: 33.333333%;*/
                /*float: left;*/
                /*padding: 20px;*/
                margin-bottom: 40px;
            }
            
            .fs-page-archive .menu-archive .menu-single .thumbnail {
                overflow: hidden;
            }
            
            .fs-page-archive .menu-archive .menu-single .thumbnail .image {
                height: 330px;
                background-size: cover !important;
                background-position: center center!important;
            }
            
            .fs-page-archive .menu-archive .menu-single .body {
                padding: 20px 0;
            }
            
            .fs-page-archive .menu-archive .menu-single .body .title {
                text-transform: uppercase;
                font-size: 1.5rem;
                text-align: left;
                font-weight: 600;
            }
            
            .fs-page-archive .menu-archive .menu-single .body .content {
                text-transform: capitalize;
                text-align: left;
                line-height: 32px;
            }
            
            .fs-page-archive .menu-archive .menu-single .body .price {
                text-align: right;
            }
            
            .fs-page-archive .menu-archive .menu-single .body .price .regular-price {
                text-decoration: line-through;
            }
            
            .fs-page-archive .menu-archive .menu-single .body .price .sale-price {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px 8px;
            }
            
            .fs-page-archive .menu-archive .menu-single .more {
            
            }
            
            .fs-page-archive .menu-archive .menu-single .more .button {
                padding: 15px 20px;
                background-color: #985f0d;
                color: #fff;
                text-transform: uppercase;
                font-weight: 600;
            }
            
            .fs-page-archive .pagination {
            
            }
            
            .fs-page-archive .pagination .previous_page {
                float: left;
            }
            
            .fs-page-archive .pagination .previous_page a {
            
            }
            
            .fs-page-archive .pagination .next_page {
                float: right;
            }
            
            .fs-page-archive .pagination .next_page a {
            
            }
            
            .fs-page-archive .pagination .next_page a.disable, .fs-page-archive .pagination .previous_page a.disable {
                pointer-events: none;
                cursor: default;
                opacity: 0.6;
            }
            .image{
                -webkit-transition: all linear .2s;
                -moz-transition: all linear .2s;
                -ms-transition: all linear .2s;
                -o-transition: all linear .2s;
                transition: all linear .2s;
            }
            .image:hover{
                transform: scale(1.5);
            }
        </style>
        <div class="fs-page-archive">
            <div class="menu-archive">
                <div class="container">
                    <div class="row flex-content">
                        <?php
                        while ( have_posts() ) {
                            the_post();
                            $content = get_the_content();
                            $content = ( strlen( $content ) <= 50 ) ? $content : ( substr( $content, 0, 50 ) . '...' );
                            ?>
                            <div class="col-lg-4 col-6 col-md-4 col-sm-4 col-xs-6">
                                <!-- Menu Item -->
                                <div class="menu-item menu-grid-item">
                                    <div class="thumbnail" style="width: 100%;">
<!--                                        <div class="image" style="background:url(<?php //echo esc_url( get_the_post_thumbnail_url( null, 'full' ) ) ?>)"></div>-->
                                        <img class="mb-4" src="<?php echo esc_url( get_the_post_thumbnail_url( null, 'full' ) ) ?>" style="width: 100%;" alt="">
                                    </div>
                                    <h6 class="mb-0"><?php the_title() ?></h6>
                                    <span class="text-muted text-sm"><?php echo esc_attr( $content ) ?></span>
                                    <div class="row align-items-center mt-4">
                                        <div class="col-sm-6"><span class="text-md mr-4"><span class="text-muted">from</span> <?php fr_the_price( null, false ) ?></span></div>
                                        <div class="col-sm-6 text-sm-right mt-2 mt-sm-0"><a class="button" href="<?php echo esc_url( get_permalink( get_the_ID() ) ) ?>">More Detail</a></div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php
                            $max_page = $wp_query->max_num_pages;
                            $current  = get_query_var( 'paged', 0 );
                            $current_page = $current !== 0 ? $current : 1 ;
                            ?>
                            <?php if($max_page > 1){?>
                                <div class="pagination">
                                    <?php if($current_page > 1){?>
                                        <a  href="<?php echo add_query_arg( array('paged' => $current_page - 1)); ?>">Previous</a>
                                    <?php } ?>
                                    <?php for($i = 1 ; $i <= $max_page ; $i++){?>
                                        <?php if($i == $current_page){?>
                                            <a class="active"><?php echo $i?></a>
                                        <?php }else{?>
                                            <a  href="<?php echo add_query_arg( array('paged' => $i)); ?>"><?php echo $i; ?></a>
                                        <?php }?>
                                    <?php }?>
                                    <?php if($current_page > 0 && $current_page < $max_page){?>
                                        <a  href="<?php echo add_query_arg(array('paged' => $current_page + 1)); ?>">Next</a>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
	get_footer();