jQuery(function ($) {
   alert('NUVO LAYOUT');
});