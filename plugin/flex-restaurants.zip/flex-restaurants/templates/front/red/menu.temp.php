<?php
global $wp;
$current_url = home_url(add_query_arg('page_id', get_query_var('page_id'), $wp->request));
?>
<section>
    <div class="container">
        <div class="row menu-widget">
            <div class="col-sm-12 col-md-3">
                <div class="menu-links clearfix text-center">
                    <nav>
                      <ul class="nav nav-pills nav-stacked span2">
                        <?php //var_dump($taxonomies); ?>
                        <?php foreach ($taxonomies as $k => $tax): ?>
                            <li><a href="<?php echo add_query_arg(array('taxonomy'=>$tax['slug']), $current_url); ?>"><h3><?php echo $tax['label']; ?></h3></a></li>
                            <?php 
                            if(is_object($tax['terms']) || is_array($tax['terms']))
                            foreach ($tax['terms'] as $t => $term): ?>
                                <li><a href="<?php echo add_query_arg(array('taxonomy'=>$tax['slug'],'term'=>$term->slug), $current_url); ?>"><?php echo $term->name;?></a></li>
                            <?php endforeach ?>
                        <?php endforeach ?>
                      </ul>
                    </nav>
                </div><!-- end menu-links -->
            </div><!-- end col -->
            <div class="col-sm-12 col-md-9">
                <div class="menu-links-big">
                    <?php if ($data->have_posts()): ?>
                        <?php while ($data->have_posts()) {
                            $data->the_post();
                            ?>                            
                            <div class="menu-item">
                                <img src="<?php the_post_thumbnail_url() ?>" alt="" class="img-thumbnail shadow alignleft">
                                <h3><?php the_title() ?></h3>
                                <p><?php the_content() ?></p>
                                <div class="price">$<?php echo get_post_meta(get_the_ID(),'fr-menu-price',true) ?></div>
                            </div><!-- end item -->
                            <?php
                        } ?>
                    <?php endif ?>
                    <nav>
                        <ul class="pager">
                        <?php if(get_query_var('paged',1) > 1){ ?>
                            <li class="pull-left"><a href="<?php echo add_query_arg(array('paged'=>(get_query_var('paged',1)-1)), $current_url); ?>">Prev</a></li>
                            <?php } ?>
                        <?php if(get_query_var('paged',1) < $data->max_num_pages){ ?>
                            <li class="pull-right"><a href="<?php echo add_query_arg(array('paged'=>(get_query_var('paged',1)+1)), $current_url); ?>">Next</a></li>
                            <?php } ?>
                        </ul>
                    </nav>
                </div><!-- end big -->
            </div><!-- end col -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end section -->