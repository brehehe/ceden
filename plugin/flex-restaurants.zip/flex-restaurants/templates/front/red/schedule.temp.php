<div class="row menu-of-week">
    <?php
    if($data->have_posts()){
        while ($data->have_posts()) {
            $data->the_post();
            ?>
                <div class="col-md-6 menu-items">
                    <div class="menu-item row shadow clearfix">
                        <div class="box col-md-6 wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
                            <a href="menu.html" title=""><?php the_post_thumbnail('medium');?></a>
                        </div>
                        <div class="menu-text col-md-6">
                            <h3><a href="menu.html" title=""><?php the_title() ?></a></h3>
                            <p><?php the_content() ?></p>
                            <h4>Price: <span>$<?php echo get_post_meta(get_the_ID(),'fr-menu-price',true) ?></span></h4>
                        </div>
                    </div><!-- end menu-item -->
                </div><!-- end col -->
            <?php
        }
    }
    ?>
    
</div>