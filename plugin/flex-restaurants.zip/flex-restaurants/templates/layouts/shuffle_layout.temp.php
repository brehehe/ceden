<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 19/5/2017
	 * Time: 2:54 PM
	 */
?>
<section class="menu" style="width: 100%">
    <div class="fs_container" style="width: 90%;margin: auto;">
        <div class="row">
            <div class="col-12">
                <div class="wow fadeInDown">
                    <h1 class="text-center"><?php  echo $infor['name'] ?>
                        <small><?php esc_html_e( stripcslashes( $infor['description'] ) ) ?></small>
                    </h1>
                </div>
            </div>
        </div>
        <div class="food-menu wow fadeInUp">
            <div class="row">
                <div class="col-12">
                    <div class="menu-tags">
                        <span data-filter="*" class="tagsort-active">All</span>
						<?php foreach ( $infor['terms'] as $term ): ?>
                            <span data-filter=".<?php echo $term->slug ?>"><?php echo $term->name ?></span>
						<?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="row menu-items <?php esc_html_e( isset( $class ) ? $class : '' ) ?>" style="position: relative; height: 392px;">
				<?php
					$posts = $body['posts'];
					do_action( 'before_archive_menus' );
					foreach ( $posts as $post ):
						do_action( 'before_show_single_menu', $post->ID );
						$option_class = "";
						if ( isset( $infor['slug'] ) ) {
							$slug = $infor['slug'];
							if ( function_exists( 'fr_get_terms_by_post' ) ) {
								$terms = fr_get_terms_by_post( $post->ID, $slug );
								foreach ( $terms as $term ) {
									$option_class .= $term->slug . " ";
								}
							}
						}
						
						$option_class = apply_filters( 'single_menu_class', $option_class );
						?>
                        
                        <div class="menu-item col-6 <?php esc_html_e( $option_class ) ?>">
                            <img src="<?php echo esc_url( get_the_post_thumbnail_url( $post->ID, 'thumbnail' ) ) ?>" class="img-responsive" alt="">
                            <div class="menu-wrapper">
                                <h4 style="clear: none;font-size: 1em;"><a href="<?php echo esc_url(get_permalink($post->ID))?>"><?php echo $post->post_title ?></a></h4>
                                <span class="price"><?php echo fr_the_price( $post->ID ); ?></span>
                                <div class="dotted-bg"></div>
                                <p><?php esc_html_e( ( strlen( $post->post_content ) <= 50 ) ? $post->post_content : ( substr( $post->post_content, 0, 50 ) . '...' ), FlexRestaurants()->app->domain ) ?></p>
                            </div>
                        </div>
						
						<?php
						echo apply_filters( 'single_menu_layout', $single );
						do_action( 'after_show_single_menu', $post->ID );
					
					endforeach;
					
					do_action( 'after_archive_menus' );
				?>
            </div>
        </div>
    </div>
</section>
