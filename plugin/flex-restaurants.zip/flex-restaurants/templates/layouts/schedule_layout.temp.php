<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 24/5/2017
	 * Time: 10:14 PM
	 */
?>
<style>
    .text-center {
        text-align: center;
    }
    
    .schedule-items {
    
    }
    
    .schedule-items .items-header {
        margin: 80px 0 40px;
    }
    
    .schedule-items .items-header:after {
        content: "";
        display: block;
        position: relative;
        height: 3px;
        width: 113px;
        background-color: #f9c56a;
        margin: 0px auto;
    }
    
    .schedule-items .items-header h1 {
    
    }
    .schedule-items .items-body {
    
    }
    
    .schedule-items .items-body .items {
    
    }
    
    .schedule-items .items-body .items .slider {
    
    }
    
    .schedule-items .items-body .items .slider .item {
        width: 70%;
        margin: auto;
        position: relative;
    }
    
    .schedule-items .items-body .items .slider .item .item-thumbnail {
        overflow: hidden;
        width: 35%;
        float: left;
    }
    
    .schedule-items .items-body .items .slider .item .item-thumbnail .image {
        height: 200px;
        background-size: cover !important;
        transition: 0.4s;
    }
    
    .schedule-items .items-body .items .slider .item .item-thumbnail:hover .image {
        transform: scale(1.1);
        transition: 0.4s;
    }
    
    .schedule-items .items-body .items .slider .item .item-body {
        width: 65%;
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        padding-left: 20px;
    }
    
    .schedule-items .items-body .items .slider .item .item-body .item-title {
    
    }
    
    .schedule-items .items-body .items .slider .item .item-body .item-title h1 {
        opacity: 1 !important;
    }
    
    .schedule-items .items-body .items .slider .item .item-body .item-title h1 a {
    
    }
    
    .schedule-items .items-body .items .slider .item .item-body .item-content {
    
    }
    
    .schedule-items .items-body .items .slider .item .item-body .item-price {
    
    }
</style>
<section class="section bg-light">
    <div class="container">
        <h1 class="text-center mb-6">Special Menus</h1>
        <div class="carousel" data-slick='{"dots": true}'>
            <!-- Special Offer -->
            <?php foreach ( $posts as $post ): ?>
                <div class="special-offer">
                    <img src="<?php echo get_the_post_thumbnail_url( $post->ID, 'full' ) ?>" alt="<?php echo $post->post_title ?>" class="special-offer-image">
                    <div class="special-offer-content">
                        <h2 class="mb-2"><a href="<?php echo esc_url( get_permalink( $post->ID ) ) ?>"><?php echo $post->post_title ?></a></h2>
                        <h5 class="text-muted mb-5"><?php esc_html_e( ( strlen( $post->post_content ) <= 50 ) ? $post->post_content : ( substr( $post->post_content, 0, 50 ) . '...' ), FlexRestaurants()->app->domain ) ?></h5>
                        <ul class="list-check text-lg mb-0">
                            <li><?php fr_the_price( $post->ID, false ) ?></li>
                        </ul>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</section>