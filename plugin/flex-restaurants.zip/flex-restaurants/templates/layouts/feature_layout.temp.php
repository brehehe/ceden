<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 24/5/2017
	 * Time: 10:14 PM
	 */
?>
<section class="section bg-light feature_menus">
    <div class="container">
        <div class="menus-header wow fadeInDown">
            <h1 class="text-center">OUR FEATURES
                <small>Little things make us best</small>
            </h1>
        </div>
        <div class="wow fadeInUp">
            <div class="feature-slider">
                <ul class="owl-carousel items" style="margin:0px">
                    <?php foreach ( $posts as $post ): ?>
                        <li class="item">
                            <div class="item-thumbnail">
                                <div class="image" style="background: url(<?php echo get_the_post_thumbnail_url( $post->ID, 'full' ) ?>) no-repeat center;"></div>
                            </div>
                            <div class="item-body">
                                <div class="item-title">
                                    <h1>
                                        <a href="<?php echo esc_url( get_permalink( $post->ID ) ) ?>"><?php echo $post->post_title ?></a>
                                    </h1>
                                </div>
                                <p class="item-content"><?php esc_html_e( ( strlen( $post->post_content ) <= 50 ) ? $post->post_content : ( substr( $post->post_content, 0, 50 ) . '...' ), FlexRestaurants()->app->domain ) ?></p>
                                <p class="item-price"><?php echo fr_the_price( $post->ID ) ?></p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</section>

