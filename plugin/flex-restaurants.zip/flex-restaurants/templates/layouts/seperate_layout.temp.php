<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 19/5/2017
	 * Time: 2:54 PM
	 */

?>
<style>
    .menus {
        width: 100%;
    }
    
    .menus .menus-container {
        width: 90%;
        margin: auto;
    }
    
    .menus .menus-container .menu-categories {
    
    }
    
    .menus .menus-container .menu-categories {
        text-align: center;
        padding-bottom: 20px;
    }
    
    .menus .menus-container .menu-categories h1 {
        font-size: 5rem;
        font-weight: 400;
    }
    
    .menus .menus-container .category {
    }
    
    .menus .menus-container .category .menu-category {
        cursor: pointer;
    }
    
    .menu-category {
    
    }
    
    .menus .menus-container .category .menu-category .menu-title {
        background-size: cover !important;
        background-position: center !important;
        background-color: rgba(16, 32, 53, 0.5);
        position: relative;
        height: 25vh;
        padding: 20px;
        -webkit-transition: all 0.4s;
        -moz-transition: all 0.4s;
        -ms-transition: all 0.4s;
        -o-transition: all 0.4s;
        transition: all 0.4s;
    }
    
    .menus .menus-container .category .menu-category .menu-title:after {
        content: '';
        width: 100%;
        height: 100%;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.5), transparent);
        position: absolute;
        top: 0;
        left: 0;
    }
    
    .menus .menus-container .category .menu-category .menu-title h1 {
        position: relative;
        color: #ffffff;
        font-size: 5rem;
        font-weight: 400;
        top: 40%;
        z-index: 2;
        padding-left: 3rem;
        text-align: left;
    }
    
    .menus .menus-container .category .menu-category .menu-title h1:after {
        position: absolute;
        right: 3rem;
        font-family: 'themify';
        content: "\e64b";
        display: inline-block;
        font-size: 5rem;
        opacity: .5;
        z-index: 2;
        -webkit-transition: all .4s ease-out;
        -moz-transition: all .4s ease-out;
        -o-transition: all .4s ease-out;
        transition: all 0.4s ease-out;
    }
    
    .menus .menus-container .category {
        border: 1px solid rgba(220, 220, 220, 0.4);
        margin-bottom: 30px;
    }
    
    .menus .menus-container .category.active .menu-category .menu-title h1:after {
        transition: all .4s;
        -webkit-transform: rotateX(180deg);
        -moz-transform: rotateX(180deg);
        -ms-transform: rotateX(180deg);
        -o-transform: rotateX(180deg);
        transform: rotateX(180deg);
    }
    
    .menus .menus-container .category.active .menu-category .menu-title {
        height: 35vh;
        -webkit-transition: all 0.4s;
        -moz-transition: all 0.4s;
        -ms-transition: all 0.4s;
        -o-transition: all 0.4s;
        transition: all 0.4s;
    }
    
    .menus .menus-container .category .menu-items {
        padding: 0 10px;
        -webkit-transition: all .4s ease-out;
        -moz-transition: all .4s ease-out;
        -o-transition: all .4s ease-out;
        transition: all 0.4s ease-out;
        display: none;
    }
    
    .menus .menus-container .category.active .menu-items {
        -webkit-transition: all .4s ease-out;
        -moz-transition: all .4s ease-out;
        -o-transition: all .4s ease-out;
        transition: all 0.4s ease-out;
        display: block;
    }
    
    .menus .menus-container .menu-items .menu-item {
        width: 33.3333333333333333333%;
        float: left;
        padding: 20px 10px;
    }
    
    @media screen and (max-width: 400px){
        .menus .menus-container .menu-items .menu-item {
            width:100%;
        }
    }
    
    .menus .menus-container .menu-items .menu-item .item-thumbnail {
        overflow: hidden;
    }
    
    .menus .menus-container .menu-items .menu-item .item-thumbnail .image {
        background-size: cover !important;
        height: 200px;
        -webkit-transition: all 0.4s;
        -moz-transition: all 0.4s;
        -ms-transition: all 0.4s;
        -o-transition: all 0.4s;
        transition: all 0.4s;
    }
    
    .menus .menus-container .menu-items .menu-item .item-thumbnail .image:hover {
        -webkit-transform: scale(1.1);
        -moz-transform: scale(1.1);
        -ms-transform: scale(1.1);
        -o-transform: scale(1.1);
        transform: scale(1.1);
        -webkit-transition: all 0.4s;
        -moz-transition: all 0.4s;
        -ms-transition: all 0.4s;
        -o-transition: all 0.4s;
        transition: all 0.4s;
    }
    
    .menus .menus-container .menu-items .menu-item .item-title {
        font-weight: 500;
        padding-top: 10px;
        font-size: 1.6rem;
        text-transform: capitalize;
    }
    
    .menus .menus-container .menu-items .menu-item .item-content {
        color: #636363;
        font-size: 1.2rem;
        text-transform: capitalize;
    }
    
    .menus .menus-container .menu-items .menu-item .item-price {
        margin-top: 20px;
    }
    
    .menus .menus-container .menu-items .menu-item .item-price .price {
        color: #636363;
    }
    
    .menus .menus-container .menu-items .menu-item .item-price .price .tag {
        color: #ccc;
    }
</style>

<div class="page-content">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-md-12">
                <?php foreach ( $body as $data ):
                    $term = $data['term'];
                    $term_config = $data['term_config'];
                    ?>
                    <div id="<?php esc_html_e( $term->slug ) ?>" class="menu-category">
                        <div class="menu-category-title">
                            <div class="bg-image"><img src="<?php echo wp_get_attachment_url( $term_config['background'], 'full' ) ?>" alt=""></div>
                            <h2 class="title"><?php esc_html_e( $term->name ) ?></h2>
                            <p class="description"><?php esc_html_e( stripcslashes( $term->description ) ) ?></p>
                        </div>

                        <div class="menu-category-content padded">
                            <div class="row gutters-sm flex-content">
                                <?php foreach ( $data['posts'] as $post ): ?>
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 flex-item">
                                        <!-- Menu Item -->
                                        <div class="menu-item menu-grid-item">
                                            <div class="image-menu" style="">
                                                <img src="<?php echo esc_url( get_the_post_thumbnail_url( $post->ID, 'full' ) ) ?>" style="width:100%" alt="">
                                            </div>
                                            <h6 class="mb-0"><a href="<?php echo esc_url( get_permalink( $post->ID ) ) ?>" target="_blank"><?php echo $post->post_title ?></a></h6>
                                            <span class="text-muted text-sm"><?php esc_html_e( ( strlen( $post->post_content ) <= 50 ) ? $post->post_content : ( substr( $post->post_content, 0, 50 ) . '...' ), FlexRestaurants()->app->domain ) ?></span>
                                            <div class="row align-items-center mt-4">
                                                <div class="col-sm-6"><span class="text-md mr-4"><span class="text-muted">from </span> <?php echo fr_the_price( $post->ID ); ?></span></div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<script>
    jQuery(document).ready(function ($) {
        $('.menu-category').click(function (event) {
            event.preventDefault();
            $(this).parent().toggleClass('active');
        })
    });
</script>