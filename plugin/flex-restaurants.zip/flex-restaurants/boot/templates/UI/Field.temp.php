<div class="row clearfix">
	<div class="col-lg-2 col-md-2 col-sm-3 col-xs-3 form-control-label">
		<label class="custom_label"><?php echo isset( $label ) ? $label : ''; ?></label>
	</div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-9">
		<?php echo isset( $content ) ? $content : ''; ?>
	</div>
</div>