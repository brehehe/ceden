<input name="<?php echo isset($name) ? $name : ''; ?>" type="radio" id="<?php echo isset($id) ? id : ''; ?>"
       class="<?php echo isset($class) ? $class : ''; ?>"/>
<label for="<?php echo isset($id) ? id : ''; ?>"><?php echo isset($label) ? $label : ''; ?></label>