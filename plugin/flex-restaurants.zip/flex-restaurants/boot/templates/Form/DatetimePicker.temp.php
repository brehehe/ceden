<div class="form-group">
	<div class="form-line">
		<input id="<?php echo isset( $id ) ? $id : ''; ?>" name="<?php echo isset( $name ) ? $name : ''; ?>" type="text"
		       class="form-control <?php echo isset( $class ) ? $class : 'datepicker'; ?>"
		       placeholder="<?php echo isset( $placeholder ) ? $placeholder : 'Please choose a date...'; ?>">
	</div>
</div>