<div class='col-xs-12 col-sm-3 col-md-3 col-lg-3 form-control-label'>
	<label><?php echo isset( $content ) ? $content : 'Not found content'; ?></label></div>