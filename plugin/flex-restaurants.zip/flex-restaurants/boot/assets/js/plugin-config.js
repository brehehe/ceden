
if (plugin_config.dev_mode === false) {
	console.log = function () {};
}

