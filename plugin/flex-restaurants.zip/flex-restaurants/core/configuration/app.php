<?php
FlexRestaurants()->app = (object)array(
    'slug_post_type'     => 'flexrestaurants',
    'setting_page_slug'  => 'fr-setting-page',
    'schedule_page_slug' => 'fr-schedule-page',
    'slug_cat_types'     => 'flexCategoriesType',
    'domain'             => 'flex-restaurants'
);