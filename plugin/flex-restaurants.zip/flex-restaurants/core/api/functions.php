<?php

if (!function_exists('fr_get_schedule')) {
    /**
     * @return null|WP_Query
     */
    function fr_get_schedule()
    {
        $schedules = get_option(FlexRestaurants()->app->schedule_page_slug, '');
        if (!empty($schedules)) {
            $schedules = json_decode($schedules, true);

            $current_time = new DateTime();
            $current_time = $current_time->setTime(0, 0, 0);
            $current_time = $current_time->getTimestamp();
            $ids          = array();
            foreach ($schedules as $schedule) {
                if (strtotime($schedule['from']) <= $current_time && strtotime($schedule['to']) >= $current_time) {
                    $ids = $schedule['post'];
                    break;
                }
            }
            if (!empty($ids)) {
                $ids  = array_unique($ids);
                $args = array(
                    'post__in'    => $ids,
                    'post_type'   => 'flexrestaurants',
                    'post_status' => 'publish',
                );
                $wp = new WP_Query($args);
                if (!is_wp_error($wp)) {
                    return $wp->posts;
                }
            }
        }

        return array();
    }
}

if (!function_exists('fr_get_page_menu')) {
    /**
     * @param array $atts
     *
     * @return array|bool
     */
    function fr_get_page_menu($atts = array())
    {
        // array(
        //     'taxonomies' => array(
        //         "kitchen" => array(),
        //         "bar" => array()
        //     ),
        //     'post_per_page' => 11,
        // )
        if (!isset($atts['taxonomies']) || empty($atts['taxonomies'])) {
            echo "Eror";

            return false;
        }
        if (get_query_var('term', false)) {
            $current_term = get_query_var('term');
        }
        if (get_query_var('taxonomy', false)) {
            $current_taxonomy = get_query_var('term');
        }
        $alltax = array();
        if (isset($atts['taxonomies'])) {
            $taxonomies = $atts['taxonomies'];
            foreach ($taxonomies as $key => $allterms) {
                $taxonomy = $key;
                $temp     = get_taxonomy($taxonomy, true);
                $rewrite  = $temp->rewrite;
                $tax      = array(
                    'label' => $temp->label,
                    'slug'  => $rewrite['slug'],
                );
                $terms = array();
                if (!empty($allterms)) {
                    foreach ($allterms as $slug) {
                        $temp = get_term_by('slug', $slug, $taxonomy);
                        if (!$temp === false) {
                            $temp->actived = "";
                            if ($slug == $current_term) {
                                $temp->actived = "active";
                            }
                            $terms[] = $temp;
                        }
                    }
                } else {
                    $terms = get_terms(array(
                        'taxonomy'   => $taxonomy,
                        'hide_empty' => false,
                    ));
                    foreach ($terms as $term) {
                        $term->actived = "";
                        if ($term->slug === $current_term) {
                            $term->actived = "active";
                        }
                    }
                }
                $tax['terms'] = $terms;
                $alltax[]     = $tax;
            }
        }
        $tax_query = array();
        //[get_posts taxonomies='a=x,y,z;b=x,y,z;c' posts_per_page = 10 author = 1]
        if (!get_query_var('taxonomy', false) === false) {
            $get_tax   = get_query_var('taxonomy');
            $get_terms = array();
            if (!get_query_var('term', false) === false) {
                $get_terms = array(get_query_var('term'));
            } else {
                $terms = get_terms(array(
                    'taxonomy'   => $get_tax,
                    'hide_empty' => false,
                ));

                foreach ($terms as $t => $term) {
                    $get_terms[] = $term->slug;
                }
            }
            $query = array(
                'taxonomy'         => $get_tax,
                'include_children' => true,
                'operator'         => 'IN',
                'field'            => 'slug',
                'terms'            => $get_terms,
            );
            $tax_query[] = $query;

        } elseif (isset($atts['taxonomies'])) {
            $tax_query['relation'] = 'OR';
            foreach ($taxonomies as $key => $allterms) {
                $tax       = $key;
                $get_terms = array();
                if (!empty($allterms)) {
                    $get_terms = $allterms;
                } else {
                    $terms = get_terms(array(
                        'taxonomy'   => $tax,
                        'hide_empty' => false,
                    ));
                    foreach ($terms as $t => $term) {
                        $get_terms[] = $term->slug;
                    }
                }
                $query = array(
                    'taxonomy'         => $tax,
                    'include_children' => true,
                    'operator'         => 'IN',
                    'field'            => 'slug',
                    'terms'            => $get_terms,
                );
                $tax_query[] = $query;
            }
            unset($atts['taxonomies']);
        }
        $args = array(
            'post_type'      => ['flexrestaurants'],
            'post_status'    => 'publish',
            'posts_per_page' => 10,
            'nopaging'       => false,
            'paged'          => get_query_var('paged', 1),
            'tax_query'      => $tax_query,
        );
        foreach ($atts as $key => $attr) {
            $args[$key] = $attr;
        }
        $wp = new WP_Query($args);

        // var_dump($wp);
        return array('taxonomies' => $alltax, 'data' => $wp);
    }
}

if (!function_exists('fr_get_categories')) {
    /**
     * @return mixed|void
     */
    function fr_get_categories()
    {
        $options = get_option('fr_taxonomies', array());

        foreach ($options as $key => $tax) {
            $terms = get_terms(array(
                'taxonomy'   => $tax['slug'],
                'hide_empty' => false,
            ));
            $options[$key]['terms'] = $terms;
        }

        return $options;
    }
}

if (!function_exists('fr_get_currency')) {
    /**
     * @return array
     */
    function fr_get_currency()
    {
        $option           = get_option('fr-setting-page', array());
        $currency         = 'USD';
        $currency_char    = '$';
        $currency_country = '($) United States Dollar';
        if (isset($option['currency']) && !empty($option['currency'])) {
            $currency = $option['currency'];
        }
        if (isset(FlexRestaurants()->currency_character[$currency]) &&
            isset(FlexRestaurants()->currency[$currency]) &&
            !empty(FlexRestaurants()->currency_character[$currency]) &&
            !empty(FlexRestaurants()->currency[$currency])
        ) {

            $currency_char    = FlexRestaurants()->currency_character[$currency];
            $currency_country = FlexRestaurants()->currency[$currency];
        } else {
            $currency = 'USD';
        }

        return array(
            'currency'  => $currency,
            'character' => $currency_char,
            'country'   => $currency_country,
        );

    }
}

if (!function_exists('fr_convert_time')) {
    /**
     * @param $date
     *
     * @return false|string
     */
    function fr_convert_time($date)
    {
        $format_date = get_option("date_format", 'F j, Y g:i a');
        if (is_numeric($date)) {
            $time_convert = date($format_date, $date);
        } else {
            $time_convert = date($format_date, strtotime($date));
        }

        return $time_convert;
    }
}

if (!function_exists('fr_get_posts')) {
    /**
     * @param       $limit
     * @param       $order
     * @param       $orderby
     * @param array $atts
     *
     * @return array
     */
    function fr_get_posts($limit = -1, $orderby = "date", $order = "ASC", $atts = array())
    {
        $args = array(
            'post_type'      => 'flexrestaurants',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'orderby'        => $orderby,
            'order'          => $order,
        );
        $args = array_merge($args, $atts);
        $data = new WP_Query($args);
        if ($data->have_posts()) {
            return $data->posts;
        }

        return array();
    }
}

if (!function_exists('fr_get_posts_by_tax')) {
    /**
     * @param        $taxonomy
     * @param array  $terms
     * @param int    $limit
     * @param string $type
     * @param string $orderby
     * @param string $order
     *
     * @return array
     */
    function fr_get_posts_by_tax($taxonomy = "", $terms = array(), $limit = -1, $type = 'all', $orderby = 'date', $order = 'asc', $atts = array())
    {
        if ($taxonomy == "") {
            return array(
                'infor' => array(),
                'body'  => array(
                    'posts' => fr_get_posts($limit, $orderby, $order, $atts),
                ),
            );
        }
        if (empty($terms)) {
            $terms = get_terms(array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'orderby'    => 'id',
                'order'      => 'ASC',
            ));
        } else {
            $terms = get_terms(array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'orderby'    => 'id',
                'order'      => 'ASC',
                'slug'       => $terms,
            ));
        }
        $data = array();
        if ($type == 'seperate') {
            foreach ($terms as $term) {
                $args = array(
                    'post_type'      => 'flexrestaurants',
                    'post_status'    => 'publish',
                    'tax_query'      => array(
                        'relation' => 'OR',
                        array(
                            'taxonomy' => $taxonomy,
                            'field'    => 'slug',
                            'terms'    => array($term->slug),
                            'operator' => 'IN',
                        ),
                    ),
                    'posts_per_page' => $limit,
                    'orderby'        => $orderby,
                    'order'          => $order,
                );
                $args      = array_merge($args, $atts);
                $posts     = new WP_Query($args);
                $term_meta = fr_get_term_meta($term->term_id);
                $temps     = array(
                    'term'        => $term,
                    'posts'       => $posts->posts,
                    'post_count'  => $posts->post_count,
                    'term_config' => $term_meta,
                );
                $data[] = $temps;
            }
        } elseif ($type == "shuffle") {
            $temp = array();
            foreach ($terms as $term) {
                $temp[] = $term->term_id;
            }
            $args = array(
                'post_type'      => 'flexrestaurants',
                'post_status'    => 'publish',
                'posts_per_page' => $limit,
                'tax_query'      => array(
                    'relation' => 'OR',
                    array(
                        'taxonomy' => $taxonomy,
                        'field'    => 'id',
                        'terms'    => $temp,
                        'operator' => 'IN',
                    ),
                ),
                'orderby'        => $orderby,
                'order'          => $order,
            );
            $args  = array_merge($args, $atts);
            $posts = new WP_Query($args);

            $data['posts'] = $posts->posts;
        } else {
            $temp = array();
            foreach ($terms as $term) {
                $temp[] = $term->term_id;
            }
            $args = array(
                'post_type'      => 'flexrestaurants',
                'post_status'    => 'publish',
                'tax_query'      => array(
                    'relation' => 'AND',
                    array(
                        'taxonomy' => $taxonomy,
                        'field'    => 'id',
                        'terms'    => $temp,
                        'operator' => 'IN',
                    ),
                ),
                'posts_per_page' => $limit,
                'orderby'        => $orderby,
                'order'          => $order,
            );
            $args          = array_merge($args, $atts);
            $posts         = new WP_Query($args);
            $data['posts'] = $posts->posts;
        }
        $taxonomy          = fr_get_tax_by($taxonomy);
        $taxonomy['terms'] = $terms;
        $result            = array(
            'infor' => $taxonomy,
            'body'  => $data,
        );

        return $result;
    }
}

if (!function_exists('fr_get_posts_by_taxs')) {
    function fr_get_posts_by_taxs($taxonomies, $relation = 'OR', $limit = null, $orderby = 'date', $order = 'asc')
    {
        if (!is_array($taxonomies)) {
            return array();
        } else {
            $tax_query             = array();
            $tax_query['relation'] = $relation;
            foreach ($taxonomies as $taxonomy) {
                if (!isset($taxonomy['terms'])) {
                    $terms = get_terms(array(
                        'taxonomy'   => $taxonomy['taxonomy'],
                        'hide_empty' => false,
                    ));
                    foreach ($terms as $term) {
                        $taxonomy['terms'][] = $term->slug;
                    }
                }
                $tax_query[] = array(
                    'taxonomy' => $taxonomy['taxonomy'],
                    'field'    => 'slug',
                    'terms'    => $taxonomy['terms'],
                    'operator' => 'IN',
                );
            }
            $args = array(
                'post_type'   => ['flexrestaurants'],
                'post_status' => 'publish',
                'tax_query'   => $tax_query,
                'orderby'     => $orderby,
                'order'       => $order,
            );
            if (!empty($limit)) {
                $args['nopaging']       = false;
                $args['posts_per_page'] = $limit;
            }
            $posts = new WP_Query($args);
            if (!is_wp_error($posts)) {
                $data = $posts->posts;

                return $data;
            }

            return array();
        }
    }
}

if (!function_exists('fr_get_tax_by')) {
    /**
     * @param      $tax_value
     * @param null $limit
     * @param int  $start
     */
    function fr_get_tax_by($tax_value, $limit = null, $start = 0)
    {
        $menus_type = get_option('fr_taxonomies', array());
        foreach ($menus_type as $value) {
            if (array_search($tax_value, $value) !== false) {
                $value['terms'] = fr_get_terms_by_tax($value['slug'], $limit, $start);

                return $value;
            }
        }

        return;
    }
}

if (!function_exists('fr_get_terms_by_tax')) {
    /**
     * @param      $taxonomy
     * @param null $limit
     * @param int  $offset
     *
     * @return array|int|void|WP_Error
     */
    function fr_get_terms_by_tax($taxonomy, $limit = null, $offset = 0)
    {
        $args = array(
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'offset'     => $offset,
            'orderby'    => 'id',
            'order'      => 'asc',
        );
        if ($limit !== null) {
            $args['number'] = $limit;
        }

        $terms = get_terms($args);
        if (!is_wp_error($terms)) {
            return $terms;
        } else {
            return;
        }
    }
}

if (!function_exists('fr_get_term_meta')) {
    /**
     * @param $term_id
     *
     * @return mixed|void
     */
    function fr_get_term_meta($term_id)
    {
        $term_meta = array(
            'layout'     => get_term_meta($term_id, 'layout', true),
            'background' => get_term_meta($term_id, 'background', true),
        );

        return $term_meta;
    }
}

if (!function_exists('fr_get_posts_by_term')) {
    /**
     * @param      $taxonomy
     * @param      $term_slug
     * @param null $limit
     *
     * @return array|void
     */
    function fr_get_posts_by_term($taxonomy, $term_slug, $limit = null, $atts = array())
    {
        if ($limit == null) {
            $limit = 10;
        }
        $args = array(
            'post_type'      => ['flexrestaurants'],
            'post_status'    => 'publish',
            'tax_query'      => array(
                'relation' => 'AND',
                array(
                    'taxonomy' => $taxonomy,
                    'field'    => 'slug',
                    'terms'    => $term_slug,
                ),
            ),
            'posts_per_page' => $limit,
        );
        $args  = array_merge($args, $atts);
        $posts = new WP_Query($args);
        if (!is_wp_error($posts)) {
            return $posts->posts;
        } else {
            return;
        }
    }
}

if (!function_exists('fr_get_post_meta')) {
    /**
     * @param $post_id
     *
     * @return mixed
     */
    function fr_get_post_meta($post_id)
    {
        return get_post_meta($post_id);
    }
}

if (!function_exists('fr_get_taxonomies_by_post')) {
    /**
     * @param $post_id
     *
     * @return array
     */
    function fr_get_taxonomies_by_post($post_id)
    {
        $taxs = get_post_taxonomies($post_id);

        return $taxs;
    }
}

if (!function_exists('fr_get_terms_by_post')) {
    /**
     * @param $post_id
     * @param $taxonomy
     *
     * @return array|WP_Error
     */
    function fr_get_terms_by_post($post_id, $taxonomy)
    {
        $terms = wp_get_post_terms($post_id, $taxonomy);

        return $terms;
    }
}

if (!function_exists('fr_get_the_price')) {
    function fr_get_the_price($post_id, $type = 'regular')
    {
        switch ($type) {
            case 'sale':
                $price = get_post_meta($post_id, 'fs_sale_price', true);
                break;
            default:
                $price = get_post_meta($post_id, 'fs_regular_price', true);
                break;
        }
        if (empty($price)) {
            return $price;
        }
        $currency = fr_get_currency()['character'];
        $setting  = get_option('fr-setting-page', array());
        $position = (!empty($setting['fr_currency_position'])) ? $setting['fr_currency_position'] : 'left';
        switch ($position) {
            case
                "right":
                return $price . $currency;
                break;
            case "left_space":
                return $currency . ' ' . $price;
                break;
            case "right_space":
                return $price . ' ' . $currency;
                break;
            default:
                return $currency . $price;
                break;
        }
    }
}

if (!function_exists('fr_the_price')) {
    function fr_the_price($post_id = "", $single = true, $order = 'regular-sale')
    {
        if (empty($post_id)) {
            global $post;
            $post_id = $post->ID;
        }
        $current_date        = current_time(get_option("links_updated_date_format", 'F j, Y g:i a'));
        $fs_sale_price_start = get_post_meta($post_id, 'fs_sale_price_start', true);
        if (empty($fs_sale_price_start)) {
            $fs_sale_price_start = $current_date;
        } else {
            $fs_sale_price_start = date(get_option("links_updated_date_format", 'F j, Y g:i a'), strtotime($fs_sale_price_start));
        }
        $fs_sale_price_stop = get_post_meta($post_id, 'fs_sale_price_stop', true);
        if (empty($fs_sale_price_stop)) {
            $fs_sale_price_stop = date(get_option("links_updated_date_format", 'F j, Y g:i a'), (strtotime($current_date) + 86400));
        } else {
            $fs_sale_price_stop = date(get_option("links_updated_date_format", 'F j, Y g:i a'), strtotime($fs_sale_price_stop));
        }

        $sale = (($current_date >= $fs_sale_price_start) && ($current_date <= $fs_sale_price_stop)) ? true : false;

        if (!$single && $sale && !empty(fr_get_the_price($post_id, 'sale'))) {
            if ($order == 'regular-sale') {
                echo '<span><span class="regular-price" style="text-decoration: line-through;padding-right: 10px;">' . fr_get_the_price($post_id, 'regular') . '</span>' .
                '<span class="sale-price">' . fr_get_the_price($post_id, 'sale') . '</span></span>';
            } else {
                echo '<span><span class="sale-price">' . fr_get_the_price($post_id, 'sale') . '</span><span class="regular-price" style="text-decoration: line-through;padding-left: 10px;">' . fr_get_the_price($post_id, 'regular') . '</span></span>';
            }
        } else {
            echo '<span class="sale-price">' . fr_get_the_price($post_id, 'regular') . '</span>';
        }
    }
}
if (!function_exists('fr_get_shortcode_assets')) {
    function fr_get_shortcode_assets()
    {
        $css_url = FlexRestaurants()->plugin_url . 'assets/css/shortcode/';
        $js_url  = FlexRestaurants()->plugin_url . 'assets/js/shortcode/';
        return apply_filters('fr_shortcode_assets', array(
            'styles'  => array(
                //$css_url . 'theme-beige.min.css',
                $css_url . 'bootstrap.css',
                $css_url . 'slick.css',
                $css_url . 'themify-icons.css',
                $css_url . 'animsition.min.css',
                $css_url . 'animate.min.css',
                $css_url . 'styleswitcher.css',
                $css_url . 'font-awesome.min.css',
                $css_url . 'shortcode.css',
            ),
            'scripts' => array(
                $js_url . 'tether.min.js',
                $js_url . 'slick.min.js',
                $js_url . 'bootstrap.min.js',
                $js_url . 'jquery.appear.js',
                $js_url . 'jquery.localScroll.min.js',
                $js_url . 'jquery.mb.YTPlayer.min.js',
                $js_url . 'skrollr.min.js',
                $js_url . 'core.js',
            ),
        ));
    }
}
