<?php

function create_roles($name, $display, $cap = array(), $new_cap = array())
{
	$role = add_roles($name,$display,$cap);
	if (null !== $role) {
		foreach ($new_cap as $key => $value) {
			$role->add_cap($key,$value);
		}
	}
	return $role;
}

/**
 * @param $post_id
 * @param $size thumbnail | large | normal
 * @return mixed
 */
function fr_get_featured_image($post_id, $size = 'thumbnail') {
    $post_thumbnail_id = get_post_thumbnail_id($post_id);

    if ($post_thumbnail_id) {
        $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, $size);
        if(!isset($post_thumbnail_img[0]) || (isset($post_thumbnail_img[0]) && empty($post_thumbnail_img[0]))) {
            return FlexRestaurants()->plugin_url . '/images/no_image.png';
        }
        return $post_thumbnail_img[0];
    }
    return FlexRestaurants()->plugin_url . '/images/no_image.png';
}