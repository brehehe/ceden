<?php
	if ( ! class_exists( 'frSettingsPage' ) ) {
		class frSettingsPage extends fs_boot {
			public $settings_option;
			private $page_slug;
			private $page_id;
			private $post_type;
			private $domain;
			
			public function __construct() {
				global $plugin_folder_name;
				$this->init( $plugin_folder_name );
				$this->page_slug = FlexRestaurants()->app->setting_page_slug;
				$this->post_type = FlexRestaurants()->app->slug_post_type;
				$this->domain    = FlexRestaurants()->app->domain;
				$this->page_id   = $this->post_type . '_page_' . $this->page_slug;
				
				$this->settings_option = get_option( $this->page_slug );
				add_action( 'admin_menu', array( $this, 'create_menu' ) );
				add_filter( 'fs_filter_tabs/fr-setting-page', array( $this, 'general_tab' ) );
				add_filter( 'fs_filter_tabs/fr-setting-page', array( $this, 'product_tab' ) );
				add_action( 'price_types', array( $this, 'add_price_types_field' ) );
				add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			}
			
			public function enqueue_scripts() {
			
			}
			
			public function create_menu() {
				add_submenu_page( 'edit.php?post_type=' . $this->post_type, esc_html__( 'Settings', $this->domain ), esc_html__( 'Settings', $this->domain ), 'manage_options', $this->page_slug, array(
					$this,
					'setting_page'
				) );
			}
			
			/**
			 * For generate base settings page
			 * @author Nic
			 */
			public function setting_page() {
				
				$option = array(
					'page_slug'  => $this->page_slug,
					'title'      => esc_html__( 'Restaurant Settings', $this->domain ),
					'tab_class'  => '',
					'query_args' => array(
						'post_type' => $this->post_type,
						'page'      => $this->page_slug,
					),
					'textdomain' => $this->domain,
					'tabs'       => array(),
				);
				$this->generatePageSettings( $option );
				$screen = get_current_screen();
				
				if ( $screen->id === $this->page_id ) {
					wp_enqueue_style( "page_settings.css", $this->plugin_url . "assets/css/page_settings.css" );
					wp_enqueue_script( 'restaurant.settings.js', $this->plugin_url . 'assets/js/restaurant.settings.js', array( 'jquery' ), '', true );
				}
			}
			
			/**
			 * @param $tabs
			 *
			 * @return mixed
			 */
			public function general_tab( $tabs ) {
				$currency        = fr_get_currency();
				$tabs['general'] = array(
					'title'   => 'General',
					'icon'    => '',
					'actived' => true,
					'note'    => '',
					'fields'  => array(
						array(
							'type'    => 'select_search',
							'name'    => 'currency',
							'label'   => 'Currency',
							'layout'  => 'horizontal',
							'options' => FlexRestaurants()->currency,
						),
						array(
							'type'        => 'select',
							'name'        => 'fr_currency_position',
							'id'          => 'fr_currency_position',
							'description' => esc_html__( 'The position of currency is lay in after the price number, check this if you want it before the price', FlexRestaurants()->app->domain ),
							'label'       => esc_html__( 'Currency Position', $this->domain ),
							'layout'      => 'horizontal',
							'options'     => array(
								'left'        => "Left {$currency['character']}99",
								'left_space'  => "Left with space {$currency['character']} 99",
								'right'       => "Right 99{$currency['character']}",
								'right_space' => "Right with space 99 {$currency['character']}",
							)
						)
					),
				);
				
				return $tabs;
			}
			
			public function product_tab( $tabs ) {
				$tabs['products']     = array(
					'title'  => esc_html__( 'Products', $this->domain ),
					'icon'   => '',
					'note'   => '',
					'fields' => array(
						array(
							'type'   => 'custom',
							'action' => 'price_types'
						)
					)
				);
				$tabs['seo_optimize'] = array(
					'title'  => esc_html__( 'SEO & OPTIMIZATION', $this->domain ),
					'icon'   => '',
					'note'   => '',
					'fields' => array(
						array(
							'label'   => esc_html__( 'Post Type Slug Name', $this->domain ),
							'default' => $this->domain,
							'layout'  => 'horizontal',
							'name'    => 'fr_post_type_slug_name',
							'id'      => 'fr_post_type_slug_name',
						)
					)
				);
				
				return $tabs;
			}
			
			public function add_price_types_field() {
				echo $this->get_template_file__( 'admin.fields.price_types', array( 'settings_option' => get_option( $this->page_slug ) ) );
			}
		}
	}
