<?php
/**
 * User: KP
 * Date: 6/8/2017
 * Time: 09:22
 */
if (!class_exists('frTemplate')) :
    class frTemplate extends fs_boot
    {
        function __construct()
        {
            global $plugin_folder_name;
            $this->init($plugin_folder_name);
            $app = FlexRestaurants()->app;
            $this->post_type = $app->slug_post_type;
            add_filter('template_include', array($this, 'template_loader'));
            add_filter('get_the_archive_title',array($this,'custom_archive_title'));
        }
        public function custom_archive_title($title){
            $title = explode(':',$title)[1];
            return $title;
        }
        public function template_loader($template)
        {

            if (is_embed()) {
                return $template;
            }

            if (is_single() && is_singular($this->post_type)) {

                $template = $this->get_template_file_path('single-menu', array(), null, 'flexrestaurants');
                $this->enqueue_assets();
            } elseif (is_tax() && is_tax(get_object_taxonomies($this->post_type))) {
                $template = $this->get_template_file_path('archive-menu', array(), null, 'flexrestaurants');
                $this->enqueue_assets();
            } elseif (is_archive() && (is_post_type_archive($this->post_type) || is_tax(get_object_taxonomies($this->post_type)))) {
                $template = $this->get_template_file_path('archive-menu', array(), null, 'flexrestaurants');
                $this->enqueue_assets();
            }

            return $template;
        }
        public function enqueue_assets(){
            wp_enqueue_script('jquery');
       //     wp_enqueue_style('theme-beige.min.css', $this->plugin_url . 'assets/css/shortcode/theme-beige.min.css');
            wp_enqueue_style('bootstrap.css', $this->plugin_url . 'assets/css/shortcode/bootstrap.css');
            wp_enqueue_style('slick.css', $this->plugin_url . 'assets/css/shortcode/slick.css');
            wp_enqueue_style('themify-icons.css', $this->plugin_url . 'assets/css/shortcode/themify-icons.css');
            wp_enqueue_style('animsition.min.css', $this->plugin_url . 'assets/css/shortcode/animsition.min.css');
            wp_enqueue_style('animate.min.css', $this->plugin_url . 'assets/css/shortcode/animate.min.css');
            wp_enqueue_style('styleswitcher.css', $this->plugin_url . 'assets/css/shortcode/styleswitcher.css');
            wp_enqueue_style('font-awesome.min.css', $this->plugin_url . 'assets/css/shortcode/font-awesome.min.css');
            wp_enqueue_style('shortcode.css', $this->plugin_url . 'assets/css/shortcode/shortcode.css');

            wp_enqueue_script("tether.min.js", $this->plugin_url . 'assets/js/shortcode/tether.min.js', array('jquery'), '', true);
            wp_enqueue_script("slick.min.js", $this->plugin_url . 'assets/js/shortcode/slick.min.js', array('jquery'), '', true);
            wp_enqueue_script("bootstrap.min.js", $this->plugin_url . 'assets/js/shortcode/bootstrap.min.js', array('jquery'), '', true);
            wp_enqueue_script("jquery.appear.js", $this->plugin_url . 'assets/js/shortcode/jquery.appear.js', array('jquery'), '', true);
            wp_enqueue_script("jquery.localScroll.min.js", $this->plugin_url . 'assets/js/shortcode/jquery.localScroll.min.js', array('jquery'), '', true);
            wp_enqueue_script("jquery.mb.YTPlayer.min.js", $this->plugin_url . 'assets/js/shortcode/jquery.mb.YTPlayer.min.js', array('jquery'), '', true);
            wp_enqueue_script("skrollr.min.js", $this->plugin_url . 'assets/js/shortcode/skrollr.min.js', array('jquery'), '', true);
            wp_enqueue_script("core.js", $this->plugin_url . 'assets/js/shortcode/core.js', array('jquery'), '', true);
            wp_enqueue_script("styleswitcher.js", $this->plugin_url . 'assets/js/shortcode/styleswitcher.js', array('jquery'), '', true);
        }
    }
endif;