<?php
	if ( ! class_exists( 'frShortCode' ) ) {
		/**
		 *
		 */
		class frShortCode extends fs_boot {
			private $taxonomies;
			
			function __construct() {
				global $plugin_folder_name;
				$this->init( $plugin_folder_name );
				
				$this->plugin_folder = $plugin_folder_name;
				$app                 = FlexRestaurants()->app;
				$this->folder        = FlexRestaurants()->app->domain;
				
				$this->taxonomies = get_option( 'fr_taxonomies', array() );
				add_shortcode( 'get_posts', array( $this, "get_posts_callback" ) );
				
				add_shortcode( 'restaurant_menus', array( $this, "restaurants_layout" ) );
				add_filter( 'fs_shuffle_menus', array( $this, 'fs_shuffle_menus' ) );
				add_filter( 'fs_seperate_menus', array( $this, 'fs_seperate_menus' ) );
				
				add_shortcode( 'feature_menus', array( $this, "features_menus_layout" ) );
				add_filter( 'fs_feature_menus', array( $this, 'fs_feature_menus' ) );
				
				add_shortcode( 'schedule_menus', array( $this, "schedule_menus_layout" ) );
				add_filter( 'fs_schedule_menus', array( $this, 'fs_schedule_menus' ) );
			}
			
			public function restaurants_layout( $atts ) {
				if ( empty( $atts ) ) {
					$atts = array();
				}
				$atts = array_merge( array(
					'type'     => 'shuffle',
					'taxonomy' => "",
					'limit'    => - 1,
					'orderby'  => 'date',
					'order'    => 'asc'
				), $atts );
				$data = fr_get_posts_by_tax( $atts['taxonomy'], array(), $atts['limit'], $atts['type'], $atts['orderby'], $atts['order'] );
				switch ( $atts['type'] ) {
					case 'shuffle':
						$atts = array_merge( array(
							'template' => 'default_shuffle_menus',
						), $atts );
						return $this->get_layout_template__( $atts['template'], 'fs_shuffle_menus', $data );
						break;
					case "seperate":
						$atts = array_merge( array(
							'template' => 'default_seperate_menus',
						), $atts );
						return $this->get_layout_template__( $atts['template'], 'fs_seperate_menus', $data );
						break;
					default:
						break;
				}
			}
			
			public function fs_shuffle_menus( $layouts ) {
				$layouts['default_shuffle_menus'] = array(
					'name'   => 'Default Shuffle Menus',
					'dir'    => $this->plugin_folder . '.templates.layouts.shuffle_layout',
					'assets' => array(
						'styles'  => array_merge(array(
							$this->plugin_url . 'assets/css/restaurant_menus.css'
						),fr_get_shortcode_assets()['styles']),
						'scripts' => array_merge(array(
							$this->plugin_url . 'assets/js/restaurant_menus.js',
							$this->plugin_url . 'assets/plugins/wow/wow.min.js',
							$this->plugin_url . 'assets/plugins/isotope/isotope.pkgd.min.js',
						),fr_get_shortcode_assets()['scripts']),
					)
				);
				
				return $layouts;
			}
			
			public function fs_seperate_menus( $layouts ) {
				$layouts['default_seperate_menus'] = array(
					'name'   => 'Default Seperate Menus',
					'dir'    => $this->plugin_folder . '.templates.layouts.seperate_layout',
					'assets' => array(
						'styles'  => array_merge(array(
							$this->plugin_url . 'assets/fonts/themify/themify-icons.css'
						),fr_get_shortcode_assets()['styles']),
						'scripts' => array_merge(array(
//							$this->plugin_url . 'assets/js/restaurant_menus.js',
//							$this->plugin_url . 'assets/plugins/wow/wow.min.js',
//							$this->plugin_url . 'assets/plugins/isotope/isotope.pkgd.min.js',
						),fr_get_shortcode_assets()['scripts']),
					)
				);
				
				return $layouts;
			}
			
			public function features_menus_layout( $atts ) {
				if ( empty( $atts ) ) {
					$atts = array();
				}
				$atts = array_merge( array(
					'template' => "default_layout",
					'taxonomy' => "",
					'limit'    => - 1,
					'orderby'  => 'date',
					'order'    => 'asc'
				), $atts );
				$data = fr_get_posts_by_tax( $atts['taxonomy'], array(), $atts['limit'], $atts['type'], $atts['orderby'], $atts['order'] );
				
				return $this->get_layout_template__( $atts['template'], 'fs_feature_menus', array( 'posts' => $data['body']['posts'] ) );
			}
			
			public function fs_feature_menus( $layouts ) {
				$layouts['default_layout'] = array(
					'name'   => 'Default Feature Menus',
					'dir'    => $this->plugin_folder . '.templates.layouts.feature_layout',
					'assets' => array(
						'styles'  => array_merge(array(
					//		$this->plugin_url . 'assets/plugins/OwlCarousel2/assets/owl.carousel.css',
							$this->plugin_url . 'assets/css/feature_menus.css'
						),fr_get_shortcode_assets()['styles']),
						'scripts' => array_merge(array(
					//		$this->plugin_url . 'assets/plugins/OwlCarousel2/owl.carousel.js',
							$this->plugin_url . 'assets/js/feature_menu.js',
						),fr_get_shortcode_assets()['scripts']),
					)
				);
				
				return $layouts;
			}
			
			public function schedule_menus_layout( $atts ) {
				if ( empty( $atts ) ) {
					$atts = array();
				}
				$atts = array_merge( array(
					'template' => "default_layout"
				), $atts );
				$data = $data = fr_get_posts_by_tax( $atts['taxonomy'], array(), $atts['limit'], $atts['type'], $atts['orderby'], $atts['order'] );
				
				return $this->get_layout_template__( $atts['template'], 'fs_schedule_menus', array( 'posts' => $data['body']['posts'] ) );
			}
			
			public function fs_schedule_menus( $layouts ) {
				$layouts['default_layout'] = array(
					'name'   => 'Default Schedule Menus',
					'dir'    => $this->plugin_folder . '.templates.layouts.schedule_layout',
					'assets' => array(
						'styles'  => array_merge(array(
							$this->plugin_url . 'assets/plugins/OwlCarousel2/assets/owl.carousel.css',
						),fr_get_shortcode_assets()['styles']),
						'scripts' => array_merge(array(
							$this->plugin_url . 'assets/plugins/OwlCarousel2/owl.carousel.js',
							$this->plugin_url . 'assets/js/schedule_menu.js',
						),fr_get_shortcode_assets()['scripts']),
					)
				);
				
				return $layouts;
			}
			
			public function get_posts_callback( $atts ) {
				if ( isset( $atts['taxonomies'] ) && ! empty( $atts['taxonomies'] ) ) {
					$taxonomies = json_decode( $atts['taxonomies'] );
					$tax        = array();
					foreach ( $taxonomies as $key => $taxonomy ) {
						$temp = array();
						if ( ! empty( $taxonomy ) ) {
							$temp = explode( ',', $taxonomy );
						}
						$tax[ $key ] = $temp;
					}
					$atts['taxonomies'] = $tax;
					$data               = fr_get_page_menu( $atts );
					
					return $this->get_template_file__( 'front.red.menu', $data, null, 'flexrestaurants' );
				} else {
					echo "Error.";
				}
			}
			
			public function embed_scripts() {
				wp_enqueue_style( 'style.css', $this->plugin_url . 'assets/red/style.css', array(), '1.0.0' );
				wp_enqueue_script( 'custom.js', $this->plugin_url . 'assets/red/js/custom.js', array(), '', true );
				wp_enqueue_style( 'custom.css', $this->plugin_url . 'assets/red/css/custom.css', array(), '' );
				wp_enqueue_style( 'flexslider.css', $this->plugin_url . 'assets/red/css/flexslider.css', array(), '' );
			}
		}
	}