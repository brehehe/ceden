<?php
if (!class_exists('frSchedule')) {
    /**
     *
     */
    class frSchedule extends fs_boot
    {

        private $page_slug;
        private $page_id;
        private $post_type;
        private $domain;

        public function __construct()
        {
	        global $plugin_folder_name;
	        $this->init( $plugin_folder_name );
            $this->page_slug = FlexRestaurants()->app->schedule_page_slug;
            $this->post_type = FlexRestaurants()->app->slug_post_type;
            $this->domain = FlexRestaurants()->app->domain;
            $this->page_id = $this->post_type . '_page_' . $this->page_slug;

            add_action('admin_menu', array($this, 'generate_menu'));
            add_action('admin_enqueue_scripts', array($this, 'flatpickr_embed'));
            add_action('admin_enqueue_scripts', array($this, 'schedule_embed'), 1);
        }

        public function flatpickr_embed()
        {
            $screen = get_current_screen();
            if ($screen->id == $this->page_id) {
                $options = array('jquery', 'bootstrap_select', 'bootstrap', 'material_icon');

                wp_enqueue_style("flatpickr.min.css", $this->plugin_url . 'assets/plugins/flatpickr-master/dist/flatpickr.min.css');
                wp_enqueue_script("flatpickr.min.js", $this->plugin_url . 'assets/plugins/flatpickr-master/dist/flatpickr.min.js', array(), '', true);

                $this->embed_flat_UI($options);
            }
        }

        public function schedule_embed()
        {
            $screen = get_current_screen();
            if ($screen->id == $this->page_id) {
	
//	            var_dump($screen);
	            $format_date = get_option('date_format');
                wp_register_script("schedule.js", $this->plugin_url . 'assets/js/schedule.js', array('jquery'), '1.0.0', true);
                wp_localize_script('schedule.js', 'format_date', $format_date);
                wp_enqueue_script('schedule.js');
                wp_enqueue_style("schedule.css", $this->plugin_url . 'assets/css/schedule.css');
            }
        }

        public function generate_menu()
        {
            add_submenu_page('edit.php?post_type=' . $this->post_type, esc_html__('Schedule', $this->domain), esc_html__('Schedule', $this->domain), 'manage_options', $this->page_slug, array($this, 'fr_schedule_page'));
        }

        public function fr_schedule_page()
        {
            $options = get_option($this->page_slug, "");
            if (isset($_POST['submit'])) {
                if (isset($_POST['data_schedule'])) {
                    $schedule = str_replace("\\", "", $_POST['data_schedule']);
                    $options = $schedule;
                }
                update_option($this->page_slug, $options);
                $_POST['notice'] = $this->string_to_url(esc_html__('Updated Successfully!', FlexRestaurants()->app->domain), esc_html__('Schedule was updated completed.', FlexRestaurants()->app->domain), 'success');
            }

            $args = array(
                'post_type'   => ['flexrestaurants'],
                'post_status' => 'publish',
                'nopaging'    => false,
            );
            $wp = new WP_Query($args);
            $data = array(
                'null' => 'Select a menu...',
            );
            if ($wp->have_posts()) {
                while ($wp->have_posts()) {
                    $wp->the_post();
	                $data[ get_the_ID() ] = '<img src="' . esc_url( get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ) ) . '" width="50px"><span style="padding-left: 10px">'.get_the_title().'</span>';
                }
            }
            $schedules = array();
            if (!empty($options)) {
                $schedules = array_reverse(json_decode($options, true), true);
            }
            $settings = get_option('fr-setting-page', array());
            echo $this->get_template_file__('admin.schedule', array(
                'posts'     => $data,
                'schedules' => $schedules,
                'options'   => $options
            ));
            return false;
        }
    }
}
