<?php
	/*
	 *Author: Nic
	 */
	if ( ! class_exists( 'frPostType' ) ) {
		/**
		 *
		 */
		class frPostType extends fs_boot {
			public function __construct() {
				global $plugin_folder_name;
				$this->init( $plugin_folder_name );
				add_action( 'init', array( $this, 'menu_post_type' ),1 );
				
				// add_action('manage_posts_extra_tablenav', array($this, 'render_post_type_empty'));
				
				// add_filter( 'parse_query', array($this, 'filter_post_by') );
				add_action( 'admin_enqueue_scripts', array( $this, 'embed_gallery_queue' ) );
				
				add_filter( 'manage_posts_columns', array( $this, 'fr_menu_columns_head' ) );
				add_action( 'manage_posts_custom_column', array( $this, 'fr_menu_columns_content' ), 10, 2 );
				
				add_filter( 'manage_edit-' . FlexRestaurants()->app->slug_post_type . '_sortable_columns', array(
					$this,
					'fr_post_type_sortable_column'
				) );
				add_filter( 'request', array( $this, 'fr_post_type_column_ordering' ) );
				
				add_filter( 'post_row_actions', array( $this, 'add_actions' ), 10, 2 );
				add_action( 'init', array( $this, 'handle_post_status' ) );
			    add_action('init',array($this,'enqueue_shortcode_assets'));
			}
			
			function fr_post_type_column_ordering( $vars ) {
				if ( isset( $vars['orderby'] ) && 'fr_price' == $vars['orderby'] ) {
					$vars = array_merge( $vars, array( 'meta_key' => 'fr-menu-price', 'orderby' => 'meta_value' ) );
				}
				
				return $vars;
			}
			
			function fr_post_type_sortable_column( $columns ) {
				$columns['fr_price'] = 'fr_price';
				
				return $columns;
			}
			
			// ADD TWO NEW COLUMNS
			function fr_menu_columns_head( $defaults ) {
				$screen = get_current_screen();
				$title  = $defaults['title'];
				$date   = $defaults['date'];
				if ( $screen->post_type == FlexRestaurants()->app->slug_post_type ) {
					$defaults = array(
						'cb'                => '<input type="checkbox">',
						'fr_image_featured' => '<center><div class="materialize" style="color:#23527c"><i class="material-icons">image</i></div></center>',
						'title'             => $title,
						'fr_price'          => esc_html__( 'Price', FlexRestaurants()->app->domain ),
						'date'              => $date
					);
				}
				
				return $defaults;
			}
			
			function fr_menu_columns_content( $column_name, $post_ID ) {
				$screen               = get_current_screen();
				if ( $screen->post_type == FlexRestaurants()->app->slug_post_type ) {
					switch ( $column_name ) {
						case 'fr_image_featured':
							$post_featured_image = fr_get_featured_image( $post_ID, 'thumbnail' );
							?>
                            <center><img class="thumbnail"
                                         style="width:70px;height:50px;margin:0;padding:0;cursor:auto;"
                                         src="<?php echo $post_featured_image ?>"/></center> <?php
							break;
						case 'fr_price' :
							$price = get_post_meta( $post_ID, 'fs_regular_price', true );
							$currency = fr_get_currency();
							if ( ! empty( $price ) ):
								?>
                                <div class="materialize">
                                    <span class=" bg-orange btn-xs" style="padding: 1px 5px;border-radius: 2px"><?php fr_the_price($post_ID) ?></span>
                                </div>
								<?php
							else:
								?> -- <?php
							endif;
							break;
					}
				}
			}
			
			public function filter_post_by( $query ) {
				echo "<pre>";
				var_dump( $query );
				die();
			}
			
			public function menu_post_type() {
				$name    = 'flexrestaurants';
				$display = 'Menu';
				$labels  = array(
					"name"               => _x( "Restaurant", "post type general name", "flex-restaurants" ),
					"singular_name"      => _x( "Restaurant", "post type singular name", "flex-restaurants" ),
					"menu_name"          => _x( "Restaurant", "admin menu", "flex-restaurants" ),
					"name_admin_bar"     => _x( "Restaurant", "add new on admin bar", "flex-restaurants" ),
					"add_new"            => _x( "Add $display", $name, "flex-restaurants" ),
					"add_new_item"       => __( "Add New $display", "flex-restaurants" ),
					"new_item"           => __( "New $display", "flex-restaurants" ),
					"edit_item"          => __( "Edit $display", "flex-restaurants" ),
					"view_item"          => __( "View $display", "flex-restaurants" ),
					"all_items"          => __( "All $display", "flex-restaurants" ),
					"search_items"       => __( "Search $display", "flex-restaurants" ),
					"parent_item_colon"  => __( "Parent $display", "flex-restaurants" ),
					"not_found"          => __( "No foods found.", "flex-restaurants" ),
					"not_found_in_trash" => __( "No foods found in Trash.", "flex-restaurants" ),
				);
				
				$args = array(
					'labels'              => $labels,
					'description'         => __( 'Description.', 'flex-restaurants' ),
					'public'              => true,
					'publicly_queryable'  => true,
					'show_ui'             => true,
					'show_in_menu'        => true,
					'query_var'           => true,
					'rewrite'             => array( 'slug' => $name ),
					'taxonomies'          => array(),
					'capability_type'     => 'post',
					'has_archive'         => true,
					'hierarchical'        => false,
					'menu_position'       => null,
					'exclude_from_search' => false,
					'supports'            => array( 'title', 'editor', 'thumbnail' ),
					'menu_icon'           => $this->plugin_url.'images/logo_flexrestaurant.png'
				);
				
				register_post_type( $name, $args );
				do_action('flex-restaurant-post_type');
			}
			
			public function render_post_type_empty( $which ) {
				global $post_type;
				if ( $post_type == 'flexrestaurants' && 'bottom' == $which ) {
					$counts = (array) wp_count_posts( $post_type );
					unset( $counts['auto-draft'] );
					$count = array_sum( $counts );
					if ( 0 < $count ) {
						return;
					}
					echo "Null";
				}
			}
			
			function embed_gallery_queue() {
				global $typenow;
				$screen = get_current_screen();
				
				// Checking for post type
				if ( $screen->post_type == FlexRestaurants()->app->slug_post_type ) {
					$flat_UI = array(
						'jquery',
						'material_icon',
						'tags_input',
						'modal',
                        'datetimepicker'
					);
					if ( $screen->base == 'post' ) {
						$flat_UI[] = 'bootstrap_select';
						$flat_UI[] = 'bootstrap';
					}
					
					$this->embed_flat_UI( $flat_UI, true );
					if ( $screen->base == "post" ) {
						wp_enqueue_media();
						
						// Elements common
						wp_enqueue_style( "elements.post_type.css", $this->plugin_url . "/assets/css/elements.post_type.css" );
						
						// helpers
						wp_enqueue_script( "helpers.elements.js", $this->plugin_url . "/assets/js/helpers.elements.js", array(), '', true );
						wp_enqueue_script( "meta.elements.js", $this->plugin_url . "/assets/js/meta.elements.js", array(), '', true );
						
						
						// Registers and enqueues the required javascript.
						wp_register_script( 'meta-box-image', $this->plugin_url . '/assets/js/thumbnails.js', array( 'jquery' ) );
						wp_localize_script( 'meta-box-image', 'meta_image',
							array(
								'title'  => __( 'Choose or Upload an Image', 'flex-restaurants' ),
								'button' => __( 'Use this image', 'flex-restaurants' ),
							)
						);
						wp_enqueue_script( 'meta-box-image' );
						/* Single menu */

					}
				}
			}
			
			public function add_actions( $actions, $post ) {
				if ( $post->post_type == 'flexrestaurants' ) {
					if ( $post->post_status == 'pending' ) {
						$actions['publish'] = '<a href="' . add_query_arg( array(
								'publish' => 'true',
								'post_id' => $post->ID
							), remove_query_arg( 'unpublish' ) ) . '">Publish</a>';
					} elseif ( $post->post_status == 'publish' ) {
						$actions['unpublish'] = '<a href="' . add_query_arg( array(
								'unpublish' => 'true',
								'post_id'   => $post->ID
							), remove_query_arg( 'publish' ) ) . '">UnPublish</a>';
					}
				}
				
				return $actions;
			}
			
			public function handle_post_status() {
				if ( current_user_can( 'publish_posts' ) && isset( $_GET['post_type'] ) && $_GET['post_type'] == 'flexrestaurants' ) {
					if ( isset( $_GET['publish'] ) && $_GET['publish'] == "true" ) {
						wp_publish_post( $_GET['post_id'] );
					}
					if ( isset( $_GET['unpublish'] ) && $_GET['unpublish'] == "true" ) {
						wp_update_post( array(
							'ID'          => $_GET['post_id'],
							'post_status' => 'pending'
						) );
					}
				}
			}
			public function enqueue_shortcode_assets(){
			    if(!is_admin()) {
                    wp_enqueue_style('Raleway', "https://fonts.googleapis.com/css?family=Raleway:300");
                }
            }
		}
	}
