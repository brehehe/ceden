<?php
	
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 11/10/2016
	 * Time: 8:34 PM
	 */
	
	if ( ! class_exists( 'frTaxonomies' ) ) {
		
		class frTaxonomies extends fs_boot {
			public $taxonomies;
			
			public function __construct() {
				global $plugin_folder_name;
				$this->init( $plugin_folder_name );
				$this->taxonomies = get_option( 'fr_taxonomies', array() );
				add_action( 'init', array( $this, 'createTaxonomy' ),1 );
				add_action( 'admin_enqueue_scripts', array( $this, 'addTaxonomyEnqueue' ) );
				add_action( 'wp_ajax_sort_terms', array( $this, 'sort_terms' ) );
				add_filter( 'get_terms_defaults', array( $this, 'get_terms_defaults' ), 10, 1 );
			}
			
			public function get_terms_defaults( $query ) {
				if ( is_admin() ) {
				    return $query;
					$screen = get_current_screen();
					if ( $screen->base == 'edit-tags' && $screen->post_type == 'flexrestaurants' ) {
						$query['meta_key'] = 'position';
						$query['orderby']  = 'meta_value';
						$query['order']    = 'DESC';
					}
				}
				
				return $query;
			}
			
			public function sort_terms() {
				if ( isset( $_POST['data'] ) ) {
					$count = count( $_POST['data'] ) - 1;
					foreach ( $_POST['data'] as $key => $term_id ) {
						update_term_meta( $term_id, 'position', ( $count - $key ) );
					}
					die( json_encode( 1 ) );
				}
			}
			
			public function staticTaxonomy() {
				$this->taxonomies[] = array(
					'slug'         => 'fr_categories',
					'name'         => esc_html__( 'Categories', 'flexrestaurants' ),
					'show_in_menu' => true
				);
				
				$this->taxonomies[] = array(
					'slug'         => 'fr_tags',
					'name'         => esc_html__( 'Tags', 'flexrestaurants' ),
					'show_in_menu' => true,
					'type'         => 'tags'
				);
			}
			
			public function createTaxonomy() {
				if ( is_array( $this->taxonomies ) ) {
					foreach ( $this->taxonomies as $value ) {
						$isshow = false;
						if ( isset( $value['show_in_menu'] ) ) {
							switch ( $value['show_in_menu'] ) {
								case 'on':
									$isshow = true;
									break;
								case 'false':
									$isshow = false;
									break;
							}
						}
						$type = array(
							'hierarchical'  => isset( $value['type'] ) && $value['type'] == 'tags' ? false : true,
							'query_var'     => $value['slug'],
							'show_tagcloud' => true,
							'rewrite'       => array(
								'slug' => $value['slug']
							),
							'labels'        => array(
								'name'              => esc_html__( $value['name'], 'flexrestaurants' ),
								'singular_name'     => esc_html__( $value['name'], 'flexrestaurants' ),
								'edit_item'         => esc_html__( 'Edit ' . $value['name'], 'flexrestaurants' ),
								'update_item'       => esc_html__( 'Update ' . $value['name'], 'flexrestaurants' ),
								'add_new_item'      => esc_html__( 'Add New ' . $value['name'], 'flexrestaurants' ),
								'new_item_name'     => esc_html__( 'New Type ' . $value['name'], 'flexrestaurants' ),
								'all_items'         => esc_html__( 'All ' . $value['name'], 'flexrestaurants' ),
								'search_items'      => esc_html__( 'Search ' . $value['name'], 'flexrestaurants' ),
								'parent_item'       => esc_html__( 'Parent ' . $value['name'], 'flexrestaurants' ),
								'parent_item_colon' => esc_html__( 'Parent ' . $value['name'] . ':', 'flexrestaurants' ),
							),
							'show_in_menu'  => isset( $value['show_in_menu'] ) && $value['show_in_menu'] == 'on' ? true : false
							/*( ( $value['slug'] == 'fr_stores' ) || ( $value['slug'] == 'fr_coupon_type' ) || ( $value['slug'] == 'fr_categories' ) ) ? true : false*/,
						);
						register_taxonomy( $value['slug'], array( 'flexrestaurants' ), $type );
						add_action( $value['slug'] . '_add_form_fields', array( $this, 'addThumbnail' ), 10, 2 );
						add_action( $value['slug'] . '_edit_form_fields', array( $this, 'editThumbnail' ), 10, 2 );
						add_action( 'edited_term', array( $this, 'saveTermMeta' ), 10, 3 );
						add_action( 'create_term', array( $this, 'saveTermMeta' ), 10, 3 );
					}
				}
			}
			
			public function addThumbnail() {
				?>
                <div class="form-field term-description-wrap">
                    <label><?php esc_html_e( 'Layout Images', 'flexrestaurants' ) ?></label>
                    <div class="thumbnails">
                        
                        <div class="thumbnails_button materialize">
                            <a class="btn btn-success waves-effect button_thumbnail"
                               data-title="<?php esc_html_e( 'Choose or Upload Image', 'flexrestaurants' ) ?>"
                               data-button="<?php esc_html_e( 'Use this image', 'flexrestaurants' ) ?>"
                               data-multiple="true">
                                <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e( 'Add images', 'flexrestaurants' ) ?>
                            </a>
                        </div>
                        <div class="thumbnails_images_container">
                            <ul class="thumbnails_images ui-sortable">
                            
                            </ul>
                            <input type="hidden" name="layout" class="image_id" value=""/>
                        </div>
                        <div class="clearfix"></div>
                        <div class="sample" style="display:none">
                            <li class="image" data-attachment_id="">
                                <div class="picture"><img src="" alt=""></div>
                                <img src="<?php echo $this->plugin_url . 'images/close_red.png' ?>"
                                     class="remove_button" id="remove_price_type" style="">
                            </li>
                        </div>
                    </div>
                    
                    <label><?php esc_html_e( 'Background Image', 'flexrestaurants' ) ?></label>
                    <div class="thumbnails">
                        
                        <div class="thumbnails_button materialize">
                            <a class="btn btn-success waves-effect button_thumbnail"
                               data-title="<?php esc_html_e( 'Choose or Upload Image', 'flexrestaurants' ) ?>"
                               data-button="<?php esc_html_e( 'Use this image', 'flexrestaurants' ) ?>"
                               data-multiple="false">
                                <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e( 'Add images', 'flexrestaurants' ) ?>
                            </a>
                        </div>
                        <div class="thumbnails_images_container">
                            <ul class="thumbnails_images ui-sortable">
                            
                            </ul>
                            <input type="hidden" name="background" class="image_id" value=""/>
                        </div>
                        <div class="clearfix"></div>
                        <div class="sample" style="display:none">
                            <li class="image" data-attachment_id="">
                                <div class="picture"><img src="" alt=""></div>
                                <img src="<?php echo $this->plugin_url . 'images/close_red.png' ?>"
                                     class="remove_button" id="remove_price_type" style="">
                            </li>
                        </div>
                    </div>
                </div>
				<?php
			}
			
			public function editThumbnail( $term ) {
				$layout     = get_term_meta( $term->term_id, 'layout', true );
				$background = get_term_meta( $term->term_id, 'background', true );
				?>
                <tr class="form-field">
                    <td><label><?php esc_html_e( 'Layout Images', 'flexrestaurants' ) ?></label></td>
                    <td>
                        <div class="thumbnails">
                            
                            <div class="thumbnails_button materialize">
                                <a class="btn btn-success waves-effect button_thumbnail"
                                   data-title="<?php esc_html_e( 'Choose or Upload Image', 'flexrestaurants' ) ?>"
                                   data-button="<?php esc_html_e( 'Use this image', 'flexrestaurants' ) ?>"
                                   data-multiple="true">
                                    <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e( 'Add images', 'flexrestaurants' ) ?>
                                </a>
                            </div>
                            <div class="thumbnails_images_container">
                                <ul class="thumbnails_images ui-sortable">
									<?php
										$image_ids = array_filter( explode( ',', $layout ) );
										if ( ! empty( $image_ids ) ) {
											foreach ( $image_ids as $key => $id ) {
												?>
                                                <li class="image" data-attachment_id="<?php echo $id; ?>">
                                                    <div class="picture"><?php echo wp_get_attachment_image( $id, array(
															78,
															78
														) ); ?></div>
                                                    <img src="<?php echo $this->plugin_url . 'images/close_red.png' ?>"
                                                         class="remove_button" id="remove_price_type" style="">
                                                </li>
												<?php
											}
										}
									?>
                                </ul>
                                <input type="hidden" name="layout" class="image_id" value=""/>
                            </div>
                            <div class="clearfix"></div>
                            <div class="sample" style="display:none">
                                <li class="image" data-attachment_id="">
                                    <div class="picture"><img src="" alt=""></div>
                                    <img src="<?php echo $this->plugin_url . 'images/close_red.png' ?>"
                                         class="remove_button" id="remove_price_type" style="">
                                </li>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td><label><?php esc_html_e( 'Background Image', 'flexrestaurants' ) ?></label></td>
                    <td>
                        <div class="thumbnails">
                            
                            <div class="thumbnails_button materialize">
                                <a class="btn btn-success waves-effect button_thumbnail"
                                   data-title="<?php esc_html_e( 'Choose or Upload Image', 'flexrestaurants' ) ?>"
                                   data-button="<?php esc_html_e( 'Use this image', 'flexrestaurants' ) ?>"
                                   data-multiple="false">
                                    <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e( 'Add images', 'flexrestaurants' ) ?>
                                </a>
                            </div>
                            <div class="thumbnails_images_container">
                                <ul class="thumbnails_images ui-sortable">
									<?php if ( ! empty( $background ) ) { ?>
                                        <li class="image" data-attachment_id="<?php echo $background; ?>">
                                            <div class="picture"><?php echo wp_get_attachment_image( $background, array(
													78,
													78
												) ); ?></div>
                                            <img src="<?php echo flexRestaurants()->plugin_url . 'images/close_red.png' ?>"
                                                 class="remove_button" id="remove_price_type" style="">
                                        </li>
									<?php } ?>
                                </ul>
                                <input type="hidden" name="background" class="image_id" value="<?php echo $background ?>"/>
                            </div>
                            <div class="clearfix"></div>
                            <div class="sample" style="display:none">
                                <li class="image" data-attachment_id="">
                                    <div class="picture"><img src="" alt=""></div>
                                    <img src="<?php echo flexRestaurants()->plugin_url . 'images/close_red.png' ?>"
                                         class="remove_button" id="remove_price_type" style="">
                                </li>
                            </div>
                        </div>
                    </td>
                </tr>
				<?php
			}
			
			public function addTaxonomyEnqueue() {
				$screen = get_current_screen();

				foreach ( $this->taxonomies as $key => $value ) {
					if ( $screen->post_type == 'flexrestaurants' && $screen->taxonomy == $value['slug'] ) {
						$this->embed_flat_UI( array( 'jquery', 'roboto', 'material_icon', 'bootstrap' ) );
						
						wp_enqueue_media();
						wp_enqueue_script( 'fr_taxonomies.js', $this->plugin_url . '/assets/js/fr_taxonomies.js', array(), '', true );
						wp_localize_script( 'fr_taxonomies.js', 'fs_ajax', array(
							'url'    => admin_url( 'admin-ajax.php' ),
							'action' => 'sort_terms',
						) );
						wp_enqueue_script( 'jquery-ui-sortable' );
						wp_enqueue_script( 'meta-box-image', $this->plugin_url . 'assets/js/thumbnails.js', array( 'jquery' ) );
						wp_enqueue_style( 'meta-box-image', $this->plugin_url . 'assets/css/elements.post_type.css' );
						
					}
				}
			}
			
			function saveTermMeta( $term_id, $tt_id, $tax ) {
			    if(!isset( $_POST['layout'] )|| !isset($_POST['background']) )
			        return;
				$terms = get_terms( array(
					'taxonomy'   => $tax,
					'hide_empty' => false
				) );
				update_term_meta( $term_id, 'position', count( $terms ) );
				update_term_meta( $term_id, 'layout', $_POST['layout'] );
				update_term_meta( $term_id, 'background', $_POST['background'] );
			}
		}
	}