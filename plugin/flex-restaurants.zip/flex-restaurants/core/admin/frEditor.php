<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 31/5/2017
	 * Time: 9:24 AM
	 */
	if ( ! class_exists( 'frEditor' ) ) {
		class frEditor extends fs_boot {
			
			/**
			 * frEditor constructor.
			 */
			public function __construct() {
				global $plugin_folder_name;
				$this->init( $plugin_folder_name );
				add_action( 'init', array( $this, 'my_recent_posts_button' ) );
			}
			
			public function my_recent_posts_button() {
				if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
					return;
				}
				
				if ( get_user_option( 'rich_editing' ) == 'true' ) {
					add_filter( 'mce_external_plugins', array( $this, 'add_plugin' ) );
					add_filter( 'mce_buttons', array( $this, 'register_button' ) );
				}
				
			}
			
			public function add_plugin( $plugin_array ) {
				
				$categories     = fr_get_categories();
				$categories_map = array();
				foreach ( $categories as $cat ) {
					$temp             = array(
						'text'  => $cat['name'],
						'value' => $cat['slug']
					);
					$categories_map[] = $temp;
				}
				$params = array(
					'restaurant_menus' => array(
						'title'  => 'Menus Layout',
						'fields' => array(
							array(
								'label'  => 'Type',
								'name'   => 'type',
								'type'   => 'listbox',
								'values' => array(
									array( 'text' => 'Seperate', 'value' => 'seperate' ),
									array( 'text' => 'Shuffle', 'value' => 'shuffle', )
								),
								'value'  => 'shuffle',
							),
							array(
								'label'       => 'Taxonomy',
								'name'        => 'taxonomy',
								'type'        => 'listbox',
								'placeholder' => 'Enter text',
								'values'      => $categories_map
							),
							array(
								'label'       => 'Limit',
								'name'        => 'limit',
								'type'        => 'textbox',
								'placeholder' => 'Enter text',
								'value'       => '-1'
							),
							array(
								'label'       => 'Order By',
								'name'        => 'orderby',
								'type'        => 'textbox',
								'placeholder' => 'Enter text',
								'value'       => 'date'
							),
							array(
								'label'  => 'Order',
								'name'   => 'order',
								'type'   => 'listbox',
								'values' => array(
									array( 'text' => 'ASC', 'value' => 'asc' ),
									array( 'text' => 'DESC', 'value' => 'desc', )
								),
								'value'  => 'asc'
							)
						)
					),
					'feature_menus'    => array(
						'title'  => 'Feature Menus Layout',
						'fields' => array(
							array(
								'label'  => 'Taxonomy',
								'name'   => 'taxonomy',
								'type'   => 'listbox',
								'values' => $categories_map
							),
							array(
								'label'       => 'Limit',
								'name'        => 'limit',
								'type'        => 'textbox',
								'placeholder' => 'Enter text',
								'value'       => '-1'
							),
							array(
								'label'       => 'Order By',
								'name'        => 'orderby',
								'type'        => 'textbox',
								'placeholder' => 'Enter text',
								'value'       => 'date'
							),
							array(
								'label'  => 'Order',
								'name'   => 'order',
								'type'   => 'listbox',
								'values' => array(
									array( 'text' => 'ASC', 'value' => 'asc' ),
									array( 'text' => 'DESC', 'value' => 'desc', )
								),
								'value'  => 'asc'
							)
						)
					),
					'schedule_menus'   => array(
						'title' => 'Schedule Menu Layout',
					),
				);
				$params = apply_filters( 'fs-shortcode-editor', $params );
				?>
                <script>
                    var fs_restaurant_codes = <?php echo json_encode( $params )?>
                </script>
				<?php
				$plugin_array['flexrestaurants'] = $this->plugin_url . 'assets/js/wp_editor.js';
				
				return $plugin_array;
			}
			
			public function register_button( $buttons ) {
				global $typenow;
				if ( $typenow == 'page' ) {
					array_push( $buttons, "|", "flexrestaurants" );
				}
				
				return $buttons;
			}
		}
	}