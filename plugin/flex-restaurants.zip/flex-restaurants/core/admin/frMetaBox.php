<?php
	
	if ( ! class_exists( 'frMetaBox' ) ) {
		/**
		 *
		 */
		class frMetaBox extends fs_boot {
			
			function __construct() {
				global $plugin_folder_name;
				$this->init( $plugin_folder_name );
				add_action( 'add_meta_boxes', array( $this, 'gallery_metabox' ) );
				add_action( 'save_post', array( $this, 'save_gallery_metabox' ) );
				
				add_action( 'add_meta_boxes', array( $this, 'render_attribute_metabox' ) );
				add_action( 'save_post', array( $this, 'save_attribute_metabox' ) );
				
			}
			
			public function gallery_metabox() {
				add_meta_box(
					'post_gallery',
					__( 'Gallery', FlexRestaurants()->app->domain ),
					array( $this, 'render_gallery_metabox' ),
					'flexrestaurants',
					'side'
				);
			}
			
			public function render_gallery_metabox() {
				global $post;
				$image_src = '';
				
				$image_id  = get_post_meta( $post->ID, 'fr-menu-gallery', true );
				$image_ids = array_filter( explode( ',', $image_id ) );
				?>
                <div class="thumbnails">
                    <div class="thumbnails_images_container">
                        <ul class="thumbnails_images ui-sortable">
							<?php
								foreach ( $image_ids as $key => $id ) {
									?>
                                    <li class="image" data-attachment_id="<?php echo $id; ?>">
                                        <div class="picture"><?php echo wp_get_attachment_image( $id, array(
												78,
												78
											) ); ?></div>
                                        <img src="<?php echo flexRestaurants()->plugin_url . 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                                    </li>
									<?php
								}
							?>
                        </ul>
                        <input type="hidden" name="fr-menu-thumbnails" class="image_id" value="<?php echo $image_id; ?>"/>
                    </div>
                    <div class="clearfix"></div>
                    <div class="thumbnails_button materialize">
                        <center><a class="btn btn-primary waves-effect button_thumbnail" name="fr-setting-page"
                                   data-title="<?php esc_html_e( 'Choose or Upload Image', FlexRestaurants()->app->domain ) ?>"
                                   data-button="<?php esc_html_e( 'Use this image', FlexRestaurants()->app->domain ) ?>"
                                   data-multiple="true">
                                <i class="material-icons" style="top:0px;vertical-align:middle;">add_box</i> <?php esc_html_e( 'Add images', FlexRestaurants()->app->domain ) ?>
                            </a></center>
                    </div>
                    <div class="sample" style="display:none">
                        <li class="image" data-attachment_id="">
                            <div class="picture"><img src="" alt=""></div>
                            <img src="<?php echo flexRestaurants()->plugin_url . 'images/close_red.png' ?>" class="remove_button" id="remove_price_type" style="">
                        </li>
                    </div>
                </div>
				<?php
			}
			
			public function save_gallery_metabox( $post_id ) {
				if ( isset( $_POST['fr-menu-thumbnails'] ) && current_user_can( 'edit_post', $post_id ) ) {
					update_post_meta( $post_id, 'fr-menu-gallery', $_POST['fr-menu-thumbnails'] );
				}
			}
			
			public function render_attribute_metabox() {
				add_meta_box(
					'post_media',
					__( 'Settings Product', 'flex-restaurants' ),
					array( $this, 'post_attribute_display' ),
					'flexrestaurants'
				);
			}
			
			public function post_attribute_display() {
				$currency = fr_get_currency();
				global $post;
				$content              = "";
				$fs_regular_price     = get_post_meta( $post->ID, 'fs_regular_price', true );
				$fs_sale_price        = get_post_meta( $post->ID, 'fs_sale_price', true );
				$fs_sale_price_start  = get_post_meta( $post->ID, 'fs_sale_price_start', true );
				$fs_sale_price_stop   = get_post_meta( $post->ID, 'fs_sale_price_stop', true );
				$fields               = array(
					array(
						'name'  => 'fs_regular_price',
						'value' => $fs_regular_price,
						'label' => "Regular price ($currency[character])",
					),
					array(
						'name'  => 'fs_sale_price',
						'value' => $fs_sale_price,
						'label' => "Sale price ($currency[character])",
					),
					array(
						'name'  => 'fs_sale_price_start',
						'value' => $fs_sale_price_start,
						'class' => 'datetimepicker2',
						'label' => "Sale off from",
					),
					array(
						'name'  => 'fs_sale_price_stop',
						'value' => $fs_sale_price_stop,
						'class' => 'datetimepicker2',
						'label' => "Sale off to",
					),
				);
				$settings             = get_option( 'fr-setting-page', false );
				$settings['currency'] = $currency;
				$settings['post_id']  = $post->ID;
				foreach ( $fields as $f => $field ) {
					$content .= $this->get_template_file__( 'fields.layouts.horizontal.text', $field, 'boot.templates' );
				}
				$content .= $this->admin_template__( 'admin.fields.meta_price_types', $settings );
				$data = array(
					'tab_class' => '',
					'tabs'      => array(
						'general' => array(
							'actived' => true,
							'icon'    => '',
							'title'   => 'General',
							'body'    => $content
						),
					),
				
				);
				echo $this->get_template_file__( 'UI.tabs', $data, 'boot.templates' );
			}
			
			public function save_attribute_metabox( $post_id ) {
			    if( !current_user_can( 'edit_post', $post_id ) ){
			        return;
                }
			    foreach ($_POST as $name => $value){
				    if ( strpos( $name, 'fs_' ) !== false ) {
					    update_post_meta( $post_id, $name, $value );
				    }
                }
				foreach ( $_POST as $name => $value ) {
					if ( strpos( $name, 'fr_extra_' ) !== false ) {
						$meta_name = str_replace( 'fr_extra_', '', $name );
						update_post_meta( $post_id, $meta_name, $_POST[ $name ] );
					}
				}
			}
		}
	}
