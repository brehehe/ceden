<?php

if (!class_exists('frCategoriesType')) {
    class frCategoriesType extends fs_boot
    {
        public $categoriespage;
        public $addcategory;
        public $taxonomies;
        private $page_slug;
        private $page_id;
        private $post_type;
        private $domain;

        public function __construct()
        {
            global $plugin_folder_name;
            $this->init($plugin_folder_name);

            $this->page_slug = FlexRestaurants()->app->slug_cat_types;
            $this->post_type = FlexRestaurants()->app->slug_post_type;
            $this->domain = FlexRestaurants()->app->domain;
            $this->page_id = $this->post_type . '_page_' . $this->page_slug;

            add_action("admin_menu", array($this, "addMenuPage"));
            add_action('admin_enqueue_scripts', array($this, "addOptionsPageEnqueue"));
            add_action('init', array($this, 'handle_save'));
            add_action('init', array($this, 'handle_update'));
            add_action('init', array($this, 'handle_delete'));
            // Create modify page
        }

        public function set_taxonomies(array $data)
        {
            $taxonomies = array();
            foreach ($data as $tax) {
                $tax_temp = wp_parse_args(
                    $tax, array(
                        'name'         => '',
                        'slug'         => '',
                        'show_in_menu' => '',
                        'type'         => '',
                        'sort'         => '',
                        'layout'       => '',
                        'background'   => '',
                        'description'  => '',
                    )
                );
                if (empty($tax_temp['name']) || empty($tax_temp['slug']))
                    continue;
                $taxonomies[] = $tax_temp;
            }
            $this->taxonomies = $taxonomies;
            return update_option('fr_taxonomies', $taxonomies);;
        }

        public function get_taxonomies($reload = false)
        {
            if (!empty($this->taxonomies) && !$reload)
                return $this->taxonomies;
            $taxonomies_use = get_option('fr_taxonomies', false);
            if (empty($taxonomies_use)) {
                $taxes = get_taxonomies(array('object_type' => array('flexrestaurants')));
                $taxonomies_use = array();
                foreach ($taxes as $tax_slug) {
                    $taxonomy = get_taxonomy($tax_slug);
                    if (!$taxonomy instanceof WP_Taxonomy)
                        continue;
                    $taxonomies_use[] = array(
                        'name'         => $taxonomy->label,
                        'slug'         => $taxonomy->name,
                        'show_in_menu' => $taxonomy->show_in_menu,
                        'type'         => ($taxonomy->hierarchical) ? '' : 'tags',
                        'sort'         => '',
                        'layout'       => '',
                        'background'   => '',
                        'description'  => $taxonomy->description,
                    );
                }
                $this->set_taxonomies($taxonomies_use);
            }
            return $this->taxonomies = $taxonomies_use;
        }

        public function addMenuPage()
        {

            //add category page
            $this->categoriespage = add_submenu_page(
                'edit.php?post_type=' . $this->post_type,
                __('Categories Types', $this->domain),
                __('Categories Types', $this->domain),
                'manage_options',
                $this->page_slug,
                array($this, 'viewCategoriesPage')
            );

            // Update categories type
            $this->update_categoriespage = add_submenu_page(false,
                __('Update Category    ', $this->domain),
                __('Update Category', $this->domain),
                'manage_options',
                'fr_update_category',
                array($this, 'frRenderUpdateCategoryPage')
            );
        }

        public function addOptionsPageEnqueue()
        {
            $screen = get_current_screen();
            if ($screen->id == $this->categoriespage || $screen->id == $this->update_categoriespage) {
                $this->embed_flat_UI(array(
                    'jquery',
                    'roboto',
                    'material_icon',
                    'bootstrap',
                    'bootstrap_select'
                ));

                wp_enqueue_media();

                wp_enqueue_script('meta-box-image', $this->plugin_url . 'assets/js/thumbnails.js', array('jquery'));
                wp_enqueue_style('meta-box-image', $this->plugin_url . 'assets/css/elements.post_type.css');
            }
        }

        public function viewCategoriesPage()
        {
            echo $this->admin_template__('categoriestypes', array(
                'taxonomies' => $this->get_taxonomies(),
            ), 'templates.admin');

        }

        public function frRenderUpdateCategoryPage()
        {
            $taxonomies = $this->get_taxonomies();
            $id = $_GET['id'];
            if (isset($taxonomies[$id])) {
                $this->admin_template_e('editCategoriesType', array(
                    'taxonomies'       => $taxonomies,
                    'current_taxonomy' => $taxonomies[$id],
                ), 'templates.admin');
            }
        }

        public function handle_update()
        {
            $taxonomies = $this->get_taxonomies();
            if (isset($_POST['update_cat'])) {
                $id = $_GET['id'];
                $current_taxonomy = $taxonomies[$id];
                if (isset($_POST['name']) && isset($_POST['slug'])) {
                    $get_name = addslashes(stripcslashes($_POST['name']));
                    $get_slug = strtolower(addslashes(stripslashes($_POST['slug'])));
                    //$get_hierarchical = $_POST['hierarchical'];
                    $show_in_menu = false;
                    if (isset($_POST['show_in_menu'])) {
                        $show_in_menu = true;
                    }
                    $this->check_empty($get_name, $get_slug);
                    $this->check_slug($get_slug, $id);

                    $taxonomies[$id] = array(
                        'name'         => $get_name,
                        'slug'         => $get_slug,
                        'show_in_menu' => $show_in_menu,
                        'type'         => strtolower($_POST['type']),
                        'sort'         => $_POST['sort'],
                        'layout'       => $_POST['layout'],
                        'background'   => $_POST['background'],
                        'description'  => $_POST['description'],
                    );
                    $update = $this->set_taxonomies($taxonomies);
//						$update = update_option( 'fr_taxonomies', $this->taxonomies );
                    if ($update) {
                        if ($get_slug != $current_taxonomy['slug']) {
                            $args = array(
                                'hierarchical'  => isset($_POST['type']) && strtolower($_POST['type']) == 'tags' ? false : true,
                                'query_var'     => $get_slug,
                                'show_tagcloud' => true,
                                'rewrite'       => array(
                                    'slug'       => $get_slug,
                                    'with_front' => false,
                                ),
                                'labels'        => array(
                                    'name'              => esc_html__($get_name, $this->domain),
                                    'singular_name'     => esc_html__($get_name, $this->domain),
                                    'edit_item'         => esc_html__('Edit ' . $get_name, $this->domain),
                                    'update_item'       => esc_html__('Update ' . $get_name, $this->domain),
                                    'add_new_item'      => esc_html__('Add New ' . $get_name, $this->domain),
                                    'new_item_name'     => esc_html__('New Type ' . $get_name, $this->domain),
                                    'all_items'         => esc_html__('All ' . $get_name, $this->domain),
                                    'search_items'      => esc_html__('Search ' . $get_name, $this->domain),
                                    'parent_item'       => esc_html__('Parent ' . $get_name, $this->domain),
                                    'parent_item_colon' => esc_html__('Parent ' . $get_name . ':', $this->domain),
                                ),
                                'show_in_menu'  => isset($show_in_menu) && $show_in_menu == 'on' ? true : false,
                            );
                            $reg = register_taxonomy($get_slug, array('flexrestaurants'), $args);
                            if (!$reg) {
                                $terms = get_terms(array(
                                    'taxonomy'   => $current_taxonomy['slug'],
                                    'hide_empty' => false,
                                ));
                                foreach ($terms as $key => $term) {
                                    wp_insert_term($term->name, $get_slug, array(
                                        'name'        => $term->name,
                                        'slug'        => $term->slug,
                                        'description' => $term->description,
                                        'parent'      => $term->parent,
                                    ));
                                    if (isset($_POST['term_meta'])) {
                                        $t_id = $term->term_id;
                                        $term_meta = get_option("taxonomy_$t_id");
                                        $cat_keys = array_keys($_POST['term_meta']);
                                        foreach ($cat_keys as $key) {
                                            if (isset($_POST['term_meta'][$key])) {
                                                if ($key == 'thumbnail') {
                                                    $term_meta[$key] = explode(',', $_POST['term_meta'][$key]);
                                                } else {
                                                    $term_meta[$key] = $_POST['term_meta'][$key];
                                                }
                                            }
                                        }
                                        // Save the option array.
                                        update_option("taxonomy_$t_id", $term_meta);
                                    }
                                    wp_delete_term($term->term_id, $current_taxonomy['slug']);
                                }
                                unregister_taxonomy($current_taxonomy['slug']);
                            }
                        }
                        //reload tax
                        $this->get_taxonomies(true);
                        $this->redirect($this->string_to_url('Updated successfully', esc_html__('Category type was updated.', $this->domain), 'success'));
                    }
                }
            }
        }

        /**
         * TO REMOVE CATEGORY TYPE
         */
        public function handle_delete()
        {
//            var_dump(isset($_GET['page']) , $_GET['page'] == 'flexCategoriesType' , isset($_GET['action']) == 'delete' , isset($_GET['id']) , $_GET['id'] != "");
            if (is_admin()) {
                if (isset($_GET['page']) && $_GET['page'] == 'flexCategoriesType' && isset($_GET['action']) == 'delete' && isset($_GET['id']) && $_GET['id'] != "") {
                    $id = intval($_GET['id']);
                    $taxonomies = $this->get_taxonomies();
                    $current_taxonomy = $taxonomies[$id];
                    unset($taxonomies[$id]);
                    $update = $this->set_taxonomies($taxonomies);
                    if ($update) {
                        $this->taxonomies = get_option('fr_taxonomies');
                        $terms = get_terms(array(
                            'taxonomy'   => $current_taxonomy['slug'],
                            'hide_empty' => false,
                        ));
                        foreach ($terms as $key => $term) {
                            wp_delete_term($term->term_id, $current_taxonomy['slug']);
                        }
                        unregister_taxonomy($current_taxonomy['slug']);
                        $this->redirect($this->string_to_url('Delete successfully', esc_html__('Category type was deleted.', $this->domain), 'success'));
                        wp_redirect($url = add_query_arg(array(
                            'post_type' => $this->post_type,
                            'page'      => $this->page_slug,
                        ), admin_url('edit.php')));
                    }
                }
            }
        }

        /**
         * TO SAVE THE CATEGORIES TYPE
         */
        public function handle_save()
        {
            if (is_admin()) {
                if (isset($_POST['save_cat'])) {
                    if (isset($_POST['name']) && isset($_POST['slug'])) {
                        $get_name = addslashes(stripslashes($_POST['name']));
                        $get_slug = strtolower(($_POST['slug']));
                        //$get_hierarchical = $_POST['hierarchical'];
                        $show_in_menu = false;
                        if (isset($_POST['show_in_menu'])) {
                            $show_in_menu = true;
                        }
                        if ($this->check_empty($get_name, $get_slug) === false) {
                            return;
                        }
                        if ($this->check_slug($get_slug) === false) {
                            return;
                        }
                        $taxonomies = $this->get_taxonomies();
                        $post_val = wp_parse_args($_POST,array(
                            'slug'=>'',
                            'name'=>'',
                            'type'=>'',
                            'sort'=>'',
                            'layout'=>'',
                            'background'=>'',
                            'description'=>''
                        ));
                        $taxonomies[] = array(
                            'name'         => addslashes(stripslashes($post_val['name'])),
                            'slug'         => strtolower(($post_val['slug'])),
                            'show_in_menu' => $show_in_menu,
                            'type'         => strtolower($post_val['type']),
                            'sort'         => $post_val['sort'],
                            'layout'       => $post_val['layout'],
                            'background'   => $post_val['background'],
                            'description'  => $post_val['description'],
                        );
                        $update = $this->set_taxonomies($taxonomies);
                        if ($update) {
                            $this->redirect($this->string_to_url('Created successfully', esc_html__('A new category type was added.', $this->domain), 'success'));
                        }
                    }
                }
            }
        }

        public function check_slug($slug, $slug_id = null)
        {
            $action = 'Create';
            if ($slug_id !== null) {
                $action = 'Update';
            }
            if (strlen($slug) == 0 || strlen($slug) > 32) {
                $this->redirect($this->string_to_url($action . esc_html__('unsuccessfully', $this->domain), esc_html__('The slug must be between 1 and 32 characters in length.', $this->domain), 'error'));

                return false;
            }
            if (!$this->validate_('slug', $slug)) {
                $this->redirect($this->string_to_url($action . esc_html__('unsuccessfully', $this->domain), esc_html__('The slug invalid.', $this->domain), 'error'));

                return false;
            }
            $taxonomies = $this->get_taxonomies();
            if (is_array($taxonomies)) {
                if ($slug_id !== null) {
                    unset($taxonomies[$slug_id]);
                }
                foreach ($taxonomies as $key => $tax) {
                    if ($tax['slug'] == $slug) {
                        $this->redirect($this->string_to_url($action . ' unsuccessfully', esc_html__('The slug exists.', $this->domain), 'error'));

                        return false;
                    }
                }
            }

            return true;
        }

        public function check_empty($name, $slug)
        {
            if (empty($slug) && empty($name)) {
                $this->redirect($this->string_to_url('Create unsuccessfully', esc_html__('You are missing Name and Slug field.', $this->domain), 'warning'));

                return false;
            } elseif (empty($slug)) {
                $this->redirect($this->string_to_url('Create unsuccessfully', esc_html__('You are missing Slug field.', $this->domain), 'warning'));

                return false;
            } elseif (empty($name)) {
                $this->redirect($this->string_to_url('Create unsuccessfully', esc_html__('You are missing Name field.', $this->domain), 'warning'));

                return false;
            }

            return true;
        }

        public function redirect($message = null)
        {
            if ($message != null) {
                $_POST['notice'] = $message;
            }
        }
    }
}
