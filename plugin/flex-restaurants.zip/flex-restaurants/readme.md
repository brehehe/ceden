API Flex Restaurant

- fr_get_schedule() hàm trả về các menu theo lịch biểu được cài đặt sẵn trong Schedule

	input: array()

	example 

		(array(
            'taxonomies' => array(

                 "kitchen" => array(),

                 "bar" => array()

            ),//required

            'post_per_page' => 11,//query arg optional

        )) 

- fr_get_page_menu() Hàm trả về danh sách menu theo category type, terms

	input: null

- fr_get_categories() Hàm trả về tất cả các term của category type

	input: null

- fr_get_currency() Hàm trả về đơn vị tiền tệ currency

	input: null 

- fr_convert_time() Hàm trả về thời gian theo định dạng được cài đặt

	input: $time 

	example: 2017-03-18
	
- fr_get_posts_by_tax($taxonomy, $limit = null, $type = 'all', $orderby = 'date', $order = 'asc')
 
    Hàm trả về menus theo taxonomy(category type)

    input: taxonomy,limit
    
    example fr_get_menus_by_tax('date',3);

- fr_get_posts_by_taxs( $taxonomies, $relation = 'OR', $limit = null, $orderby = 'date', $order = 'asc' )
    Hàm get posts theo nhiều taxonomy
    
    
    $taxonomies = array(
        array(
            'taxonomy'  => 'tax 1',
            'terms'     => array( 'term_slug_1','term_slug_2'),
        ),
        array(
            'taxonomy   => 'tax 2'
        )
    )
    fr_get_posts_by_taxs($taxonomies,'AND')
- fr_get_tax_by($tax_value, $limit = null)

- fr_get_terms_by_tax($taxonomy,$limit=null)

- fr_get_term_meta($term_id)

- fr_get_posts_by_term($taxonomy, $term_slug, $limit = null)

- fr_get_post_meta($post_id)

- fr_get_taxonomies_by_post($post_id)

- function fr_get_terms_by_post($post_id, $taxonomy)


