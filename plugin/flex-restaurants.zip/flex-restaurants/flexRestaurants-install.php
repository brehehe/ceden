<?php
	/* Flex Extensions group */
	
	if ( isset( $flex_extensions ) ) {
		$flex_extensions[ $plugin_folder_name ] = plugin_dir_path( __FILE__ );
	} else {
		$flex_extensions = array( $plugin_folder_name => plugin_dir_path( __FILE__ ) );
	}
	add_filter('flex_restaurants_alert_required',function (){
		return null;
	});
	
// boot include
	if ( ! class_exists( 'boot' ) ) {
		reset( $flex_extensions );
		$first_key = key( $flex_extensions );
		$boot_dir  = rtrim( $flex_extensions[ $first_key ], '\\\/' ) . DIRECTORY_SEPARATOR . 'boot' . DIRECTORY_SEPARATOR . 'boot.php';
		
		include_once $boot_dir;
	}