<?php
/**
 * Created by PhpStorm.
 * User: Mạnh Ninh
 * Date: 28/3/2017
 * Time: 9:30 AM
 */
?>
<div class="fs-wrapper">
    <h2 style="font-size: 60px;text-align: center">MAKE A RESERVATION</h2>
    <form method="post">
        <div class="col-md-12">
            <div class="form-control-label text-uppercase">
                <label>Number of persons</label>
            </div>
            <div class="form-group">
                <div class="col-md-1 col-md-offset-1">
                    <input type="radio" name="fs_partysize" value="1" id="fs_partysize_1"><label for="fs_partysize_1">&nbsp;1</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="2" id="fs_partysize_2"><label for="fs_partysize_2">&nbsp;2</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="3" id="fs_partysize_3"><label for="fs_partysize_3">&nbsp;3</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="4" id="fs_partysize_4"><label for="fs_partysize_4">&nbsp;4</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="5" id="fs_partysize_5"><label for="fs_partysize_5">&nbsp;5</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="6" id="fs_partysize_6"><label for="fs_partysize_6">&nbsp;6</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="7" id="fs_partysize_7"><label for="fs_partysize_7">&nbsp;7</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="8" id="fs_partysize_8"><label for="fs_partysize_8">&nbsp;8</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="9" id="fs_partysize_9"><label for="fs_partysize_9">&nbsp;9</label>
                </div>
                <div class="col-md-1">
                    <input type="radio" name="fs_partysize" value="10" id="fs_partysize_10"><label for="fs_partysize_10">&nbsp;10+</label>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-control-label text-uppercase">
                <label for="fs_date">Date</label>
            </div>
            <div class="form-group">
                <input type="date" name="fs_date" id="fs_date" value="" placeholder="28/03/2017">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-control-label text-uppercase">
                <label for="fs_time">time</label>
            </div>
            <div class="form-group">
                <input type="time" name="fs_time" id="fs_time" value="" placeholder="8:00 AM">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-control-label text-uppercase">
                <label for="fs_name">your name</label>
            </div>
            <div class="form-group">
                <input type="text" name="fs_name" id="fs_name" value="" placeholder="David Beckham">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-control-label text-uppercase">
                <label for="fs_hone">phone number</label>
            </div>
            <div class="form-group">
                <input type="tel" name="fs_phone" id="fs_phone" value="" placeholder="">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-control-label text-uppercase">
                <label for="fs_email">email address</label>
            </div>
            <div class="form-group">
                <input type="email" name="fs_email" id="fs_email" value="" placeholder="John@example.com...">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-control-label text-uppercase">
                <label for="fs_other">special request?</label>
            </div>
            <div class="form-group">
                <textarea name="fs_message" id="fs_message" cols="30" rows="10"></textarea>
            </div>
        </div>

        <div class="fs-notice-wrapper">

        </div>

        <div class="col-md-8"><strong>
                <p class="text-uppercase">OR reserve your table by email or phone</p>
                <p>reservation@nuvo.com <span>&#9679;</span> +1(806)478 1800</strong>
        </div>
        <div class="col-md-4">
            <input type="submit" name="fs_submit" class="pull-right fs_submit" value="BOOK TABLE">
        </div>

    </form>
    <div class="success-wrapper">

    </div>
    <div class="fs-loading-wrapper">
        <div class="loading-background"></div>
        <div class="la-ball-clip-rotate-pulse la-dark la-2x loading-icon">
            <div></div>
            <div></div>
        </div>
       <!-- <div class="la-ball-clip-rotate-multiple la-dark la-2x loading-icon">
            <div></div>
            <div></div>
        </div>-->
    </div>
</div>
