<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 14/4/2017
	 * Time: 8:34 AM
	 */

?>
<div class="fs-wrapper">
    <h2 class="text-center">MAKE A RESERVATION</h2>
    <form method="post">
        <div class="col-md-5">
            <div class="form-control-label text-uppercase">
                <label for="fs_date">Date</label>
            </div>
            <div class="form-group">
                <input type="date" name="fs_date" id="fs_date" value="" placeholder="28/03/2017">
            </div>
        </div>
        <div class="col-md-5">
            <div class="form-control-label text-uppercase">
                <label for="fs_time">time</label>
            </div>
            <div class="form-group">
                <input type="time" name="fs_time" id="fs_time" value="" placeholder="8:00 AM">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-control-label text-uppercase">
                <label>Number of persons</label>
            </div>
            <div class="form-group">
                <select name="fs_partysize" id="fs_partysie">
				    <?php for ( $i = 1; $i < 10; $i ++ ): ?>
                        <option value="<?php echo $i ?>"><?php echo $i ?></option>
				    <?php endfor; ?>

                    <option value="10++">10++</option>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-control-label text-uppercase">
                <label for="fs_name">your name</label>
            </div>
            <div class="form-group">
                <input type="text" name="fs_name" id="fs_name" value="" placeholder="David Beckham">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-control-label text-uppercase">
                <label for="fs_hone">phone number</label>
            </div>
            <div class="form-group">
                <input type="tel" name="fs_phone" id="fs_phone" value="" placeholder="">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-control-label text-uppercase">
                <label for="fs_email">email address</label>
            </div>
            <div class="form-group">
                <input type="email" name="fs_email" id="fs_email" value="" placeholder="John@example.com...">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-control-label text-uppercase">
                <label for="fs_other">special request?</label>
            </div>
            <div class="form-group">
                <textarea name="fs_message" id="fs_message" cols="30" rows="10"></textarea>
            </div>
        </div>

        <div class="fs-notice-wrapper">

        </div>

        <div class="col-md-8"><strong>
                <p class="text-uppercase">OR reserve your table by email or phone</p>
                <p>reservation@nuvo.com <span>&#9679;</span> +1(806)478 1800</strong>
        </div>
        <div class="col-md-4">
            <input type="submit" name="fs_submit" class="pull-right fs_submit" value="BOOK TABLE">
        </div>

    </form>
    <div class="success-wrapper">

    </div>
    <div class="fs-loading-wrapper">
        <div class="loading-background"></div>
        <div class="la-ball-clip-rotate-pulse la-dark la-2x loading-icon">
            <div></div>
            <div></div>
        </div>
    </div>
</div>
