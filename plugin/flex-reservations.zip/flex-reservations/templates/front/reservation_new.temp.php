<?php

$form_template = fsr_get_form_template();
$fields = array_merge(fsr_get_fields_editor_data(true),fsr_get_ui_fields_editor_data(true));

?>
<style>
    .fs-wrapper p {
        filter: invert(70%);
    }

    .fs-wrapper .center {
        text-align: center;
    }

    .fs-wrapper .title {
        font-weight: bold;
        color: #e4b95b;
    }
</style>
<div class="fs-wrapper">
    <form class="fs-form" method="post">
        <input type="hidden" name="action" value="flex-reservations-submit">
        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('flex-reservations-form') ?>">
        <?php foreach ($form_template as $row): ?>
        <div class="row">
            <?php foreach ($row as $index => $cell):
                if(!array_key_exists($cell,$fields))
                    continue;
                $field = $fields[$cell];
                $col = intval( 12 / count($row));
                $class = "col-xs-12 col-sm-{$col} col-md-{$col}".($index === 0 ? " col-left" : '' );
                ?>
                <div class="<?php echo esc_attr($class) ?>">
                    <?php fsr_build_form_field_front($field); ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </form>
    <div class="success-wrapper"></div>
</div>
