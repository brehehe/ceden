<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 14/6/2017
	 * Time: 2:30 PM
	 */
	?>

<strong>Hi, admin</strong>
<p style="text-align:left">Have just got a reservation, please check to approve this reservation!</p>
<p style="text-align:left">Reservation's information:</p>
<p style="text-align:left">Name: [[name]]</p>
<p style="text-align:left">Email: [[email]]</p>
<p style="text-align:left">Date: [[date]]</p>
<p style="text-align:left">Time: [[time]]</p>
<p style="text-align:left">Number of people: [[partysize]]</p>
<p style="text-align:left">Your message: [[message]]</p>
<p></p>
<p style="text-align: left">Regards</p>
<strong><?php echo get_bloginfo('name')?></strong>

