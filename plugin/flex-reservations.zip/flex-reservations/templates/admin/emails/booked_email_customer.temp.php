<?php
	/**
	 * Created by PhpStorm.
	 * User: Nic
	 * Date: 14/6/2017
	 * Time: 2:30 PM
	 */
	?>

<strong>Hi, [[name]]</strong>
<p style="text-align:left">Thank you for your reservation</p>
<p style="text-align:left">Your reservation's information:</p>
<p style="text-align:left">Date: [[date]]</p>
<p style="text-align:left">Time: [[time]]</p>
<p style="text-align:left">Number of people: [[partysize]]</p>
<p style="text-align:left">Your message: [[message]]</p>
<p style="text-align: left">Please wait for us to approve!</p>
<br>
<p style="text-align: left">Regards</p>
<strong><?php echo get_bloginfo('name')?></strong>

