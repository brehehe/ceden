<?php
    /**
     * Created by PhpStorm.
     * User: Nic
     * Date: 2/4/2017
     * Time: 12:37 PM
     */

?>
<div class="materialize">
    <!--    <label for="name">--><?php //esc_html_e('Nom’, 'flexreservations'); ?><!--</label>-->
    <!--    <div class="input-group">-->
    <!--        <div class="form-line">-->
    <!--            --><?php //echo $this->generate_field(array('name' => 'name', 'id' => 'name', 'value'=> $data['name'])); ?>
    <!--        </div>-->
    <!--    </div>-->
    <label for="email"><?php esc_html_e('Email', FlexReservations()->app->domain); ?></label>
    <div class="input-group">
        <div class="form-line">
            <?php echo $this->generate_field(array('name' => 'fs_email', 'id' => 'fs_email', 'value'=> $data['fs_email'])); ?>
        </div>
    </div>
    <label for="phone"><?php esc_html_e('Phone number', FlexReservations()->app->domain); ?></label>
    <div class="input-group">
        <div class="form-line">
            <?php echo $this->generate_field(array('name' => 'fs_phone', 'id' => 'fs_phone', 'value'=> $data['fs_phone'])); ?>
        </div>
    </div>
    <label for="partysize"><?php esc_html_e('Number of people', FlexReservations()->app->domain); ?></label>
    <div class="input-group">
        <div class="form-line">
            <?php echo $this->generate_field(array('name' => 'fs_partysize', 'id' => 'fs_partysize', 'value'=> $data['fs_partysize'])); ?>
        </div>
    </div>
    <label for="date"><?php esc_html_e('Date', FlexReservations()->app->domain); ?></label>
    <div class="input-group">
        <div class="form-line">
            <?php echo $this->generate_field(array('name' => 'fs_date', 'id' => 'fs_date', 'value'=> $data['fs_date'])); ?>
        </div>
    </div>
    <label for="time"><?php esc_html_e('Hour', FlexReservations()->app->domain); ?></label>
    <div class="input-group">
        <div class="form-line">
            <?php echo $this->generate_field(array('name' => 'fs_time', 'id' => 'fs_time', 'value'=> $data['fs_time'], 'class'=>'time ui-timepicker-input')); ?>
        </div>
    </div>
    <label for="message"><?php esc_html_e('Message', FlexReservations()->app->domain); ?></label>
    <div class="input-group">
        <?php echo $this->generate_field(array('type' => 'textarea', 'name' => 'fs_message', 'id' => 'fs_message', 'value'=> $data['fs_message'])); ?>
    </div>
    <?php
    $ignore = ['fs_email','fs_phone','fs_partysize','fs_date','fs_time','fs_message'];
    $fields_template = fsr_get_fields_editor_data(true);
    foreach ($data as $field => $value):
        if(in_array($field,$ignore) || !array_key_exists($field,$fields_template)) continue;
    $cr_field_template = $fields_template[$field];
    $generate_data = [
        'name' => $field,
        'id' => $field,
        'value'=> $data[$field],
    ];
    if($cr_field_template['type']['value'] == 'time')
        $generate_data['class'] = 'time ui-timepicker-input';
    ?>
        <label for="<?php echo esc_attr($field) ?>"><?php echo esc_html($cr_field_template['label']['value']) ?></label>
        <div class="input-group">
            <div class="form-line">
                <?php echo $this->generate_field($generate_data); ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>