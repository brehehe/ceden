<?php
/**
 * Created by FsFlex.
 * User: VH
 * Date: 4/9/2018
 * Time: 5:19 PM
 */
wp_enqueue_script('jquery-ui-sortable');

?>
<style>
    .template-editor .btn {
        margin: 10px 10px 10px 10px !important;
    }

    .template-editor .element-card {
        width: 40%;
        background-color: #dda62f;
        color: #fff;
        font-weight: normal
    }

    .template-editor .element-card:only-child {
        width: 82%;
    }

    .template-editor .row-container {
        background-color: rgba(200, 228, 248, 0.98);
    }
</style>
<div class="templates" style="display: none">
    <?php
    ob_start();
    ?>
    <tr>
        <td class="col-lg-10 col-md-10 sortable row-container">
        </td>
        <td class="col-lg-2 col-md-2">
            <div class="btn waves-effect action-remove-row">Remove</div>
        </td>
    </tr>
    <?php
    $single_form_row_template = ob_get_clean();
    ?>
    <input class="single-template" data-name="single-form-row" type="hidden"
           value="<?php echo esc_attr($single_form_row_template) ?>">
</div>
<h3>Reservation Form</h3>
<ul class="editor-notice">
</ul>
<table id="form-template-editor" class="col-lg-12 col-md-12 materialize template-editor" border="1">
    <tr>
        <td colspan="4">
            <div class="btn waves-effect" style="width: 30%" id="editor_form-add_row">+ Add more row</div>
        </td>
    </tr>
    <tr>
        <td class="col-lg-12 col-md-12 sortable" colspan="2" style="height: 100px">
            <?php
            $cards = [];
            $ui_fields = fsr_get_ui_fields_editor_data();
            $except = ['ui_more_reservation','ui_reservation_data'];
            $special_title = [
                'ui_error_notice'=>'Error Notice (ui_error_notice)'
            ];
            foreach ($ui_fields as $field)
            {
                if(in_array($field['id']['value'],$except))
                    continue;
                if(array_key_exists($field['id']['value'],$special_title))
                    $card_title = $special_title[$field['id']['value']];
                else
                    $card_title = "{$field['content']['value']} ({$field['id']['value']})";
                $cards[] = ['title' => $card_title, 'id' => $field['id']['value'],'style'=>'background-color:#DD8768'];
            }
            $fields = fsr_get_fields_editor_data();
            foreach ($fields as $field) {
                $card_title = "{$field['label']['value']} ({$field['id']['value']})";
                $cards[] = ['title' => $card_title, 'id' => $field['id']['value']];
            }
            //echo card
            foreach ($cards as $card) {
                ?>
                <div class="btn waves-effect element-card" <?php if(!empty($card['style'])) echo 'style="'.esc_attr($card['style']).'"' ?>
                     data-name="<?php echo esc_attr($card['id']) ?>"><?php echo esc_html($card['title']) ?></div>
                <?php
            }
            ?>
        </td>
    </tr>
</table>
<h3>Reservation Success Template</h3>
<ul class="editor-notice">
</ul>
<table id="success-template-editor" class="col-lg-12 col-md-12 materialize template-editor" border="1">
    <tr>
        <td colspan="4">
            <div class="btn waves-effect" style="width: 30%" id="success-editor_form-add_row">+ Add more row</div>
        </td>
    </tr>
    <tr>
        <td class="col-lg-12 col-md-12 sortable" colspan="2" style="height: 100px">
            <?php
            $cards = [];
            $ui_fields = fsr_get_ui_fields_editor_data();
            $except = ['ui_error_notice','ui_submit'];
            $special_title = [
                'ui_reservation_data'=>'Reservation Data (ui_reservation_data)'
            ];
            foreach ($ui_fields as $field)
            {
                if(in_array($field['id']['value'],$except))
                    continue;
                if(array_key_exists($field['id']['value'],$special_title))
                    $card_title = $special_title[$field['id']['value']];
                else
                    $card_title = "{$field['content']['value']} ({$field['id']['value']})";
                $cards[] = ['title' => $card_title, 'id' => $field['id']['value'],'style'=>'background-color:#DD8768'];
            }
            //echo card
            foreach ($cards as $card) {
                ?>
                <div class="btn waves-effect element-card" <?php if(!empty($card['style'])) echo 'style="'.esc_attr($card['style']).'"' ?>
                     data-name="<?php echo esc_attr($card['id']) ?>"><?php echo esc_html($card['title']) ?></div>
                <?php
            }
            ?>
        </td>
    </tr>
</table>
<input type="hidden" name="form-template-editor-data" id="form-template-editor-data"
       value="<?php echo esc_attr(json_encode(fsr_get_form_template()));?>">
<input type="hidden" name="success-template-editor-data" id="success-template-editor-data"
       value="<?php  echo esc_attr(json_encode(fsr_get_success_form_template()));?>">
<script>
    jQuery(function ($) {
        var success_container_selector = "#success-template-editor",
            main_container_selector = "#form-template-editor"
            ,main_container = $(main_container_selector)
            , store_container = $('#form-template-editor-data')
            ,success_container = $(success_container_selector)
            ,success_store_container = $("#success-template-editor-data")
        ;
        init_data();
        init_success_form_data();
        main_container.on('click', '#editor_form-add_row', function () {
            add_rows(1);
            init_sortable();
        }).on('click','.action-remove-row:not(.disabled)',function () {
            $(this).closest('tr').remove();
            save_data();
        });
        success_container.on('click', '#success-editor_form-add_row', function () {
            success_add_rows(1);
            init_success_form_sortable();
        }).on('click','.action-remove-row:not(.disabled)',function () {
            $(this).closest('tr').remove();
            save_success_form_data();
        });
        function init_data() {
            var data = json_tryparse(store_container.val());
            if (data.length < 1) {
                add_rows(7);
                return;
            }
            add_rows(data.length, false);
            data.forEach(function (e, i) {
                e.forEach(function (e2, i2) {
                    main_container.find('.element-card[data-name="' + e2 + '"]').appendTo($(main_container.find('.row-container')[i]));
                });
            });
            init_sortable();
            validate_editor_table();
        }
        function init_success_form_data() {
            var data = json_tryparse(success_store_container.val());
            if (data.length < 1) {
                success_add_rows(4);
                return;
            }
            success_add_rows(data.length, false);
            data.forEach(function (e, i) {
                e.forEach(function (e2, i2) {
                   success_container.find('.element-card[data-name="' + e2 + '"]').appendTo($(success_container.find('.row-container')[i]));
                });
            });
            init_success_form_sortable();
            validate_success_editor_table();
        }
        var duplicate_save = false,duplicate_save_success_table;
        function save_success_form_data() {
            if (duplicate_save_success_table)
                return;
            duplicate_save_success_table = true;
            setTimeout(function () {
                duplicate_save_success_table = false;
            }, 100);
            var data = [];
            success_container.find('.row-container').each(function () {
                var row = [];
                $(this).find('.element-card').each(function () {
                    row.push($(this).attr('data-name'))
                });
                data.push(row);
            });
            success_store_container.val(JSON.stringify(data));
        }
        function save_data() {
            if (duplicate_save)
                return;
            duplicate_save = true;
            setTimeout(function () {
                duplicate_save = false;
            }, 100);
            var data = [];
            main_container.find('.row-container').each(function () {
                var row = [];
                $(this).find('.element-card').each(function () {
                    row.push($(this).attr('data-name'))
                });
                data.push(row);
            });
            store_container.val(JSON.stringify(data));
        }

        function json_tryparse(str) {
            var result = [];
            try {
                result = JSON.parse(str)
            }
            catch (e) {
                result = []
            }
            return result;
        }
        function success_add_rows(count = 1, init_sort = true) {
            for (var i = 0; i < count; i++) {
                generate_template_element('single-form-row').insertBefore($('#success-editor_form-add_row').closest('tr'));
            }
            if (init_sort)
                init_success_form_sortable();
        }
        function add_rows(count = 1, init_sort = true) {
            for (var i = 0; i < count; i++) {
                generate_template_element('single-form-row').insertBefore($('#editor_form-add_row').closest('tr'));
            }
            if (init_sort)
                init_sortable();
        }

        function init_sortable() {
            main_container.find("td.sortable").sortable({
                connectWith: main_container_selector+ " td.sortable:not(.full)",
                update: function (e, ui) {
                    validate_editor_table();
                    save_data();
                }
            });
        }
        function init_success_form_sortable() {
            console.log(success_container.find("td.sortable"))
            success_container.find("td.sortable").sortable({
                connectWith: success_container_selector + " td.sortable:not(.full)",
                update: function (e, ui) {
                    validate_success_editor_table();
                    save_success_form_data();
                }
            });
        }
        function validate_success_editor_table() {
            success_container.find('.row-container').each(function () {
                var $this = $(this);
                var child_count = $this.find('.element-card').length;
                if (child_count > 1)
                    $this.addClass('full');
                else
                    $this.removeClass('full');
                var remove_btn = $this.closest('tr').find('.action-remove-row').removeClass('disabled');
                if (child_count > 0)
                    remove_btn.addClass('disabled');
            });
        }
        function validate_editor_table() {
            main_container.find('.row-container').each(function () {
                var $this = $(this);
                var child_count = $this.find('.element-card').length;
                if (child_count > 1)
                    $this.addClass('full');
                else
                    $this.removeClass('full');
                var remove_btn = $this.closest('tr').find('.action-remove-row').removeClass('disabled');
                if (child_count > 0)
                    remove_btn.addClass('disabled');
            });
        }

        function generate_template_element(name) {
            var text = $('.templates .single-template[data-name="' + name + '"]').val();
            return $(text);
        }
    });
</script>
<br style="clear:both">

