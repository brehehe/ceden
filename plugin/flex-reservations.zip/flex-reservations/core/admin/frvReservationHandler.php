<?php
/**
 * Created by PhpStorm.
 * User: Mạnh Ninh
 * Date: 29/3/2017
 * Time: 8:19 AM
 */
if (!class_exists('frvReservationHandler')) {
    
    class frvReservationHandler extends fs_boot
    {
        /**
         * frvReservationHandler constructor.
         */
        protected $settings = [];
        public function __construct()
        {
            global $plugin_folder_name;
            $this->init($plugin_folder_name);
            $this->settings = get_option(FlexReservations()->app->setting_page_slug, array());
            // add_action('init', array($this, 'handle_save_reservation'));
//            add_action('wp_ajax_new_reservation', array($this, 'new_reservation'));
//            add_action('wp_ajax_nopriv_new_reservation', array($this, 'new_reservation'));


            add_action('wp_ajax_nopriv_flex-reservations-submit', array($this, 'new_reservation_ajax'));
            add_action('wp_ajax_flex-reservations-submit', array($this, 'new_reservation_ajax'));
        }
        public function new_reservation_ajax()
        {
            $data = (isset($_POST['nonce'])) && wp_verify_nonce($_POST['nonce'],'flex-reservations-form') && isset($_POST['data']) ? $_POST['data'] : false;
            if(!is_array($data))
                die(403);
            $required_field = fsr_get_required_fields();
            $error = [];
            foreach ($required_field as  $field)
            {
                if(!array_key_exists($field,$data) || empty(trim($data[$field])))
                {
                    $error[$field] = 'empty';
                    continue;
                }
            }
            $fields_use = fsr_get_form_input_fields();
            $data_use = [];
            foreach ($data as $field => $value)
            {
                if(!in_array($field,$fields_use))
                    continue;
                $data_use[$field] = $value;
            }
            //begin
            $time_work = get_timework();
            $holiday = get_holiday();
            $default = [
                'fs_name' => '',
                'fs_email' => '',
                'fs_phone' => '',
                'fs_date' => '',
                'fs_time' => '',
                'fs_partysize' => 1,
            ];
            $data = wp_parse_args($data_use,$default);
            if (empty($data['fs_partysize'])) {
                $data['fs_partysize'] = 1;
            }
            foreach (array_keys($default) as $field)
            {
                $field_use_name = substr($field,3);
                if (!$this->validate_($field_use_name, $data[$field])) {
                    $error[$field] = "{$field}_incorrect";
                }
            }
            $data['fs_date'] = date('F j, Y',strtotime($data['fs_date']));
            $reservation_time = strtotime(date('Y-m-d',strtotime($data['fs_date'])) . ' ' . $data['fs_time']);
            if (time() > $reservation_time) {
                $error['fs_date'] = "fs_time_expired";
                $error['fs_time'] = "fs_time_expired";
            }
            foreach ($holiday as $holi) {
                if (strtotime($holi->startDate) <= $reservation_time && strtotime($holi->endDate) >= $reservation_time) {
                    $error['fs_date'] = 'fs_holiday';
                    break;
                }
            }
            $day = date('l', $reservation_time);
            if (isset($time_work->day_off) && in_array($day, $time_work->day_off)) {
                $error['fs_date'] = 'fs_dayoff';
            }
            if ((isset($time_work->time_start) && !empty($time_work->time_start)
                    && date('H:i:s', strtotime($time_work->time_start)) > date('H:i:s', strtotime($data['fs_time'])))
                || (isset($time_work->time_stop) && !empty($time_work->time_stop)
                    && date('H:i:s', strtotime($time_work->time_stop)) < date('H:i:s', strtotime($data['fs_time'])))
            ) {
                $error['fs_time'] = 'fs_timeout';
            }

            //error handle
            if(!empty($error))
            {
                $message = [];
                foreach ($error as $key => $value)
                {
                    $message[] = fsr_get_error_notice_data($value);
                }
                $message = array_unique($message);
                $response = [
                    'success'=>'fail',
                    'error_fields'=>array_keys($error),
                    'message'=>$message
                ];
                $this->response($response);
            }
            $post_id = wp_insert_post(array(
                'post_type' => 'flexreservations',
                'post_status' => 'pending',
                'post_title' => $data['fs_name'],
            ));
            foreach ($data as $name => $value) {
                update_post_meta($post_id, $name, $value);
            }
            fsr_set_current_reservation($post_id);
            $response = [
                'success'=>'success',
                'message'=> $this->get_template_file__('front.success_notice_new')
            ];
            do_action('after_book_reservation', $post_id);
            echo json_encode($response);
            die();
        }
        function  maybe_special_validate_field($field,$value,&$error)
        {
            switch ($field)
            {
                case 'fs_time':
                    $time_work = get_timework();
                    if ((isset($time_work->time_start) && !empty($time_work->time_start)
                            && date('H:i:s', strtotime($time_work->time_start)) > date('H:i:s', strtotime($value)))
                        || (isset($time_work->time_stop) && !empty($time_work->time_stop)
                            && date('H:i:s', strtotime($time_work->time_stop)) < date('H:i:s', strtotime($value)))
                    ) {
                        $error['fs_time'] = 'fs_timeout';
                    }
                    break;
            }
        }
        public function validate_($type, $string = "")
        {
            switch ($type) {
                case 'email':
                    return fs_validateEmail($string);
                    break;
                case 'phone':
                    return fs_validatePhone($string);
                    break;
                case 'slug':
                    return fs_validateSlug($string);
                    break;
                case 'name':
                    return fs_validateName($string);
                    break;
                default:
                    return true;
                    break;
            }
        }

        public function new_reservation()
        {
            $time_work = get_timework();
            $holiday = get_holiday();
            if (isset($_POST['body'])) {
                $default = [
                    'fs_name' => '',
                    'fs_email' => '',
                    'fs_phone' => '',
                    'fs_date' => '',
                    'fs_time' => '',
                    'fs_partysize' => 1,
                    'fs_message' => '',
                ];
                $data = wp_parse_args($_POST['body'],$default);
                if (empty($data['fs_partysize'])) {
                    $data['fs_partysize'] = 1;
                }
                $errors = array();
                $name = array();
                foreach (array_keys($default) as $field)
                {
                    $field_use_name = substr($field,3);
                    if (!$this->validate_($field_use_name, $data[$field])) {
                        $errors[] = "{$field}_incorrect";
                        $name[] = $field;
                    }
                }
                $reservation_time = strtotime($data['fs_date'] . ' ' . $data['fs_time']);
                if (time() > $reservation_time) {
                    $errors[] = "fs_time_expired";
                    $name[] = "fs_date";
                    $name[] = "fs_time";
                }
                foreach ($holiday as $holi) {
                    if (strtotime($holi->startDate) <= $reservation_time && strtotime($holi->endDate) >= $reservation_time) {
                        $errors[] = 'fs_holiday';
                        $name[] = "fs_date";
                        break;
                    }
                }
                $day = date('l', $reservation_time);
                if (isset($time_work->day_off) && in_array($day, $time_work->day_off)) {
                    $errors[] = 'fs_dayoff';
                    $name[] = "fs_date";
                }
                if ((isset($time_work->time_start) && !empty($time_work->time_start)
                        && date('H:i:s', strtotime($time_work->time_start)) > date('H:i:s', strtotime($data['fs_time'])))
                    || (isset($time_work->time_stop) && !empty($time_work->time_stop)
                        && date('H:i:s', strtotime($time_work->time_stop)) < date('H:i:s', strtotime($data['fs_time'])))
                ) {
                    $errors[] = 'fs_timeout';
                    $name[] = "fs_time";
                }
                if (!empty($errors)) {
                    $this->response(array(
                        'type' => 'invalid',
                        'errors' => $errors,
                        'name' => $name,
                    ));
                }
                $post_id = wp_insert_post(array(
                    'post_type' => 'flexreservations',
                    'post_status' => 'pending',
                    'post_title' => $data['fs_name'],
                ));
                foreach ($data as $name => $value) {
                    update_post_meta($post_id, $name, $value);
                }
                $olddata1 = apply_filters('data_temp_reservation', array('name' => 'text', 'date' => 'text', 'time' => 'text', 'partysize' => 1));
                foreach ($olddata1 as $key => $value) {
                    if (is_array($value)) {
                        $newdata[] = $value[$data['fs_' . $key]];
                    } else {
                        $newdata[] = $data['fs_' . $key];
                    }
                    $olddata2[] = '[[' . $key . ']]';
                }
                $message = array(
                    'type' => 'success',
                    'message' => get_template_reservation_success($olddata2, $newdata)
                );
                do_action('after_book_reservation', $post_id);
                $this->response($message);
            }
        }
        public function replace_infor()
        {
        }
        public function response($message)
        {
            if (!empty($message)) {
                die(json_encode($message));
            }
        }
    }
}
