<?php
	/**
	 * Created by PhpStorm.
	 * User: Mạnh Ninh
	 * Date: 26/3/2017
	 * Time: 8:08 PM
	 */
	$textdomain         = 'flex-reservations';
	if ( ! class_exists( 'FlexReservations' ) ) {
		class FlexReservations extends fs_boot {
			
			private static $instance;
			public $app;
			
			/**
			 * flexReservations constructor.
			 */
			public static function instance() {
				if ( null === static::$instance ) {
					static::$instance = new static();
					static::$instance->includes();
				}
				
				return static::$instance;
			}
			
			public function includes() {
				global $plugin_folder_name;
				$plugin_folder_name = dirname( plugin_basename( __FILE__ ) );
				$this->init( $plugin_folder_name );
				$this->requireFolder( 'core' );
				$this->requireFolder( 'core.config' );
				$this->requireFolder( 'core.admin' );
				$this->requireFolder( 'core.api' );
				
			}
		}
	}
	if ( ! function_exists( 'flexReservations' ) ) {
		function flexReservations() {
			return FlexReservations::instance();
		}
	}
	if ( defined( 'FlexReservations_LATE_LOAD' ) ) {
		add_action( 'plugins_loaded', 'flexReservations', (int) FlexReservations_LATE_LOAD );
	} else {
		flexReservations();
	}

