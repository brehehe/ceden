// /**
//  * Created by Manhn on 5/4/2017.
//  */
// jQuery(document).ready(function(){
//
//     $('.fs_book').click(function (event) {
//         event.preventDefault();
//         Reservation({
//             value:{
//                 vendor:$('input[name="fs_vendor"]:checked').val(),
//                 name: $('input[name="fs_name"]').val(),
//                 email:$('input[name="fs_email"]').val(),
//                 phone: $('input[name="fs_phone"]').val(),
//                 partysize:$('input[name="fs_partysize"]:checked').val(),
//                 date: $('input[name="fs_date"]').val(),
//                 time: $('input[name="fs_time"]').val(),
//                 message:  $('input[name="fs_message"]').val(),
//             },
//             handle:{
//                 ajax_start: function () {
//                     console.log('begin ajax');
//                 },
//                 ajax_stop: function (data) {
//                     console.log('end ajax',data);
//                 },
//                 ajax_success: function (data) {
//                     console.log('ajax success',data);
//                 },
//                 ajax_fail: function (data) {
//                     console.log('ajax fail',data);
//                 },
//                 error: function (key) {
//                     console.log(key);
//                 }
//             }
//         });
//     });
// });