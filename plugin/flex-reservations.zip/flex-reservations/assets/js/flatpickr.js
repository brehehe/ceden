jQuery(document).ready(function ($) {
    $('.flatpickr').flatpickr({
        allowInput:true
    });
})