<?php

	

	/**

	 * Created by PhpStorm.

	 * User: Mạnh Ninh

	 * Date: 26/3/2017

	 * Time: 8:08 PM

	 */

	$textdomain         = 'flex-reservations';

	

	if ( class_exists('fs_boot') && ! class_exists( 'FlexReservations' ) ) {

		class FlexReservations extends fs_boot {

			

			private static $instance;

			public $app;

			

			/**

			 * flexReservations constructor.

			 */

			public static function instance() {

				if ( null === static::$instance ) {

					static::$instance = new static();

					static::$instance->includes();

				}

				

				return static::$instance;

			}

			

			public function includes() {

				global $plugin_folder_name;

				$plugin_folder_name = dirname(plugin_basename(__FILE__));

				$this->init( $plugin_folder_name );

				$this->requireFolder( 'core' );

				$this->requireFolder( 'core.config' );

				$this->requireFolder( 'core.admin' );

				$this->requireFolder( 'core.api' );

				

				add_filter( 'flexrestaurant_layout', array( $this, 'add_user_dashboard_layout' ) );

			}

			

			function add_user_dashboard_layout( $templates ) {

				$templates['reservation_default'] = array(

					'name'    => 'Default',

					'dir'     => 'flexReservations.templates.front.reservation',

					'details' => array(

						'image' => 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/A_small_cup_of_coffee.JPG/275px-A_small_cup_of_coffee.JPG'

					),

					'assets'  => array(

						'styles'  => array(),

						'scripts' => array()

					)

				);

				

				return $templates;

			}

		}

		

		if ( ! function_exists( 'flexReservations' ) ) {

			function flexReservations() {

				return FlexReservations::instance();

			}

		}

		if ( defined( 'FlexReservations_LATE_LOAD' ) ) {

			add_action( 'plugins_loaded', 'FlexReservations', (int) FlexReservations_LATE_LOAD );

		} else {

			flexReservations();

		}

	}