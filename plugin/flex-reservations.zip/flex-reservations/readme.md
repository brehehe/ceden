<h3>Handle Booking Form using Ajax</h3>

Return error:

    {
        type:"invalid",    
        errors: List error,
    }

List errors:
    
    + 'value': Sai giá trị truyền vào(khi code)
    + 'name': Sai tên.
    + 'phone':Sai phone.
    + 'email':Sai email.
    + 'date': Sai ngày.
    + 'time': Sai giờ.
    + 'time_expired': Ngày hết hạn(thời gian đặt nhỏ hơn hiện tại).
    + 'holiday': Đặt vào kỳ nghỉ.
    + 'dayoff': Đặt vào ngày nghỉ.
    + 'timeout': Đặt ngoài giờ làm việc.
    
Return success:

    {
        type:'success',
        message:'Booking successfully!'
    }

Example:

    /**
     * Created by Manhn on 5/4/2017.
     */
    jQuery(document).ready(function(){
        //Submit form(click button submit)
        $('.fs_book').click(function (event) {
            event.preventDefault();
            Reservation({
                //Send Form Data
                value:{
                    vendor:$('input[name="fs_vendor"]:checked').val(),//optional
                    name: $('input[name="fs_name"]').val(),//required
                    email:$('input[name="fs_email"]').val(),//required
                    phone: $('input[name="fs_phone"]').val(),//required
                    partysize:$('input[name="fs_partysize"]:checked').val(),//optional default:1
                    date: $('input[name="fs_date"]').val(),//required
                    time: $('input[name="fs_time"]').val(),//required
                    message:  $('input[name="fs_message"]').val(),//optional
                },
                //Handle callback
                handle:{
                    //Ajax start and stop(for loading)
                    ajax_start: function () {
                        console.log('begin ajax');
                    },
                    ajax_stop: function (data) {
                        console.log('end ajax',data);
                    },
                    
                    //Ajax done
                    ajax_success: function (data) {
                        console.log('ajax success',data);
                    },
                    
                    //Ajax fail
                    ajax_fail: function (data) {
                        console.log('ajax fail',data);
                    },
                    
                    //check error or success
                    error: function (key) {
                        console.log(key);
                    }
                }
            });
        })
        
    });
    
Settings:

    time start, time stop, day off
    holiday

Reservation structure:

    Require class 
        fs-wrapper,
        fs-loading-wrapper, 
        fs-notice-wrapper, 
        fs fields with prefix,
        success-wrapper
    Inject function:
         initReservation.inject.fields
         initReservation.inject.ajax_start
         initReservation.inject.ajax_stop
         initReservation.inject.ajax_success
         initReservation.inject.ajax_fail
         initReservation.inject.error
     