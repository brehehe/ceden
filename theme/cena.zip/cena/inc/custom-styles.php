<?php

if ( !function_exists ('cena_tbay_custom_styles') ) {
	function cena_tbay_custom_styles() {
		global $post;	
		
		ob_start();	
		?>
			
			<?php
				$font_source = cena_tbay_get_config('font_source');
				$main_font = cena_tbay_get_config('main_font');
				$main_font = isset($main_font['font-family']) ? $main_font['font-family'] : false;
				$main_google_font_face = cena_tbay_get_config('main_google_font_face');
			?>
			<?php if ( ($font_source == "1" && $main_font) || ($font_source == "2" && $main_google_font_face) ): ?>
				body,
				p
				{font-family: 
					<?php if ( $font_source == "2" ) echo '\'' . esc_html($main_google_font_face) . '\','; ?>
					<?php if ( $font_source == "1" ) echo '\'' . esc_html($main_font) . '\','; ?> 
					sans-serif;
				}
			<?php endif; ?>
			/* Second Font */
			<?php
				$secondary_font = cena_tbay_get_config('secondary_font');
				$secondary_font = isset($secondary_font['font-family']) ? $secondary_font['font-family'] : false;
				$secondary_google_font_face = cena_tbay_get_config('secondary_google_font_face');
			?>
			<?php if ( ($font_source == "1" && $secondary_font) || ($font_source == "2" && $secondary_google_font_face) ): ?>
					h1, h2, h3, h4, h5, h6, .widget-title, btn ,.navbar-nav.megamenu > li > a
				{
					
					font-family: 
					<?php if ( $font_source == "2" ) echo '\'' . esc_html($secondary_google_font_face) . '\','; ?>
					<?php if ( $font_source == "1" ) echo '\'' . esc_html($secondary_font) . '\','; ?> 
					sans-serif;
				}		
			<?php endif; ?>

			/* Custom Color (skin) */ 

			/* check main color */ 
			<?php if ( cena_tbay_get_config('main_color') != "" ) : ?>
			/*color*/
			.tbay-breadscrumb .breadscrumb-inner .breadcrumb .active,
			.entry-single .entry-meta .entry-date,
			.comment-list .date,
			.archive-shop div.product .information .price,
			.tbay-filter .change-view.active,
			.readmore a:hover,
			.testimonials-body .name-client,
			.entry-create a,
			.entry-create,
			a:hover, a:focus,
			.top-cart .dropdown-menu .cart_list + .total .amount,
			.top-cart .dropdown-menu .product-details .woocommerce-Price-amount,
			.color,
			#tbay-footer .btn-default, #tbay-footer .btn-default:hover, #tbay-footer .btn-default:focus, #tbay-footer .btn-default:active, #tbay-footer .btn-default.active, #tbay-footer .open > .btn-default.dropdown-toggle,
			ul.list-category li a:hover,
			#tbay-header.header-v4 #cart .mini-cart .sub-title .amount,
			#tbay-header.header-v5 #cart .mini-cart .sub-title .amount,
			.top-shipping h1, .top-shipping h2, .top-shipping h3, .top-shipping h4,
			.name a:hover,
			.meta-info span.author a,
			.dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus,
			#tbay-header.header-v2 .top-cart-wishlist #cart .mini-cart .sub-title .amount,
			.widget-features.style1 .fbox-image i, .widget-features.style1 .fbox-icon i,
			.contact-help i,
			#tbay-header .top-cart .dropdown-menu .product-details .woocommerce-Price-amount,
			#tbay-header .top-cart .dropdown-menu .cart_list + .total .amount,
			#tbay-header.header-v6 .top-shipping p, #tbay-header.header-v6 .top-shipping strong,
			#tbay-header.header-v8 ul.acount, #tbay-header.header-v8 ul.acount ,
			#tbay-header.header-v9 ul.acount, #tbay-header.header-v9 ul.acount a,
			#tbay-header.header-v9 #cart .mini-cart .sub-title .amount,
			.widget.woocommerce .woocommerce-Price-amount,
			.navbar-nav.megamenu .dropdown-menu > li > a:hover, .navbar-nav.megamenu .dropdown-menu > li > a:active,
			.list-categories ul li a:hover, .list-categories ul li a:focus,
			#tbay-header.header-v8 ul.acount, #tbay-header.header-v8 ul.acount a,
			.archive-shop div.product .information .yith-wcwl-wishlistexistsbrowse > a:hover, .archive-shop div.product .information .yith-wcwl-wishlistexistsbrowse > a.show, .archive-shop div.product .information .yith-wcwl-wishlistaddedbrowse > a:hover, .archive-shop div.product .information .yith-wcwl-wishlistaddedbrowse > a.show, .archive-shop div.product .information .yith-compare > a:hover, .archive-shop div.product .information .yith-compare > a.show, .archive-shop div.product .information .add_to_wishlist:hover, .archive-shop div.product .information .add_to_wishlist.show,
			.archive-shop div.product .information .compare:hover,
			.woocommerce table.wishlist_table tbody td.product-price .woocommerce-Price-amount, .woocommerce table.wishlist_table tbody td.product-subtotal .woocommerce-Price-amount, .woocommerce table.shop_table tbody td.product-price .woocommerce-Price-amount, .woocommerce table.shop_table tbody td.product-subtotal .woocommerce-Price-amount,
			.name a:hover,
			.entry-title a:hover,
			.widget_product_categories .product-categories a:hover,
			.widget_layered_nav > ul a:hover, .widget_layered_nav > ul a:active,
			.archive-shop div.product .information .compare:hover:before,
			.tbay-breadscrumb .breadscrumb-inner .breadcrumb a:hover,
			.contactinfos li i,
			.topbar-device-mobile .active-mobile .btn-danger,
			.topbar-device-mobile .device-cart .mobil-view-cart i,
			.footer-device-mobile > *.active a,
			body.woocommerce-wishlist .footer-device-mobile > .device-wishlist a,
			.topbar-device-mobile .topbar-post > * i,
			.archive-shop div.product .information .yith-wcwl-wishlistexistsbrowse > a,
			.archive-shop div.product .information .yith-wcwl-wishlistaddedbrowse > a,
			.woocommerce-message::before,
			.widget_product_categories .product-categories .current-cat>a,
			.mm-menu .mm-panels > .mm-panel > .mm-navbar + .mm-listview li.active > a, .mm-menu .mm-panels > .mm-panel > .mm-navbar + .mm-listview li.active .mm-counter,
			.tbay-offcanvas-body .navbar-collapse ul.treeview > li li.active > a
			{
				color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.woocommerce-message {
				border-top-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.top-cart .dropdown-menu .product-details .product-name:hover,
			.tbay-category-fixed ul li a:hover, .tbay-category-fixed ul li a:active,
			.treeview .hover,
			.popup-cart .total .woocommerce-Price-amount,
			#tbay-cart-modal .quantity .woocommerce-Price-amount
			{
				color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
			}
			#tbay-header .search-form .btn,
			.tbay_custom_menu.treeview-menu .widget .widgettitle,
			.category-inside,
			.top-cart-wishlist .wishlist-icon .count_wishlist,
			.tbay-to-top .search-form,
			.widget-categoriestabs .woocommerce .btn-view-all, .widget_deals_products .woocommerce .btn-view-all,
			.meta-info:after,
			#tbay-header .top-cart .dropdown-menu p.buttons,
			.testimonials-body .description::before,
			.tbay-to-top.v8 #back-to-top,
			ul.show-brand li a:hover, ul.show-brand li a:focus,
			.widget.widget-text-heading.title_underlined span:after,
			.woocommerce .woocommerce-MyAccount-navigation ul li.is-active a, .woocommerce .woocommerce-MyAccount-navigation ul li:focus a, .woocommerce .woocommerce-MyAccount-navigation ul li:hover a,
			.topbar-device-mobile .device-cart .mobil-view-cart .mini-cart-items,
			#yith-quick-view-modal.open .yith-wcqv-main .single_add_to_cart_button,
			body table.compare-list .add-to-cart td a,
			body table.compare-list .add-to-cart td a:hover,
			.product-block .groups-button .yith-compare > a.added,
			.footer-device-mobile>* a span.icon span.count, 
			.footer-device-mobile>* a span.icon .mini-cart-items,
			#yith-quick-view-modal.open .yith-wcqv-main .carousel-indicators li.active,
			.woocommerce-account .edit-account .woocommerce-Button,
			.woo-variation-swatches-stylesheet-enabled .variable-items-wrapper .variable-item:not(.radio-variable-item).button-variable-item
			{
				background: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.woo-variation-swatches-stylesheet-enabled .variable-items-wrapper .variable-item:not(.radio-variable-item).image-variable-item.selected, .woo-variation-swatches-stylesheet-enabled .variable-items-wrapper .variable-item:not(.radio-variable-item).image-variable-item:hover {
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.flex-control-nav.flex-control-thumbs .slick-arrow:hover.owl-prev, .flex-control-nav.flex-control-thumbs .slick-arrow:hover.owl-next {
				background: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
			}
			.woocommerce-account .edit-account .woocommerce-Button:hover {
				background: <?php echo cena_darken_color( cena_tbay_get_config('main_color'), -10 ) ?>;
			}			
			.popup-cart .gr-buttons a:focus, .popup-cart .gr-buttons a:hover {
				background: <?php echo cena_darken_color( cena_tbay_get_config('main_color'), -10 ) ?> !important;
				border-color: <?php echo cena_darken_color( cena_tbay_get_config('main_color'), -10 ) ?> !important;
			}
			.woocommerce .woocommerce-form-login input[type="submit"]:focus, .woocommerce .woocommerce-form-login input[type="submit"]:hover {
				background: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
			}
			#cboxClose:hover:before {
				color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.tbay-tooltip + .tooltip.top .tooltip-arrow {
				border-top-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}

			.ui-autocomplete.ui-widget-content .woocommerce-Price-amount,
			.form-ajax-search .tbay-search-result-wrapper > ul:first-child li .name a:hover,
			.form-ajax-search .tbay-search-result-wrapper > ul:first-child li.list-header span {
				color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}

			.mm-menu .mm-panels > .mm-panel > .mm-navbar + .mm-listview li.active .mm-btn_next:after,
			.woocommerce div.product .woocommerce-tabs ul.wc-tabs li:hover > a, 
			.woocommerce div.product .woocommerce-tabs ul.wc-tabs li.active > a,
			.woocommerce div.product .woocommerce-tabs ul.wc-tabs li:hover > a:hover, .woocommerce div.product .woocommerce-tabs ul.wc-tabs li:hover > a:focus, .woocommerce div.product .woocommerce-tabs ul.wc-tabs li.active > a:hover, .woocommerce div.product .woocommerce-tabs ul.wc-tabs li.active > a:focus {
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}

			.product-block .groups-button .add-cart .product_type_external:hover, .product-block .groups-button .add-cart .product_type_grouped:hover, .product-block .groups-button .add-cart .add_to_cart_button:hover,
			.pagination a:hover, .tbay-pagination a:hover,
			.tagcloud a:focus, .tagcloud a:hover,
			.rev_slider_wrapper .persephone.tparrows:hover, .rev_slider_wrapper .persephone.tparrows:focus,
			#yith-quick-view-modal.open .yith-wcqv-main .carousel-control
			{
				background: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.product-block .groups-button .yith-wcwl-wishlistexistsbrowse > a:hover, .product-block .groups-button .yith-wcwl-wishlistaddedbrowse > a:hover, .product-block .groups-button .yith-wcwl-add-to-wishlist > a:hover, .product-block .groups-button .yith-compare > a:hover, .product-block .groups-button .add_to_wishlist:hover, .product-block .groups-button .yith-wcqv-button:hover,
			.product-block .groups-button .yith-wcwl-wishlistexistsbrowse > a, .product-block .groups-button .yith-wcwl-wishlistaddedbrowse > a,
			#tbay-footer .btn-default, #tbay-footer .btn-default:hover, #tbay-footer .btn-default:focus, #tbay-footer .btn-default:active, #tbay-footer .btn-default.active, #tbay-footer .open > .btn-default.dropdown-toggle,
			.page-links > span:not(.page-links-title),
			.page-links a:hover,
			html input[type="button"], input[type="reset"], input[type="submit"],
			.tbay-offcanvas .offcanvas-head .btn-toggle-canvas,
			.btn-theme, .woocommerce .form-group input[type="submit"], 
			.woocommerce .form-row button[type="submit"],
			.woocommerce .form-row input[type="submit"], .woocommerce .widget_price_filter .price_slider_amount .button, .woocommerce table.shop_table input[type="submit"], .woocommerce-cart .wc-proceed-to-checkout a.checkout-button, .popup-cart .gr-buttons a, .woocommerce .return-to-shop .wc-backward, .woocommerce #payment #place_order, .woocommerce-page #payment #place_order, #reviews #commentform .form-submit input.submit, #respond .form-submit input, .woocommerce .woocommerce-form-login input[type="submit"],
			.btn-theme, .widget.yith-woocompare-widget a.compare,
			.archive-shop div.product .flex-control-thumbs.owl-carousel .owl-controls .owl-nav .owl-prev:hover, .archive-shop div.product .flex-control-thumbs.owl-carousel .owl-controls .owl-nav .owl-next:hover,
			.woocommerce .woocommerce-MyAccount-content a.button,
			.widget-categoriestabs .woocommerce .owl-carousel .owl-controls .owl-nav .owl-next:hover, .widget-categoriestabs .woocommerce .owl-carousel .owl-controls .owl-nav .owl-prev:hover, .widget_deals_products .woocommerce .owl-carousel .owl-controls .owl-nav .owl-next:hover, .widget_deals_products .woocommerce .owl-carousel .owl-controls .owl-nav .owl-prev:hover,
			.woocommerce-page .woocommerce-message .button
			{
				background-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
			}
			.owl-controls .owl-dot span,
			.widget_deals_products .block-inner .flex-control-thumbs li img.flex-active,
			.archive-shop div.product .flex-control-thumbs li img.flex-active,
			.blog-list-item,
			.product-block.grid:hover,
			.wpb_single_image.widget .vc_single_image-wrapper:hover,
			ul.list-category:hover,
			#yith-quick-view-modal.open .yith-wcqv-main .carousel-indicators li
			{
				border-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.btn-view-all:hover,
			.times > div,
			.text-theme,
			.product-block .price{
				color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
			}
			/*Border-color*/
			.tabs-v1 ul.nav-tabs li:hover > a, .tabs-v1 ul.nav-tabs li.active > a,
			.tabs-v1 ul.nav-tabs li:hover > a:hover, .tabs-v1 ul.nav-tabs li:hover > a:focus, .tabs-v1 ul.nav-tabs li.active > a:hover, .tabs-v1 ul.nav-tabs li.active > a:focus,
			.readmore a:hover,
			.btn-theme,
			.pagination span.current, .pagination a.current, .tbay-pagination span.current, .tbay-pagination a.current
			{
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			/*background color*/
			.comment-list .comment-reply-link,
			.archive-shop div.product .information .single_add_to_cart_button,
			.widget_price_filter .ui-slider-horizontal .ui-slider-range,
			.widget-categoriestabs ul.nav-tabs > li.active > a::after, .widget-categoriestabs ul.nav-tabs > li.active > a:hover::after, .widget-categoriestabs ul.nav-tabs > li.active > a:focus::after,
			.wpb_heading::before,
			.owl-controls .owl-dot.active span,
			.widget .widget-title::before, .widget .widgettitle::before, .widget .widget-heading::before,
			.woocommerce span.saled,
			.navbar-nav.megamenu > li > a::before,
			.btn-theme,.bg-theme
			{
				background-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?> !important;
			}
			.tbay-search-form .button-group,
			#cart .mini-cart .mini-cart-items,
			.pagination span.current, .pagination a.current, .tbay-pagination span.current, .tbay-pagination a.current,
			.tbay-tooltip + .tooltip .tooltip-inner,
			body table.compare-list .add-to-cart td a,
			.product-block .groups-button .yith-compare>a.added
			{
				background-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
			}
			.widget_deals_products .products-carousel .widget-title::after{
				border-color:<?php echo esc_html( cena_tbay_get_config('main_color') ) ?> <?php echo esc_html( cena_tbay_get_config('main_color') ) ?> rgba(0, 0, 0, 0) rgba(0, 0, 0, 0);
			}
			<?php endif; ?>

			/* Top Bar Backgound */
			<?php $topbar_bg = cena_tbay_get_config('topbar_bg'); ?>
			<?php if ( !empty($topbar_bg) ) :
				$image = isset($topbar_bg['background-image']) ? str_replace(array('http://', 'https://'), array('//', '//'), $topbar_bg['background-image']) : '';
				$topbar_bg_image = $image && $image != 'none' ? 'url('.esc_url($image).')' : $image;
			?>
				#tbay-topbar, 
				#tbay-header.header-default .tbay-topbar,
				#tbay-header.header-v2 #tbay-topbar,
				#tbay-header.header-v7 #tbay-topbar {
					<?php if ( isset($topbar_bg['background-color']) && $topbar_bg['background-color'] ): ?>
				    background-color: <?php echo esc_html( $topbar_bg['background-color'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($topbar_bg['background-repeat']) && $topbar_bg['background-repeat'] ): ?>
				    background-repeat: <?php echo esc_html( $topbar_bg['background-repeat'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($topbar_bg['background-size']) && $topbar_bg['background-size'] ): ?>
				    background-size: <?php echo esc_html( $topbar_bg['background-size'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($topbar_bg['background-attachment']) && $topbar_bg['background-attachment'] ): ?>
				    background-attachment: <?php echo esc_html( $topbar_bg['background-attachment'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($topbar_bg['background-position']) && $topbar_bg['background-position'] ): ?>
				    background-position: <?php echo esc_html( $topbar_bg['background-position'] ) ?>;
				    <?php endif; ?>
				    <?php if ( $topbar_bg_image ): ?>
				    background-image: <?php echo esc_html( $topbar_bg_image ) ?>;
				    <?php endif; ?>
				}
			<?php endif; ?>
			/* Top Bar Color */
			<?php if ( cena_tbay_get_config('topbar_text_color') != "" ) : ?>
				#tbay-topbar,
				#tbay-header.header-default .tbay-topbar,
				#tbay-header.header-v2 #tbay-topbar,
				#tbay-header.header-default .tbay-topbar a,
				#tbay-header.header-v2 .top-shipping2 p strong,
				#tbay-header.header-v2 a
				{
					color: <?php echo esc_html(cena_tbay_get_config('topbar_text_color')); ?>;
				}
			<?php endif; ?>

			/* Top Cart Background */
			<?php if ( cena_tbay_get_config('topbar_cart_background') != "" ) : ?>
				.top-cart-wishlist,
				#tbay-header.header-v6 .tbay-topbar .top-cart-wishlist,
				#tbay-header.header-v10 .logo {
					background-color: <?php echo esc_html(cena_tbay_get_config('topbar_cart_background')); ?>;
				}
			<?php endif; ?>

			/* Top Bar Icon Color */
			<?php if ( cena_tbay_get_config('topbar_icon_color') != "" ) : ?>
				.tbay-topbar .icons {
					color: <?php echo esc_html(cena_tbay_get_config('topbar_icon_color')); ?>;
				}
			<?php endif; ?>

			/* Header Backgound */
			<?php $header_bg = cena_tbay_get_config('header_bg'); ?>
			<?php if ( !empty($header_bg) ) :
				$image = isset($header_bg['background-image']) ? str_replace(array('http://', 'https://'), array('//', '//'), $header_bg['background-image']) : '';
				$header_bg_image = $image && $image != 'none' ? 'url('.esc_url($image).')' : $image;
			?>
				#tbay-header .header-main, #tbay-header.header-v3 .header-main,
				#tbay-header.header-v10 .header-main,
				#tbay-header.header-v7 .header-main,
				#tbay-header.header-v5 .header-main {
					<?php if ( isset($header_bg['background-color']) && $header_bg['background-color'] ): ?>
				    background-color: <?php echo esc_html( $header_bg['background-color'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($header_bg['background-repeat']) && $header_bg['background-repeat'] ): ?>
				    background-repeat: <?php echo esc_html( $header_bg['background-repeat'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($header_bg['background-size']) && $header_bg['background-size'] ): ?>
				    background-size: <?php echo esc_html( $header_bg['background-size'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($header_bg['background-attachment']) && $header_bg['background-attachment'] ): ?>
				    background-attachment: <?php echo esc_html( $header_bg['background-attachment'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($header_bg['background-position']) && $header_bg['background-position'] ): ?>
				    background-position: <?php echo esc_html( $header_bg['background-position'] ) ?>;
				    <?php endif; ?>
				    <?php if ( $header_bg_image ): ?>
				    background-image: <?php echo esc_html( $header_bg_image ) ?>;
				    <?php endif; ?>
				}
			<?php endif; ?>
			/* Header Color */
			<?php if ( cena_tbay_get_config('header_text_color') != "" ) : ?>
				#tbay-header, #tbay-header.header-v3 .header-main {
					color: <?php echo esc_html(cena_tbay_get_config('header_text_color')); ?>;
				}
			<?php endif; ?>
			/* Header Link Color */
			<?php if ( cena_tbay_get_config('header_link_color') != "" ) : ?>
				#tbay-header a, #tbay-header.header-v3 .header-main a {
					color: <?php echo esc_html(cena_tbay_get_config('header_link_color'));?> ;
				}
			<?php endif; ?>
			/* Header Link Color Active */
			<?php if ( cena_tbay_get_config('header_link_color_active') != "" ) : ?>
				#tbay-header .active > a,
				#tbay-header a:active,
				#tbay-header a:hover {
					color: <?php echo esc_html(cena_tbay_get_config('header_link_color_active')); ?>;
				}
			<?php endif; ?>


			/* Menu Link Color */
			<?php if ( cena_tbay_get_config('main_menu_link_color') != "" ) : ?>
				.dropdown-menu .menu li a,
				.navbar-nav.megamenu .dropdown-menu > li > a,
				.navbar-nav.megamenu > li > a{
					color: <?php echo esc_html(cena_tbay_get_config('main_menu_link_color'));?> !important;
				}
			<?php endif; ?>
			/* Menu Link Color Active */
			<?php if ( cena_tbay_get_config('main_menu_link_color_active') != "" ) : ?>
				.navbar-nav.megamenu > li.active > a,
				.navbar-nav.megamenu > li > a:hover,
				.navbar-nav.megamenu > li > a:active,
				.navbar-nav.megamenu .dropdown-menu > li.active > a,
				.navbar-nav.megamenu .dropdown-menu > li > a:hover,
				.dropdown-menu .menu li a:hover,
				.dropdown-menu .menu li.active > a
				{
					color: <?php echo esc_html(cena_tbay_get_config('main_menu_link_color_active')); ?> !important;
				}
			<?php endif; ?>			
 
			/* Menu Background Color Active */
			<?php if ( cena_tbay_get_config('main_menu_bg_color_active') != "" ) : ?>
				#primary-menu.navbar-nav.megamenu > li:hover > a,
				#primary-menu.navbar-nav.megamenu > li.active > a, 
				#primary-menu.navbar-nav.megamenu > li > a:hover, 
				#primary-menu.navbar-nav.megamenu > li > a:active
				{
					background-color: <?php echo esc_html(cena_tbay_get_config('main_menu_bg_color_active')); ?> !important;
				}
			<?php endif; ?>

			/* Footer Backgound */
			
			/* Footer Heading Color*/
			<?php if ( cena_tbay_get_config('footer_heading_color') != "" ) : ?>
				#tbay-footer h1, #tbay-footer h2, #tbay-footer h3, #tbay-footer h4, #tbay-footer h5, #tbay-footer h6 ,#tbay-footer .widget-title {
					color: <?php echo esc_html(cena_tbay_get_config('footer_heading_color')); ?> !important;
				}
			<?php endif; ?>
			/* Footer Color */
			<?php if ( cena_tbay_get_config('footer_text_color') != "" ) : ?>
				#tbay-footer {
					color: <?php echo esc_html(cena_tbay_get_config('footer_text_color')); ?>;
				}
			<?php endif; ?>
			/* Footer Link Color */
			<?php if ( cena_tbay_get_config('footer_link_color') != "" ) : ?>
				#tbay-footer a {
					color: <?php echo esc_html(cena_tbay_get_config('footer_link_color')); ?>;
				}
			<?php endif; ?>

			/* Footer Link Color Hover*/
			<?php if ( cena_tbay_get_config('footer_link_color_hover') != "" ) : ?>
				#tbay-footer a:hover {
					color: <?php echo esc_html(cena_tbay_get_config('footer_link_color_hover')); ?>;
				}
			<?php endif; ?>

			/* Copyright Backgound */
			<?php $copyright_bg = cena_tbay_get_config('copyright_bg'); ?>
			<?php if ( !empty($copyright_bg) ) :
				$image = isset($copyright_bg['background-image']) ? str_replace(array('http://', 'https://'), array('//', '//'), $copyright_bg['background-image']) : '';
				$copyright_bg_image = $image && $image != 'none' ? 'url('.esc_url($image).')' : $image;
			?>
				.tbay-copyright {
					<?php if ( isset($copyright_bg['background-color']) && $copyright_bg['background-color'] ): ?>
				    background-color: <?php echo esc_html( $copyright_bg['background-color'] ) ?> !important;
				    <?php endif; ?>
				    <?php if ( isset($copyright_bg['background-repeat']) && $copyright_bg['background-repeat'] ): ?>
				    background-repeat: <?php echo esc_html( $copyright_bg['background-repeat'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($copyright_bg['background-size']) && $copyright_bg['background-size'] ): ?>
				    background-size: <?php echo esc_html( $copyright_bg['background-size'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($copyright_bg['background-attachment']) && $copyright_bg['background-attachment'] ): ?>
				    background-attachment: <?php echo esc_html( $copyright_bg['background-attachment'] ) ?>;
				    <?php endif; ?>
				    <?php if ( isset($copyright_bg['background-position']) && $copyright_bg['background-position'] ): ?>
				    background-position: <?php echo esc_html( $copyright_bg['background-position'] ) ?>;
				    <?php endif; ?>
				    <?php if ( $copyright_bg_image ): ?>
				    background-image: <?php echo esc_html( $copyright_bg_image ) ?> !important;
				    <?php endif; ?>
				}
			<?php endif; ?>

			/* Footer Color */
			<?php if ( cena_tbay_get_config('copyright_text_color') != "" ) : ?>
				.tbay-copyright {
					color: <?php echo esc_html(cena_tbay_get_config('copyright_text_color')); ?>;
				}
			<?php endif; ?>
			/* Footer Link Color */
			<?php if ( cena_tbay_get_config('copyright_link_color') != "" ) : ?>
				.tbay-copyright a {
					color: <?php echo esc_html(cena_tbay_get_config('copyright_link_color')); ?>;
				}
			<?php endif; ?>

			/* Footer Link Color Hover*/
			<?php if ( cena_tbay_get_config('copyright_link_color_hover') != "" ) : ?>
				.tbay-copyright a:hover {
					color: <?php echo esc_html(cena_tbay_get_config('copyright_link_color_hover')); ?> !important;
				}
			<?php endif; ?>

			/* Woocommerce Breadcrumbs */
			<?php if ( cena_tbay_get_config('breadcrumbs') == "0" ) : ?>
			.woocommerce .woocommerce-breadcrumb,
			.woocommerce-page .woocommerce-breadcrumb
			{
				display:none;
			}
			<?php endif; ?>

			@media (max-width: 1300px) {
				.tbay-to-top.active #back-to-top {
					background-color: <?php echo esc_html( cena_tbay_get_config('main_color') ) ?>;
				}
			}

			/********************************************************************/
			/* Custom CSS *******************************************************/
			/********************************************************************/
			<?php if ( cena_tbay_get_config('custom_css') != "" ) : ?>
				<?php echo cena_tbay_get_config('custom_css') ?>
			<?php endif; ?>

	<?php
		$content = ob_get_clean();
		$content = str_replace(array("\r\n", "\r"), "\n", $content);
		$lines = explode("\n", $content);
		$new_lines = array();
		foreach ($lines as $i => $line) {
			if (!empty($line)) {
				$new_lines[] = trim($line);
			}
		}

		$custom_css = implode($new_lines);

		wp_enqueue_style( 'cena-style', get_template_directory_uri() . '/style.css', array(), '1.0' );

		wp_add_inline_style( 'cena-style', $custom_css );

		if( class_exists( 'WooCommerce' ) && class_exists( 'YITH_Woocompare' ) ) {
			wp_add_inline_style( 'cena-woocommerce', $custom_css );
		}

	}
}
add_action('wp_enqueue_scripts', 'cena_tbay_custom_styles', 999);
?>