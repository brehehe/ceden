=== TB Cena ===

Contributors: automattic
Tags: translation-ready, custom-background, theme-options, custom-menu, post-formats, threaded-comments

Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A starter theme called TB Cena, or underscores.

== Description ==

TB Cena Store is a Multi-purposes eCommerce WordPress Theme that is flexible and customizable for setting and changing any elements wihtin a minutes via Powerful Theme Options, you also can customize Google fonts without code very easy and simple. 

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

TB Cena includes support for Infinite Scroll in Jetpack.

== Changelog ==

Version 1.0 - October 04, 2017
- First release. 

Version 1.1 - October 05, 2017
- Update all plugins to latest version
- Update TBay Addon in Visual Composer
- Remove file /js/gmap3.js
- Remove file /vc_templates/tbay_googlemap.php

Version 1.2 - October 08, 2017
- Fix bug Customize doesn't work
- Update style for My Account Page in Woocommerce

Version 1.2.1 - October 09, 2017
- Update Tbay Framework plugin (cena/plugins/tbay-framework.zip)

Version 1.2.2 - October 12, 2017
- Fix bug Page Show sub category
- Update code compatible with Woocommerce version 3.2 

Version 2.0 - November 03, 2017
- Optimize design for mobile
- Update all plugins to latest version
- Fix some bugs in Theme Options

Version 2.1 - November 04, 2017
- Fix bug style on Firefox Mobile
- Update style for Menu Mobile

Version 2.2 - November 07, 2017
- Update style for Cart Page, Wishlist Page in Mobile

Version 2.3 - November 14, 2017
- Update all plugins to latest version
- Update Slider Revolution Version 5.4.6.3
- Fix bug long name in Category Menu
- Fix Logo in Home 10
- Fix Wishlist page on responsive, not mobile.
- Fix bug doesn't work in Shop page when the product has no image
- Fix width of logo mobile

Version 2.4 - November 16, 2017
- Compatibility: with WordPress 4.9
- Update WPBakery Page Builder 5.4.3
- Update Slider Revolution Version 5.4.6.3.1
- Add Ajax remove product in Minicart
- Add navigation image in single product page
- Add video thumbnail in single product page
- Add countdown in single product page

Version 2.5 - November 22, 2017
- Compatibility: with WooCommerce 3.2.4
- Update WPBakery Page Builder 5.4.4

Version 2.6 - December 08, 2017
- Compatibility: with WooCommerce 3.2.5
- Update WPBakery Page Builder 5.4.5
- Update Slider Revolution Version 5.4.6.4
- Update style Compare Popup
- Add config media size in Theme Options
- Add mutil Select Preloader
- Add Mobile menu Option
- Fix bug when click SUBSCRIBE
- Fix some bug style

Version 2.6.2 - December 15, 2017
- Compatibility: with WooCommerce 3.2.6
- Update All plugin to latest version

Version 2.6.3 - December 26, 2017
- Update All plugin to latest version
- Fix bug link cart in Back To Top don't work
- Fix bug Header JavaScript Code don't work in Theme Options

Version 2.6.4 - February 21, 2017
- Compatible with WordPress 4.9.4
- Compatible with Woocommerce 3.3.2
- Fixbug no ajax remove product in page cart
- Fix bug title on mobile of shop and category Page
- Element tbay social link support Snapchat and Instagram.
- Add new customiez Background Color Active.

Version 2.6.5 - March 23, 2018
- Compatible with Woocommerce 3.3.4
- Compatible with WPBakery Page Builder 5.4.7
- Compatible Revslider 5.4.7.2
- Optimize JS
- Add new customize Cena thumbnail in the mini cart and single product image thumbnail
- Add Variation Swatches in quick view
- Add feature auto ajax update page cart.
- Fix bug Post Archives does not configure the column
- Fix bug doesn't show pagination in page brand
- Fix bug title page search and category display incorrect in mobile

Version 2.6.6 - May 03, 2018
- Compatible with Woocommerce 3.3.5
- Compatible with Slider Revolution 5.4.7.3
- UPDATE All plugin to latest version
- UPDATE DOCUMENT: More details, more clearly
- [FIX] Bug style in Cart page

Version 2.7.0 - July 26, 2018
- [ADD NEW] Smart Mobile Menu
- Compatible with WordPress 4.9.7
- Compatible with Woocommerce 3.4.4
- Compatible with Slider Revolution 5.4.7.8
- Compatible with WPBakery Page Builder 5.5.2 (fix bug in RTL)
- [FIX] Fix bug can't update the premium plugins
- [FIX] Fix bug slow load the thumbnail images on detail product page
- [FIX] Fix bug Ajax search don't work well
- [FIX] Fix bug Sale label in multi language.

Version 2.7.1 - November 05, 2018
- [ADD NEW] Add new options "Max number of results show" in Theme Options/Header/Search Form
- [ADD NEW] Add new options "Preload Image" in Theme Options/General/Preload Website
- [ADD NEW] Add new options "Enable/Disable Ajax update quantity" in Theme Options/Woocommerce
- Compatible with Woocommerce 3.5.1
- Compatible with WPBakery Page Builder 5.5.5
- Compatible with WooCommerce Variation Swatches(By Emran Ahmed)
- [FIX] Fix bug ajax cart doesn't load price
- [FIX] Fix bug "Ajax Search Form" only search title
- [FIX] Fix bug label in "Countdown Timer" doesn't translate

Version 2.8 - December 15, 2018
- [ADD NEW] Add new LazyLoadImage in themee , add new options "Enable LazyLoadImage" in Theme Options/General
- Compatible with WordPress 5.0
- Compatible Gutenberg Editor
- Compatible with Woocommerce 3.5.2
- Compatible with WPBakery Page Builder 5.6
- Compatible with Slider Revolution 5.4.8.1
- Compatible with WooCommerce Blocks 1.2 plugin
+ [REMOVE] Remove the file "cena\vc_templates\tbay_category_info.php"
+ [REMOVE] Remove the file "cena\woocommerce\myaccount\form-lost-password.php"
- [FIX] Fix footer default can edit text
- [FIX] Fix "mini cart mobile" count does not work correctly
- [FIX] Fix variable product defect not showing percent off

Version 2.8.1 - January 15, 2019
- [ADD NEW] Add new option "Sale Tag Settings" in Theme Options/Woocommerce
- [ADD NEW] Add new Feature Custom Sale Label
- Compatible with Woocommerce 3.5.3
- Compatible with WPBakery Page Builder 5.6
+ [REMOVE] Remove the file "greenmart\woocommerce\content-none.php" 
- [FIX] Fix bug Product Second Image (Hover) works incorrectly
- [FIX] Fix bug doesn't show label "Feature" product
- [FIX] Fix bug theme options "Footer JavaScript Code" does not work
== Credits ==

* Based on Underscores http://underscores.me/,(C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/,(C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
