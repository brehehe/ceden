<?php
/**
 * Functions used in Electro
 *
 * @since 2.0
 */

require_once get_template_directory() . '/inc/functions/header.php';
require_once get_template_directory() . '/inc/functions/home.php';