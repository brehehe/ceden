<?php
/**
 * Template hooks used in header v6
 */
add_action( 'electro_header_v6', 'electro_set_header_v6_hooks', 10 );
add_action( 'electro_header_v6', 'electro_masthead', 20 );