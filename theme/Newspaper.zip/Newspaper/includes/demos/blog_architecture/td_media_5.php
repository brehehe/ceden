<?php

// ads
td_demo_media::add_image_to_media_gallery('td_blog_architecture_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_blog_architecture_content_ad',              "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/content.jpg");

