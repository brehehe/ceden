<?php

// ads
td_demo_media::add_image_to_media_gallery('banner',                      "http://demo_content.tagdiv.com/Newspaper_6/crypto/banner.png");
td_demo_media::add_image_to_media_gallery('rec_sidebar',                 "http://demo_content.tagdiv.com/Newspaper_6/crypto/rec-sidebar.png");

//menu bg
td_demo_media::add_image_to_media_gallery('td_pic_menu',                 "http://demo_content.tagdiv.com/Newspaper_6/crypto/menu-bg.png");