<?php

td_demo_media::add_image_to_media_gallery('work-man',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/worker.png");
td_demo_media::add_image_to_media_gallery('worker',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_worker_xxx.jpg");
td_demo_media::add_image_to_media_gallery('about-hero',              "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_about-hero_xxx.jpg");
td_demo_media::add_image_to_media_gallery('achievements',            "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_achievements_xxx.jpg");
td_demo_media::add_image_to_media_gallery('city',                    "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_city_xxx.jpg");
