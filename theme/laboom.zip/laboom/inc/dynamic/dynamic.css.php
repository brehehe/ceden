<?php

/**
 * Auto create css from Meta Options.
 * 
 * @author Fox
 * @version 1.0.0
 */
 if(!function_exists('wp_ laboom_hex_to_rgb')){
    function laboom_hex_to_rgb($hex,$opacity = 1) {
        $hex = str_replace("#",null, $hex);
        $color = array();
        if(strlen($hex) == 3) {
            $color['r'] = hexdec(substr($hex,0,1).substr($hex,0,1));
            $color['g'] = hexdec(substr($hex,1,1).substr($hex,1,1));
            $color['b'] = hexdec(substr($hex,2,1).substr($hex,2,1));
            $color['a'] = $opacity;
        }
        else if(strlen($hex) == 6) {
            $color['r'] = hexdec(substr($hex, 0, 2));
            $color['g'] = hexdec(substr($hex, 2, 2));
            $color['b'] = hexdec(substr($hex, 4, 2));
            $color['a'] = $opacity;
        }
        $color = "rgba(".implode(', ', $color).")";
        return $color;
    }
}
class CMSSuperHeroes_DynamicCss
{

    function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'generate_css'));
    }

    /**
     * generate css inline.
     *
     * @since 1.0.0
     */
    public function generate_css()
    {

        wp_enqueue_style('custom-dynamic',get_template_directory_uri() . '/assets/css/custom-dynamic.css');

        $_dynamic_css = $this->css_render();

        wp_add_inline_style('custom-dynamic', $_dynamic_css);
    }

    /**
     * header css
     *
     * @since 1.0.0
     * @return string
     */
    public function css_render()
    {
        global $opt_meta_options;
        ob_start();

        /* custom css. */
     if(is_page()){
       if(isset($opt_meta_options['body_layout']) && $opt_meta_options['body_layout'] == '0')
            echo 'body{width: calc(100% - 140px);margin: auto;max-width:100%;}';
         if(!empty($opt_meta_options['page_padding'])) {
            echo 'body #page #content{padding-top:'.$opt_meta_options['page_padding']['padding-top'].';padding-bottom:'.$opt_meta_options['page_padding']['padding-bottom'].' !important;}';
         }
          if(!empty($opt_meta_options['body_padding'])) {
            echo 'body{padding-top:'.$opt_meta_options['body_padding']['padding-top'].';padding-bottom:'.$opt_meta_options['body_padding']['padding-bottom'].' !important;'.';padding-left:'.$opt_meta_options['body_padding']['padding-left'].' !important;'.';padding-right:'.$opt_meta_options['body_padding']['padding-right'].' !important;}';
         }

         if(!empty($opt_meta_options['body_padding']['padding-left'])) {
            echo '.header-trans #cshero-header.header-fixed {left: '.$opt_meta_options['body_padding']['padding-left'].';width:auto;}';
            echo '.vc_row[data-vc-stretch-content] {padding-left: '.$opt_meta_options['body_padding']['padding-left'].' !important}';
         }
          if(!empty($opt_meta_options['body_padding']['padding-right'])) {
            echo '.header-trans #cshero-header.header-fixed {right: '.$opt_meta_options['body_padding']['padding-right'].';width:auto}';
             echo '.vc_row[data-vc-stretch-content] {padding-right: '.$opt_meta_options['body_padding']['padding-right'].' !important}';
         }



          if(!empty($opt_meta_options['page_title_padding'])) {
            echo 'body #page-title{padding-top:'.$opt_meta_options['page_title_padding']['padding-top'].' !important;padding-bottom:'.$opt_meta_options['page_title_padding']['padding-bottom'].' !important;}';
         }



         if (!empty($opt_meta_options['page_title_text_color']['rgba'])) {

             echo "#page-title #page-title-text{color: ".esc_attr($opt_meta_options['page_title_text_color']['rgba'])." !important;}";
            }
         if (!empty($opt_meta_options['page_title_fontsize'])) {

             echo "#page-title #page-title-text h1{font-size: ".esc_attr($opt_meta_options['page_title_fontsize'])." !important;}";
            }
         if (!empty($opt_meta_options['body_background_color']['background-color'])) {

             echo "body{background-color: ".esc_attr($opt_meta_options['body_background_color']['background-color'])." !important;}";
            }
         if (!empty($opt_meta_options['body_background_color']['background-repeat'])) {

             echo "body{background-repeat: ".esc_attr($opt_meta_options['body_background_color']['background-repeat'])." !important;}";
            }
          if (!empty($opt_meta_options['body_background_color']['background-size'])) {

             echo "body{background-size: ".esc_attr($opt_meta_options['body_background_color']['background-size'])." !important;}";
            }
             if (!empty($opt_meta_options['body_background_color']['background-image'])) {

             echo "body{background-image:url( ".esc_attr($opt_meta_options['body_background_color']['background-image']).") !important;}";
            }
             if (!empty($opt_meta_options['body_background_color']['background-attachment'])) {

             echo "body{background-attachment: ".esc_attr($opt_meta_options['body_background_color']['background-attachment'])." !important;}";
            }
            if (!empty($opt_meta_options['body_background_color']['background-position'])) {

             echo "body{background-position: ".esc_attr($opt_meta_options['body_background_color']['background-position'])." !important;}";
            }
         if (!empty($opt_meta_options['header_text_color'])) {

             echo "#cshero-header,#cshero-header-contact{color: ".esc_attr($opt_meta_options['header_text_color'])." !important;}";
            }
         if(!empty($opt_meta_options['logo_max_height']['height']))
                    echo 'header #cshero-header-logo img{max-height:'.esc_attr($opt_meta_options['logo_max_height']['height']).' !important;}';

         if(!empty($opt_meta_options['header_link_color']['regular'])){
           echo '#cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > ul > li > a,
           #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > li > a,
          #cshero-header-inner #cshero-header-navigation-left .menu-main-menu li a,
            #cshero-header-inner #cshero-header-navigation-left .menu-main-menu > ul li a,
           #cshero-header:not(.header-fixed) #cshero-header-logo .site-title a{color:' .esc_attr($opt_meta_options['header_link_color']['regular']).' !important;}';
           }

        if(!empty($opt_meta_options['header_link_color']['hover'])){
           echo '#cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > ul > li.current-menu-item > a,
            #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > li.current-menu-item > a,
            #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > ul > li.current-menu-ancestor > a,
             #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > li.current-menu-ancestor > a,
              #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > ul > li:hover > a,
              #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu > ul > li> a:hover,
              .header-trans #cshero-header:not(.header-fixed) #cshero-header-navigation .main-navigation .menu-main-menu li> a:hover,
             #cshero-header:not(.header-fixed) .is-one-page.current,
            #cshero-header:not(.header-fixed) .header-right .nav-button-icon i:hover{color:' .esc_attr($opt_meta_options['header_link_color']['hover']).' !important;}';
             }
        if (!empty($opt_meta_options['footer_bg_color'])) {

             echo "#footer-bottom{background-color: ".esc_attr($opt_meta_options['footer_bg_color'])." !important;}";
            }
        if (!empty($opt_meta_options['header_top_color_hover'])) {

             echo ".widget_nav_menu ul li a:hover,#cshero-header-top .header-right a:hover,#cshero-header-top a:hover{color: ".esc_attr($opt_meta_options['header_top_color_hover'])." !important;}";
            }
        if (!empty($opt_meta_options['footer_text_color'])) {

             echo "#footer-bottom{color:".esc_attr($opt_meta_options['footer_text_color'])." !important;}";
            }
            if (!empty($opt_meta_options['footer_background_image']['url'])) {

             echo "footer{background-image:url( ".esc_attr($opt_meta_options['footer_background_image']['url']).") !important;}";
            }
             if (!empty($opt_meta_options['header_bg_color'])) {

             echo "#cshero-header{background-color: ".esc_attr($opt_meta_options['header_bg_color'])." !important;}";
            }
             if (!empty($opt_meta_options['footer_top_bg_color']['rgba'])) {

             echo "footer #footer-top{background: ".esc_attr($opt_meta_options['footer_top_bg_color']['rgba'])." !important;}";
            }
}
        ?>

        <?php
        
        return ob_get_clean();
    }
}

new CMSSuperHeroes_DynamicCss();