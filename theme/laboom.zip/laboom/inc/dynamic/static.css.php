<?php

/**
 * Auto create .css file from Theme Options
 * @author Fox
 * @version 1.0.0
 */
class CMSSuperHeroes_StaticCss
{

    public $scss;
    
    function __construct()
    {
        if(!class_exists('scssc'))
            return;

        /* scss */
        $this->scss = new scssc();
        
        /* set paths scss */
        $this->scss->setImportPaths(get_template_directory() . '/assets/scss/');
             
        /* generate css over time */
		add_action('wp', array($this, 'generate_over_time'));
        
        /* save option generate css */
   	    add_action("redux/options/opt_theme_options/saved", array($this,'generate_file'));
    }
	
    public function generate_over_time(){
    	
    	global $opt_theme_options;

    	if (isset($opt_theme_options) && $opt_theme_options['dev_mode']){
    	    $this->generate_file();
    	}
    }
    /**
     * generate css file.
     *
     * @since 1.0.0
     */
    public function generate_file()
    {
        global $opt_theme_options, $wp_filesystem;
        
        if (empty($wp_filesystem) || !isset($opt_theme_options))
            return;
            
        $options_scss = get_template_directory() . '/assets/scss/options.scss';

        /* delete files options.scss */
        $wp_filesystem->delete($options_scss);

        /* write options to scss file */
        $wp_filesystem->put_contents($options_scss, $this->css_render(), FS_CHMOD_FILE); // Save it

        /* minimize CSS styles */
        if (!$opt_theme_options['dev_mode'])
            $this->scss->setFormatter('scss_formatter_compressed');

        /* compile scss to css */
        $css = $this->scss_render();

        $file = "static.css";

        $file = get_template_directory() . '/assets/css/' . $file;

        /* delete files static.css */
        $wp_filesystem->delete($file);

        /* write static.css file */
        $wp_filesystem->put_contents($file, $css, FS_CHMOD_FILE); // Save it
    }
    
    /**
     * scss compile
     * 
     * @since 1.0.0
     * @return string
     */
    public function scss_render(){
        /* compile scss to css */
        return $this->scss->compile('@import "master.scss"');
    }
    
    /**
     * main css
     *
     * @since 1.0.0
     * @return string
     */
    public function css_render()
    {
        global $opt_theme_options;
        
        ob_start();

        /* boxed layout. */
        if(isset($opt_theme_options['general_layout']) && $opt_theme_options['general_layout'] == '0')
            echo 'body{width: 1170px;margin: auto;}';
        if(isset($opt_theme_options['general_layout']) && $opt_theme_options['general_layout'] == '0'){
             if(isset($opt_theme_options['menu_sticky']) && $opt_theme_options['menu_sticky'] == '1'){
                echo '#cshero-header.header-fixed{max-width: 1170px;margin: 0 auto;}';
             }
        }
        /* primary_color */
        if(!empty($opt_theme_options['primary_color']))
            echo '$primary_color:'.esc_attr($opt_theme_options['primary_color']).';';

          if(!empty($opt_theme_options['third_color']))
            echo '$third_color:'.esc_attr($opt_theme_options['third_color']).';';
            if(!empty($opt_theme_options['fourth_color']))
            echo '$four_color:'.esc_attr($opt_theme_options['fourth_color']).';';



        /* link color */
        if(!empty($opt_theme_options['link_color']['regular']))
            echo '$link_color:'.esc_attr($opt_theme_options['link_color']['regular']).';';

        /* link color */
        if(!empty($opt_theme_options['link_color']['hover']))
            echo '$link_color_hover:'.esc_attr($opt_theme_options['link_color']['hover']).';';


        /* secondary_color */
                if(!empty($opt_theme_options['secondary_color']))
                    echo '$secondary_color:'.esc_attr($opt_theme_options['secondary_color']).';';

        /* logo_max_height */
        if(!empty($opt_theme_options['logo_max_height']['height']))
            echo 'header #cshero-header-logo img{max-height:'.esc_attr($opt_theme_options['logo_max_height']['height']).';}';

        if(!empty($opt_theme_options['logo-height-sticky']['height'])) {
                echo '#cshero-header.header-fixed #cshero-header-logo .sticky_logo img{max-height:'.esc_attr($opt_theme_options['logo-height-sticky']['height']).' !important;}';
            }
         if(!empty($opt_theme_options['trans_logo_height']['height'])) {
            echo '$trans_logo_height:'.esc_attr($opt_theme_options['trans_logo_height']['height']).';';
        }
        /* header_background_color */
        if(!empty($opt_theme_options['header_background_color']['rgba']))
            echo 'header #cshero-header{background-color:'.esc_attr($opt_theme_options['header_background_color']['rgba']).'}';
            /*header-link-color-hover*/
        if(!empty($opt_theme_options['header_link_color']['hover']))
            echo '$header_link_hover:'.esc_attr($opt_theme_options['header_link_color']['hover']).';';
         if(!empty($opt_theme_options['header_trans_link_color']['hover']))
            echo '$header_trans_link_hover:'.esc_attr($opt_theme_options['header_trans_link_color']['hover']).';';
         if(!empty($opt_theme_options['sticky_link_color']['hover']))
            echo '$sticky_link_color:'.esc_attr($opt_theme_options['sticky_link_color']['hover']).';';
        if(!empty($opt_theme_options['link_color']['hover']))
            echo '$link_hover:'.esc_attr($opt_theme_options['link_color']['hover']).';';
        /* sticky menu. */
        if(isset($opt_theme_options['menu_sticky']) && $opt_theme_options['menu_sticky']){
            echo '.sticky-desktop.header-fixed{position:fixed;}';

            /* sticky_background_color */
            if(!empty($opt_theme_options['sticky_background_color']['rgba']))
                echo '#cshero-header.sticky-desktop.header-fixed{background-color:'.esc_attr($opt_theme_options['sticky_background_color']['rgba']).' !important;}';
        }
         if(!empty($opt_theme_options['btn_border_color']['rgba']))
            echo '.btn,button,input[type="submit"]{border-color:'.esc_attr($opt_theme_options['btn_border_color']['rgba']).';}';
         if(!empty($opt_theme_options['btn_border_color_hover']['rgba']))
            echo '.btn:hover,button:hover,input[type="submit"]:hover{border-color:'.esc_attr($opt_theme_options['btn_border_color_hover']['rgba']).' !important;}';
         if(!empty($opt_theme_options['footer_border_social_color']))
                    echo '#footer-bottom .cms-footer-social li a{border-color:'.esc_attr($opt_theme_options['footer_border_social_color']).' !important;}';

        return ob_get_clean();
    }
}

new CMSSuperHeroes_StaticCss();