<?php
/**
 * @name : Default Header
 * @package : CMSSuperHeroes
 * @author : Fox
 */
?>
<div id="cshero-header-inner" class="header-default">
    <?php laboom_header_top();?>
    <div id="cshero-header" class="<?php laboom_header_class('cshero-main-header'); ?>">
            <div class="container">
                <div class="row">
                    <div id="cshero-header-navigation" class="col-xs-12 col-sm-8 col-md-5 col-lg-5">
                        <div class="cshero-header-navigation-inner">
                            <nav id="site-navigation" class="main-navigation">
                                <?php laboom_header_navigation(); ?>
                            </nav><!-- #site-navigation -->
                        </div>
                    </div>
                    <div id="cshero-header-logo" class="site-branding col-xs-12 col-sm-12 col-md-2 col-lg-2">
                        <?php laboom_header_logo(); ?>
                    </div><!-- #site-logo -->
                    <div id="cshero-header-right" class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                        <?php laboom_header_right();?>
                        <?php laboom_header_book_table();?>
                        <?php laboom_search_popup()?>
                    </div>
                    <div id="cshero-menu-mobile" class="collapse navbar-collapse">
                        <i class="pe-7s-menu"></i>
                    </div><!-- #menu-mobile -->
                </div>
            </div>

    </div><!-- #site-navigation -->
</div>