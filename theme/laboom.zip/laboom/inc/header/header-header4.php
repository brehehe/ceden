<?php
/**
 * @name : Default Header
 * @package : CMSSuperHeroes
 * @author : Fox
 */
?>
    <div id="cshero-header-inner" class="header-trans header4">
        <div id="cshero-header" class="<?php laboom_header_class('cshero-main-header'); ?>">
            <div class="container">
                <div class="row">
                    <div id="cshero-header-logo" class="site-branding col-xs-12 col-sm-2 col-md-2 col-lg-2">
                        <?php laboom_header_logo(); ?>
                    </div><!-- #site-logo -->
                    <div class="header-right-wrap col-xs-12 col-sm-10 col-md-10 col-lg-10">
                        <div id="cshero-header-right" class="right">
                            <?php laboom_header_right();?>
                            <?php laboom_header_book_table();?>
                            <?php laboom_search_popup()?>
                        </div>
                        <div id="cshero-header-navigation">
                            <div class="cshero-header-navigation-inner right">
                                <nav id="site-navigation" class="main-navigation">
                                    <?php laboom_header_navigation(); ?>
                                </nav><!-- #site-navigation -->
                            </div>
                        </div>

                    </div>
                    <div id="cshero-menu-mobile" class="collapse navbar-collapse">
                        <i class="pe-7s-menu"></i>
                    </div><!-- #menu-mobile -->

            </div>

        </div><!-- #site-navigation -->
    </div>