<?php
/**
 * ReduxFramework Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */
if (! class_exists('Redux')) {
    return;
}

// This line is only for altering the demo. Can be easily removed.
$opt_name = apply_filters('opt_name', 'opt_theme_options');

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name' => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name' => $theme->get('Name'),
    // Name that appears at the top of your panel
    'display_version' => $theme->get('Version'),
    // Version that appears at the top of your panel
    'menu_type' => 'menu',
    // Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu' => true,
    // Show the sections below the admin menu item or not
    'menu_title' => $theme->get('Name'),
    'page_title' => $theme->get('Name'),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key' => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography' => false,
    // Use a asynchronous font on the front end or font string
    // 'disable_google_fonts_link' => true, // Disable this in case you want to create your own google fonts loader
    'admin_bar' => true,
    // Show the panel pages on the admin bar
    'admin_bar_icon' => 'dashicons-smiley',
    // Choose an icon for the admin bar menu
    'admin_bar_priority' => 50,
    // Choose an priority for the admin bar menu
    'global_variable' => '',
    // Set a different name for your global variable other than the opt_name
    'dev_mode' => false,
    // Show the time the page took to load, etc
    'update_notice' => true,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer' => true,
    // Enable basic customizer support
    // 'open_expanded' => true, // Allow you to start the panel in an expanded way initially.
    // 'disable_save_warn' => true, // Disable the save warning when a user changes a field

    // OPTIONAL -> Give you extra features
    'page_priority' => null,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent' => 'themes.php',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions' => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon' => 'dashicons-dashboard',
    // Specify a custom URL to an icon
    'last_tab' => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon' => 'dashicons-smiley',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug' => '',
    // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
    'save_defaults' => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show' => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark' => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export' => true,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time' => 60 * MINUTE_IN_SECONDS,
    'output' => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag' => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit' => '', // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database' => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn' => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    // HINTS
    'hints' => array(
        'icon' => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color' => 'lightgray',
        'icon_size' => 'normal',
        'tip_style' => array(
            'color' => 'red',
            'shadow' => true,
            'rounded' => false,
            'style' => ''
        ),
        'tip_position' => array(
            'my' => 'top left',
            'at' => 'bottom right'
        ),
        'tip_effect' => array(
            'show' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'mouseover'
            ),
            'hide' => array(
                'effect' => 'slide',
                'duration' => '500',
                'event' => 'click mouseleave'
            )
        )
    )
);

Redux::setArgs($opt_name, $args);

/**
 * General Options.
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('General', 'laboom'),
    'icon' => 'el-icon-adjust-alt',
    'fields' => array(
        array(
            'title'             => esc_html__('Layout', 'laboom'),
            'subtitle'          => esc_html__('Full width / Boxed.', 'laboom'),
            'id'                => 'general_layout',
            'type'              => 'button_set',
            'options'           => array(
                                        1 => esc_html__('Full width', 'laboom'),
                                        0 => esc_html__('Boxed', 'laboom')
                                    ),
            'default'           => 1
        ),
        array(
            'title'             => esc_html__('Background', 'laboom'),
            'id'                => 'body_fullwidth_background',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-image'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array( 'body' ),
            'required'          => array( 'general_layout', '=', 1 )
        ),
        array(
            'title'             => esc_html__('Body Background', 'laboom'),
            'subtitle'          => esc_html__('Body background.', 'laboom'),
            'id'                => 'general_background',
            'type'              => 'background',
            'output'            => array( 'body' ),
            'required'          => array( 'general_layout', '=', 0 )
        ),
        array(
            'title'             => esc_html__('Content Background', 'laboom'),
            'subtitle'          => esc_html__('Content background.', 'laboom'),
            'id'                => 'general_content_background',
            'type'              => 'background',
            'output'            => array( '#content' ),
            'required'          => array( 'general_layout', '=', 0 )
        ),
        array(
            'subtitle'          => esc_html__('Enable back to top button.', 'laboom'),
            'id'                => 'general_back_to_top',
            'type'              => 'switch',
            'title'             => esc_html__('Back To Top', 'laboom'),
            'default'           => false,
        ),
        array(
            'subtitle'          => esc_html__('Enable page loading.', 'laboom'),
            'id'                => 'general_page_loading',
            'type'              => 'switch',
            'title'             => esc_html__('Page loading', 'laboom'),
            'default'           => false,
        )
    )
));

/**
 * Header Options
 * 
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Header', 'laboom'),
    'icon' => 'el-icon-credit-card',
    'fields' => array(
        array(
            'id'                => 'header_layout',
            'title'             => esc_html__('Layouts', 'laboom'),
            'subtitle'          => esc_html__('select a layout for header', 'laboom'),
            'default'           => 'default',
            'type'              => 'image_select',
            'options'           => array(
                'default' => get_template_directory_uri().'/assets/images/header/h-style-1.jpg',
                'trans' => get_template_directory_uri().'/assets/images/header/h-style-2.jpg',
                'header3' => get_template_directory_uri().'/assets/images/header/h-style-3.jpg',
                'header4' => get_template_directory_uri().'/assets/images/header/h-style-4.jpg',
                'header5' => get_template_directory_uri().'/assets/images/header/h-style-5.jpg',
            )
        ),
        array(
            'title'             => esc_html__('Logo Type', 'laboom'),
            'subtitle'          => esc_html__('Image / Text.', 'laboom'),
            'id'                => 'logo_type',
            'type'              => 'button_set',
            'options'           => array(
                1 => esc_html__('Image', 'laboom'),
                0 => esc_html__('Text', 'laboom')
            ),
            'default'           => 1
        ),
        array(
            'title'             => esc_html__('Select Logo', 'laboom'),
            'subtitle'          => esc_html__('Select an image file for your logo.', 'laboom'),
            'id'                => 'main_logo',
            'type'              => 'media',
            'url'               => true,
            'default'           => array(
                'url'=>get_template_directory_uri().'/assets/images/logo.png'
            ),
            'required'          =>array(
                array( 'logo_type', '=', 1 )
            )
        ),
        array(
            'id'                => 'our_hours',
            'type'              => 'text',
            'title'             => esc_html__('Our hours', 'laboom'),
            'default'           =>esc_html__('Mon-Fri: 9-23; Sat: 9-20; Sun: Off','laboom'),
            'required'          => array( 'header_layout', '=', 'header3' )
        ),
        array(
            'id'                => 'our_phone',
            'type'              => 'text',
            'title'             => esc_html__('Our phone', 'laboom'),
            'default'           =>esc_html__('(503) 228 4329','laboom'),
            'required'          => array( 'header_layout', '=', 'header3' )
        ),
        array(
            'id'                => 'our_address',
            'type'              => 'text',
            'title'             => esc_html__('Our Address', 'laboom'),
            'default'           =>esc_html__('135 E Houston Street, New York, US','laboom'),
            'required'          => array( 'header_layout', '=', 'header3' )
        ),
        array(
            'id'                => 'enable_search1',
            'type'              => 'switch',
            'title'             => esc_html__('Enable Search Right', 'laboom'),
            'default'           => false,
            'required'          => array( 'header_layout', '=', 'header3' )
        ),
        array(
            'id'                => 'enable_cart1',
            'type'              => 'switch',
            'title'             => esc_html__('Enable Cart Right', 'laboom'),
            'default'           => true,
            'required'          => array( 'header_layout', '=', 'header3' )
        ),

        array(
            'subtitle'          => esc_html__('Set max height for logo.', 'laboom'),
            'id'                => 'logo_max_height',
            'type'              => 'dimensions',
            'units'             => array('px'),
            'width'             => false,
            'title'             => esc_html__('Logo Height', 'laboom'),
            'required'          => array( 'logo_type', '=', 1 )
        ),
        array(
            'title' => esc_html__('Transparent Logo', 'laboom'),
            'subtitle' => esc_html__('Select an image file for logo which is displayed on header transparent and popup menu and hidden sidebar ', 'laboom'),
            'id' => 'trans_logo',
            'type' => 'media',
            'url' => false,
            'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-trans.png'
            ),
            'required'          =>array(
                array( 'header_layout', '!=', 'trans' ),
                array( 'header_layout', '!=', 'header3' ),
                array( 'logo_type', '=', 1 )
            )
        ),
        array(
            'subtitle'          => esc_html__('Set max height for transparent logo.', 'laboom'),
            'id' => 'trans_logo_height',
            'title' => 'Logo Transparent Height ',
            'type' => 'dimensions',
            'units'    => array('px'),
            'width' => false,
            'default'  => array(
                'Height'  => '76'
            ),
            'required'          =>array(
                array( 'header_layout', '=', 'trans' ),
                array( 'logo_type', '=', 1 )
            )

        ),
        array(
            'subtitle'          => esc_html__('Add custom logo text.', 'laboom'),
            'id'                => 'logo_text',
            'type'              => 'text',
            'title'             => esc_html__('Logo Text', 'laboom'),
            'required'          => array( 'logo_type', '=', 0 )
        ),
        array(
            'subtitle'          => esc_html__('Add custom slogan Text.', 'laboom'),
            'id'                => 'logo_text_sologan',
            'type'              => 'text',
            'title'             => esc_html__('Slogan Text', 'laboom'),
            'required'          => array( 'logo_type', '=', 0 )
        ),
        array(
            'id'                => 'header_background_color',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Background Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Header background color', 'laboom' ),
        ),
        array(
            'title'             => esc_html__('Background Image', 'laboom'),
            'subtitle'          => esc_html__('Header background image.', 'laboom'),
            'id'                => 'header_background_image',
            'type'              => 'background',
            'preview'           => false,
            'background-color'  => false,
            'output'            => array( '#cshero-header' )
        ),
        array(
            'id'                => 'header_trans_text_color',
            'type'              => 'color',
            'title'             => esc_html__( 'Text Color for header transparent', 'laboom' ),
            'subtitle'          => esc_html__( 'Select text color in header transparent', 'laboom' ),
            'output'            => array( '.header-trans #cshero-header' ),
        ),
        array(
            'id'                => 'header_trans_link_color',
            'type'              => 'link_color',
            'title'             => esc_html__( 'Links Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select links color in header transparent', 'laboom' ),
            'regular'           => true,
            'hover'             => true,
            'active'            => false,
            'visited'           => false,
            'default'  => array(
                'hover'    => '#e4b95b',
            ),
            'output'            => array( '.header-trans #cshero-header-navigation .main-navigation .menu-main-menu > ul > li > a,.header-trans #cshero-header-navigation .main-navigation .menu-main-menu > li > a,.header-trans #cshero-header-logo .site-title a' ),
        ),
        array(
            'id'                => 'header_text_color',
            'type'              => 'color',
            'title'             => esc_html__( 'Text Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select text color in header which is not transparent', 'laboom' ),
            'output'            => array( '#cshero-header,#cshero-header-contact .header-contact-right' ),
        ),
        array(
            'id'                => 'header_link_color',
            'type'              => 'link_color',
            'title'             => esc_html__( 'Links Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select links color in header', 'laboom' ),
            'regular'           => true,
            'hover'             => true,
            'active'            => false,
            'visited'           => false,
            'default'  => array(
                'hover'    => '#e4b95b',
            ),
            'output'            => array( '#cshero-header-navigation .main-navigation .menu-main-menu > ul > li > a,#cshero-header-navigation .main-navigation .menu-main-menu > li > a,#cshero-header-logo .site-title a,#cshero-header a,.header-right .nav-button-icon .shopping-cart-wrapper:hover,.header-right .nav-button-icon .lnr-magnifier:hover ' ),
        ),

        array(
            'id' => 'font_main_menu',
            'type' => 'typography',
            'title' => esc_html__('Font main menu', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'color'=>'false',
            'all_styles' => false,
            'text-align' =>false,
            'output'  => array('#cshero-header-navigation .main-navigation .menu-main-menu > ul > li > a, #cshero-header-navigation .main-navigation .menu-main-menu > li > a,#cshero-header-navigation .main-navigation li ul li a'),
            'units' => 'px',
            'line-height' => false,

        ),
        array(
            'id'                => 'enable_search',
            'type'              => 'switch',
            'title'             => esc_html__('Enable Search Right', 'laboom'),
            'default'           => false,

        ),
        array(
            'id'                => 'enable_cart',
            'type'              => 'switch',
            'title'             => esc_html__('Enable Cart Right', 'laboom'),
            'default'           => true,
                  ),
        array(
            'id'                => 'enable_book_table',
            'type'              => 'switch',
            'title'             => esc_html__('Enable Book Table', 'laboom'),
            'default'           => false,
        ),
        array(
            'id'             => 'margin_top_mainmenu',
            'type'           => 'spacing',
            'output'         => array('#cshero-header-navigation .main-navigation'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin top primary menu', 'laboom'),
            'bottom'     => false,
            'left'     => false,
            'right'     => false,

        ),
        array(
            'subtitle'          => esc_html__('Enable mega menu.', 'laboom'),
            'id'                => 'mega_menu',
            'type'              => 'switch',
            'title'             => esc_html__('Mega Menu', 'laboom'),
            'default'           => false,
        ),
    )
));
/* header top */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Header Top', 'laboom'),
    'icon' => 'el el-info-circle',
    'subsection' => true,
    'fields' => array(
        array(
            'id'                => 'enable_header_top',
            'type'              => 'switch',
            'title'             => esc_html__('Enable header Top', 'laboom'),
            'subtitle'          => esc_html__( 'Apply for header layout 4 and 8 and 9', 'laboom' ),
            'default'           => false,
        ),
        array(
            'title'             => esc_html__('Background header top', 'laboom'),
            'id'                => 'header_top_background',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-image'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array( '#cshero-header-top' ),
            'required'          => array( 'enable_header_top', '=', 1 ),
        ),
        array(
            'id'                => 'header_top_color',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Text Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select text color in header top', 'laboom' ),
            'output'            => array( '#cshero-header-top' ),
            'required'          => array( 'enable_header_top', '=', 1 )
        ),
        array(
            'id'                => 'header_top_link_color',
            'type'              => 'link_color',
            'title'             => esc_html__( 'Links Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select links color in header top', 'laboom' ),
            'regular'           => true,
            'hover'             => true,
            'active'            => false,
            'visited'           => false,
            'default'  => array(
                'regular'  => '',
                'hover'    => '',
            ),
            'output'            => array( '.widget_nav_menu ul li a,#cshero-header-top .header-right a,#cshero-header-top a' ),
            'required'          => array( 'enable_header_top', '=', 1 ),
        ),
        array(
            'title' => esc_html__('Phone', 'laboom'),
            'id' => 'top_phone',
            'type' => 'textarea',
            'default' => '123-456-7890',
//            'required'          => array( 'enable_header_top', '=', 1 ),
            'required'          =>array(
                array( 'enable_header_top', '=', 1 ),
                array( 'header_layout', '=', 'default' )
            )
        ),
        array(
            'title' => esc_html__('Email', 'laboom'),
            'id' => 'top_email',
            'type' => 'text',
            'default' => 'support@laboom.com',
            'required'          =>array(
                array( 'enable_header_top', '=', 1 ),
                array( 'header_layout', '=', 'default' )
            )
        ),
        array(
            'title' => esc_html__('Slogen Welcome', 'laboom'),
            'id' => 'slogen_welcome',
            'type' => 'textarea',
            'default' => esc_html__('Welcome to our website, check our services and gain success!','laboom'),
//            'required'          => array( 'enable_header_top', '=', 1 ),
            'required'          =>array(
                array( 'enable_header_top', '=', 1 ),
                array( 'header_layout', '=', 'trans' )
            )
        ),

        array(
            'id'                => 'enable_social_header_top',
            'type'              => 'switch',
            'title'             => esc_html__('Enable Social', 'laboom'),
            'default'           => true,
            'required'          =>array(
                array( 'enable_header_top', '=', 1 )
            )
        ),
        array(
            'title' => esc_html__('Social', 'laboom'),
            'id'      => 'cms_header_top_social',
            'type'    => 'sorter',
            'desc'    => 'Choose social networks which are displayed on header top.',
            'options' => array(
                'enabled'  => array(
                    'facebook'  => 'Facebook',
                    'twitter'   => 'Twitter',
                    'dribbble'  => 'Dribbble',
                    'instagram'  => 'Instagram',
                    'google'  => 'Google',
                    'printest'  => 'Printest',
                ),
                'disabled' => array(

                )
            ),
            'required'          =>array(
                array( 'enable_header_top', '=', 1 ),
                array( 'enable_social_header_top', '=', 1 )
            )
        ),

    )
));
/* Menu Sticky */
Redux::setSection($opt_name, array(
    'icon' => 'el-icon-minus',
    'title' => esc_html__('Menu Sticky', 'laboom'),
    'subsection' => true,
    'fields' => array(
        array(
            'subtitle'          => esc_html__('enable sticky mode for menu.', 'laboom'),
            'id'                => 'menu_sticky',
            'type'              => 'switch',
            'title'             => esc_html__('Sticky Header', 'laboom'),
            'default'           => false,
        ),
        array(
            'title'             => esc_html__('Logo Type', 'laboom'),
            'subtitle'          => esc_html__('From Main / Image / Text.', 'laboom'),
            'id'                => 'sticky_logo_type',
            'type'              => 'button_set',
            'options'           => array(
                'default' => esc_html__('Main', 'laboom'),
                'img' => esc_html__('Image', 'laboom'),
                'text' => esc_html__('Text', 'laboom')
            ),
            'default'           => 'img',
            'required'          => array( 'menu_sticky', '=', 1 )
        ),
        array(
            'title'             => esc_html__('Select Logo', 'laboom'),
            'subtitle'          => esc_html__('Select an image file for your logo.', 'laboom'),
            'id'                => 'sticky_logo',
            'type'              => 'media',
            'url'               => true,
            'default'           => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-sticky.png'
            ),
            'required'          => array( 'sticky_logo_type', '=', 'img' )
        ),
        array(
            'subtitle' => esc_html__('in pixels.', 'laboom'),
            'id' => 'logo-height-sticky',
            'title' => 'Logo Height Sticky',
            'type' => 'dimensions',
            'units'    => array('px'),
            'width' => false,
            'required'          => array( 'menu_sticky', '=', 1 )

        ),
        array(
            'id'             => 'sticky_margin_top_mainmenu',
            'type'           => 'spacing',
            'output'         => array('#cshero-header.header-fixed #cshero-header-navigation .main-navigation,#cshero-header.header-fixed .header-right'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin top primary menu', 'laboom'),
            'bottom'     => false,
            'left'     => false,
            'right'     => false,
            'required'          => array( 'menu_sticky', '=', 1 )
        ),
        array(
            'subtitle'          => esc_html__('Add custom logo text.', 'laboom'),
            'id'                => 'sticky_logo_text',
            'type'              => 'text',
            'title'             => esc_html__('Logo Text', 'laboom'),
            'required'          => array( 'sticky_logo_type', '=', 'text' )
        ),
        array(
            'subtitle'          => esc_html__('Add custom slogan Text.', 'laboom'),
            'id'                => 'sticky_logo_text_sologan',
            'type'              => 'text',
            'title'             => esc_html__('Slogan Text', 'laboom'),
            'required'          => array( 'sticky_logo_type', '=', 'text' )
        ),
        array(
            'id'                => 'sticky_background_color',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Background Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Header background color', 'laboom' ),
            'required'          => array( 'menu_sticky', '=', 1 )
        ),
        array(
            'id'                => 'sticky_text_color',
            'type'              => 'color',
            'title'             => esc_html__( 'Text Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select text color in header', 'laboom' ),
            'output'            => array( '#cshero-header.header-fixed' ),
            'required'          => array( 'menu_sticky', '=', 1 ),
            'default' => '#fff',
        ),
        array(
            'id'                => 'sticky_link_color',
            'type'              => 'link_color',
            'title'             => esc_html__( 'Links Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select links color in header', 'laboom' ),
            'regular'           => true,
            'hover'             => true,
            'active'            => false,
            'visited'           => false,
            'output'            => array( 'body .header-fixed #cshero-header-navigation .main-navigation .menu-main-menu > li > a' ),
            'required'          => array( 'menu_sticky', '=', 1 ),
            'default'  => array(
                'regular'  => '#fff',
                'hover'    => '#e4b95b',
            )
        ),
        array(
            'title'          => esc_html__('Enable menu sticky tablet', 'laboom'),
            'id'                => 'sticky_tablet',
            'type'              => 'switch',
            'default'           => false,
        ),
        array(
            'title'          => esc_html__('Enable menu sticky mobile', 'laboom'),
            'id'                => 'sticky_mobile',
            'type'              => 'switch',
            'default'           => false,
        ),
    )
));
/**
 * page config
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Page', 'laboom'),
    'icon' => 'el-icon-map-marker',
    'fields' => array(
        array(
            'title'             => esc_html__('Padding', 'laboom'),
            'subtitle'          => esc_html__('Main content padding (top/bottom).', 'laboom'),
            'id'                => 'page_padding',
            'type'              => 'spacing',
            'mode'              => 'padding',
            'units'             => array( 'px'),
            'top'               => true,
            'right'             => false,
            'bottom'            => true,
            'left'              => false,
            'output'            => array( '#page #content' )
        ),
    )
));
/**
 * Page Title
 *
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Page Title', 'laboom'),
    'icon' => 'el-icon-map-marker',
    'subsection' => true,
    'fields' => array(
        array(
            'id'                => 'page_title_layout',
            'title'             => esc_html__('Layouts', 'laboom'),
            'subtitle'          => esc_html__('select a layout for page title', 'laboom'),
            'default'           => '1',
            'type'              => 'image_select',
            'options'           => array(
                                    '1' => get_template_directory_uri().'/assets/images/pagetitle/pt-s-1.jpg',
                                    '2' => get_template_directory_uri().'/assets/images/pagetitle/pt-s-2.jpg',
                                )
        ),
        array(
            'title' => esc_html__('Select Background Image', 'laboom'),
            'id' => 'bg_page_title',
            'type' => 'media',
            'url' => false,
            'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/page-title.jpg'
            ),
        ),
        array(
            'title'             => esc_html__('Padding', 'laboom'),
            'subtitle'          => esc_html__('Page title padding (top/bottom).', 'laboom'),
            'id'                => 'page_title_padding',
            'type'              => 'spacing',
            'mode'              => 'padding',
            'units'             => array( 'px'),
            'top'               => true,
            'right'             => false,
            'bottom'            => true,
            'left'              => false,
            'output'            => array( '#page-title' ),

        ),
    )
));
/* Breadcrumb */
Redux::setSection($opt_name, array(
    'icon' => 'el-icon-random',
    'title' => esc_html__('Breadcrumb', 'laboom'),
    'subsection' => true,
    'fields' => array(
        array(
            'title'          => esc_html__('Enable breadcrumbs', 'laboom'),
            'id'                => 'enable_breadcrumb',
            'type'              => 'switch',
            'default'           => false,
        ),
        array(
            'subtitle' => esc_html__('The text before the breadcrumb home.', 'laboom'),
            'id' => 'breacrumb_home_prefix',
            'type' => 'text',
            'title' => esc_html__('Breadcrumb Home Prefix', 'laboom'),
            'default' => esc_html__('Home', 'laboom'),
            'required'          => array( 'enable_breadcrumb', '=', 1 )
        )
    )
));
/*woocomerce*/
Redux::setSection($opt_name, array(
    'title' => esc_html__('Shop', 'laboom'),
    'icon' => 'el el-shopping-cart',
    'fields' => array(
        array(
            'title'          => esc_html__('Enable breadcrumbs', 'laboom'),
            'id'                => 'shop_enable_breadcrumb',
            'type'              => 'switch',
            'default'           => false,
        ),
        array(
            'title'             => esc_html__('Background Shop', 'laboom'),
            'id'                => 'background_woo_all',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array( 'body.woocommerce' ),

        ),
        array(
            'title'             => esc_html__('Background for page title', 'laboom'),
            'id'                => 'background_shop_title',
            'type'              => 'media',
        ),
        array(
            'id'       => 'shop_layout',
            'type'     => 'button_set',
            'title'    => esc_html__('Shop Left', 'laboom'),
            'subtitle' => esc_html__('Shop Category Layout', 'laboom'),
            'options' => array(
                'fullwidth' => 'Full width',
                'sidebar_left' => 'Sidebar Left',
                'sidebar_right' => 'Sidebar Right',
            ),
            'default' => 'fullwidth',
        ),
        array(
            'title' => esc_html__('Products displayed per page', 'laboom'),
            'id' => 'product_per_page',
            'type' => 'slider',
            'subtitle' => esc_html__('Number product to show', 'laboom'),
            'default' => 12,
            'min'  => 6,
            'step' => 1,
            'max' => 50,
        ),
        array(
            'id'       => 'shop_column',
            'type'     => 'button_set',
            'title'    => esc_html__('Shop Column', 'laboom'),
            'options' => array(
                '3column' => '3 Column (Default)',
                '4column' => '4 Column',
            ),
            'default' => '3column'
        ),
          array(
              'id' => 'term-chose-page',
              'type' => 'select',
              'title' => esc_html__('Select A Terms & Conditions Page', 'laboom'),
              'data'  => 'pages',
          ),
    )
));
/**
 * Page 404
 *
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Page 404', 'laboom'),
    'icon' => 'el-icon-map-marker',
    'fields' => array(
        array(
            'id'       => 'page404_background',
            'type'     => 'background',
            'title' => esc_html__('Select Background for Page 404', 'laboom'),
            'background-repeat' => false,
            'background-position'=> false,
            'background-size'=> false,
            'output'=> array('.cms-content404'),
            'default' => array(
                'background-image'=>get_template_directory_uri().'/assets/images/page404.jpg',

            ),

        ),

    )
));

/**
 * Content
 *
 * css color.
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Content', 'laboom'),
    'icon' => 'el-icon-pencil',
    'fields' => array(
    )
));

/* archive */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Archive Standard', 'laboom'),
    'icon' => 'el-icon-list',
    'subsection' => true,
    'fields' => array(
        array(
            'id'                => 'archive_layout',
            'title'             => esc_html__('Layouts', 'laboom'),
            'subtitle'          => esc_html__('select a layout for archive, search, index...', 'laboom'),
            'default'           => 'right',
            'type'              => 'image_select',
            'options'           => array(
                                        'left' => get_template_directory_uri().'/assets/images/content/right.png',
                                        'full' => get_template_directory_uri().'/assets/images/content/full.png',
                                        'right' => get_template_directory_uri().'/assets/images/content/left.png',
                                    )
        ),
        array(
            'title'             => esc_html__('Background', 'laboom'),
            'subtitle'          => esc_html__('Body Archive background', 'laboom'),
            'id'                => 'archive_background',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-image'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array( 'body[class*="page-template-blog"]' ),
        ),
        array(
            'subtitle'          => esc_html__('Show author.', 'laboom'),
            'id'                => 'archive_author',
            'type'              => 'switch',
            'title'             => esc_html__('Author', 'laboom'),
            'default'           => true,
        ),
        array(
            'subtitle'          => esc_html__('Show categories.', 'laboom'),
            'id'                => 'archive_categories',
            'type'              => 'switch',
            'title'             => esc_html__('Categories', 'laboom'),
            'default'           => false,
        ),
        array(
            'subtitle'          => esc_html__('Show tags.', 'laboom'),
            'id'                => 'archive_tag',
            'type'              => 'switch',
            'title'             => esc_html__('Tags', 'laboom'),
            'default'           => false,
        ),
        array(
            'subtitle'          => esc_html__('Show comment count.', 'laboom'),
            'id'                => 'archive_comment',
            'type'              => 'switch',
            'title'             => esc_html__('Comment', 'laboom'),
            'default'           => true,
        ),
        array(
            'subtitle'          => esc_html__('Show date time.', 'laboom'),
            'id'                => 'archive_date',
            'type'              => 'switch',
            'title'             => esc_html__('Date', 'laboom'),
            'default'           => false,
        ),
    )
));
Redux::setSection($opt_name, array(
    'title' => esc_html__('Archive Grid', 'laboom'),
    'icon' => 'el-icon-list',
    'subsection' => true,
    'fields' => array(
        array(
            'subtitle'          => esc_html__('Show categories.', 'laboom'),
            'id'                => 'archive_grid_categories',
            'type'              => 'switch',
            'title'             => esc_html__('Categories', 'laboom'),
            'default'           => true,
        ),
        array(
            'subtitle'          => esc_html__('Show date time.', 'laboom'),
            'id'                => 'archive_grid_date',
            'type'              => 'switch',
            'title'             => esc_html__('Date', 'laboom'),
            'default'           => true,
        ),
    )
));
/* Single */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Single', 'laboom'),
    'icon' => 'el-icon-file-edit',
    'subsection' => true,
    'fields' => array(
        array(
            'id'                => 'single_layout',
            'title'             => esc_html__('Layouts', 'laboom'),
            'subtitle'          => esc_html__('select a layout for single...', 'laboom'),
            'default'           => 'right',
            'type'              => 'image_select',
            'options'           => array(
                'left' => get_template_directory_uri().'/assets/images/content/right.png',
                'full' => get_template_directory_uri().'/assets/images/content/full.png',
                'right' => get_template_directory_uri().'/assets/images/content/left.png',
            )
        ),
        array(
            'subtitle'          => esc_html__('Show author.', 'laboom'),
            'id'                => 'single_author',
            'type'              => 'switch',
            'title'             => esc_html__('Author', 'laboom'),
            'default'           => true,
        ),
        array(
            'subtitle'          => esc_html__('Show categories.', 'laboom'),
            'id'                => 'single_categories',
            'type'              => 'switch',
            'title'             => esc_html__('Categories', 'laboom'),
            'default'           => false,
        ),
        array(
            'subtitle'          => esc_html__('Show tags.', 'laboom'),
            'id'                => 'single_tag',
            'type'              => 'switch',
            'title'             => esc_html__('Tags', 'laboom'),
            'default'           => false,
        ),
        array(
            'subtitle'          => esc_html__('Show comment count.', 'laboom'),
            'id'                => 'single_comment',
            'type'              => 'switch',
            'title'             => esc_html__('Comment', 'laboom'),
            'default'           => true,
        ),
        array(
            'subtitle'          => esc_html__('Show date time.', 'laboom'),
            'id'                => 'single_date',
            'type'              => 'switch',
            'title'             => esc_html__('Date', 'laboom'),
            'default'           => false,
        )

    )
));
/**
 * admin social link
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Admin Social Link', 'laboom'),
    'icon' => 'el el-group-alt',
    'fields' => array(
        array(
            'subtitle' => '',
            'id' => '_admin_fb',
            'type' => 'text',
            'title' => 'Facebook',
            'default' => 'http://facebook.com/'
        ),
        array(
            'subtitle' => '',
            'id' => '_admin_tw',
            'type' => 'text',
            'title' => 'Twitter',
            'default' => 'https://twitter.com/'
        ),
        array(
            'subtitle' => '',
            'id' => '_admin_google',
            'type' => 'text',
            'title' => 'Google',
            'default' => 'https://plus.google.com/'
        ),


    )
));
/**
 * Button config
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Button', 'laboom'),
    'icon' => 'el-icon-map-marker',
    'fields' => array(
        array(
            'title'             => esc_html__('Background color for button', 'laboom'),
            'id'                => 'btn_background',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-image'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array('body .btn,body button,body input[type="submit"]'),
            'default'  => array(
                'background-color' => '',
            )
        ),
        array(
            'id'                => 'btn_color',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Text Color', 'laboom' ),
            'output'            => array('body .btn,body button,body input[type="submit"]'),
            'default'   => array(
                'color'     => '',
                'alpha'     => 1
            ),
        ),
        array(
            'id'                => 'btn_border_color',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Border Color', 'laboom' ),
            'default'   => array(
                'color'     => '',
                'alpha'     => 1
            ),
        ),
    )
));
Redux::setSection($opt_name, array(
    'title' => esc_html__('Button hover', 'laboom'),
    'icon' => 'el-icon-map-marker',
    'subsection' => true,
    'fields' => array(
        array(
            'title'             => esc_html__('Background color for button when hover', 'laboom'),
            'id'                => 'btn_background_hover',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-image'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array('body #content .btn:hover,body #content button:hover,body #content input[type="submit"]:hover,.single-product .cs-product-wrap .entry-summary .cart .add_to_wishlist:hover,.woocommerce a.button:hover,.woocommerce .return-to-shop a.button:hover, .woocommerce-checkout #payment #place_order:hover,.woocommerce table.shop_table td.actions .wc-proceed-to-checkout a:hover,#cshero-header-top .header-right .nav-button-icon .widget_shopping_cart .widget_shopping_cart_content p.buttons .button:hover'),
            'default'  => array(
                'background-color' => '#20202f',
            )
        ),
        array(
            'id'                => 'btn_color_hover',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Text Color hover', 'laboom' ),
            'output'            => array('body #content .btn:hover,body #content button:hover,body #content input[type="submit"]:hover,.single-product .cs-product-wrap .entry-summary .cart .add_to_wishlist:hover'),
            'default'   => array(
                'color'     => '#fff',
                'alpha'     => 1
            ),
        ),
        array(
            'id'                => 'btn_border_color_hover',
            'type'              => 'color_rgba',
            'title'             => esc_html__( 'Border Color hover', 'laboom' ),
            'default'   => array(
                'color'     => '#20202f',
                'alpha'     => 1
            ),

        ),
    )
));
/**
 * Styling
 * 
 * css color.
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Styling', 'laboom'),
    'icon' => 'el-icon-adjust',
    'fields' => array(
        array(
            'subtitle' => esc_html__('Set main color.', 'laboom'),
            'id' => 'primary_color',
            'type' => 'color',
            'title' => esc_html__('Primary Color', 'laboom'),
            'default' => '#e4b95b'
        ),
        array(
            'subtitle' => esc_html__('Set secondary color.', 'laboom'),
            'id' => 'secondary_color',
            'type' => 'color',
            'title' => esc_html__('Secondary Color', 'laboom'),
            'default' => '#20202f'
        ),
        array(
            'subtitle' => esc_html__('Set third color.', 'laboom'),
            'id' => 'third_color',
            'type' => 'color',
            'title' => esc_html__('third Color', 'laboom'),
            'default' => '#f4f2ed'
        ),
        array(
            'subtitle' => esc_html__('Set fourth color.', 'laboom'),
            'id' => 'fourth_color',
            'type' => 'color',
            'title' => esc_html__('Fourth Color', 'laboom'),
            'default' => '#383848'
        ),
        array(
            'id'       => 'link_color',
            'type'     => 'link_color',
            'title'    => esc_html__( 'Links Color', 'laboom' ),
            'subtitle' => esc_html__( 'Select Links Color Option', 'laboom' ),
            'regular'   => true,
            'hover'     => true,
            'active'    => false,
            'visited'   => false,
            'output'   => array( 'a' ),
            'default'  => array(
                'regular'  => '#e4b95b',
                'hover'    => '#20202f',
            ),
        ),
    )
));

/**
 * Typography
 * 
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Typography', 'laboom'),
    'icon' => 'el-icon-text-width',
    'fields' => array(
        array(
            'id' => 'font_body',
            'type' => 'typography',
            'title' => esc_html__('Body Font', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'output'  => array('body'),
            'units' => 'px',
            'text-align' =>false,
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#959393',
                'font-style' => '400',
                'google' => true,
                'font-family' => 'Source Sans Pro',
                'font-size' => '15px',
                'line-height' => '24px',
            )
        ),
        array(
            'id' => 'font_h1',
            'type' => 'typography',
            'title' => esc_html__('H1', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'output'  => array('h1'),
            'units' => 'px',
            'text-align' =>false,
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#102035',
                'font-style' => '500',
                'font-family' => 'Quicksand',
                'google' => true,
                'font-size' => '45px',
                'line-height' => '60px',
            )
        ),
        array(
            'id'             => 'margin_h1',
            'type'           => 'spacing',
            'output'         => array('h1'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin Bottom H1', 'laboom'),
            'top'     => false,
            'left'     => false,
            'right'     => false,
            'default'            => array(
                'margin-bottom'    => '15px',
            )
        ),

        array(
            'id' => 'font_h2',
            'type' => 'typography',
            'title' => esc_html__('H2', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'text-align' =>false,
            'output'  => array('h2'),
            'units' => 'px',
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#102035',
                'font-style' => '500',
                'font-family' => 'Quicksand',
                'google' => true,
                'font-size' => '40px',
                'line-height' => '50px',
            )
        ),
        array(
            'id'             => 'margin_h2',
            'type'           => 'spacing',
            'output'         => array('h2'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin Bottom H2', 'laboom'),
            'top'     => false,
            'left'     => false,
            'right'     => false,
            'default'            => array(
                'margin-bottom'    => '15px',
            )
        ),
        array(
            'id' => 'font_h3',
            'type' => 'typography',
            'title' => esc_html__('H3', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'text-align' =>false,
            'output'  => array('h3'),
            'units' => 'px',
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#383848',
                'font-style' => '500',
                'font-family' => 'Quicksand',
                'google' => true,
                'font-size' => '26px',
                'line-height' => '35px',
            )
        ),
        array(
            'id'             => 'margin_h3',
            'type'           => 'spacing',
            'output'         => array('h3'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin Bottom H3', 'laboom'),
            'top'     => false,
            'left'     => false,
            'right'     => false,
            'default'            => array(
                'margin-bottom'    => '15px',
            )
        ),
        array(
            'id' => 'font_h4',
            'type' => 'typography',
            'title' => esc_html__('H4', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'text-align' =>false,
            'output'  => array('h4'),
            'units' => 'px',
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#102035',
                'font-style' => '500',
                'font-family' => 'Quicksand',
                'google' => true,
                'font-size' => '20px',
                'line-height' => '35px',
            )
        ),
        array(
            'id'             => 'margin_h4',
            'type'           => 'spacing',
            'output'         => array('h4'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin Bottom H4', 'laboom'),
            'top'     => false,
            'left'     => false,
            'right'     => false,
            'default'            => array(
                'margin-bottom'    => '15px',
            )
        ),
        array(
            'id' => 'font_h5',
            'type' => 'typography',
            'title' => esc_html__('H5', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'text-align' =>false,
            'output'  => array('h5'),
            'units' => 'px',
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#102035',
                'font-style' => '500',
                'font-family' => 'Quicksand',
                'google' => true,
                'font-size' => '20px',
                'line-height' => '30px',
            )
        ),
        array(
            'id'             => 'margin_h5',
            'type'           => 'spacing',
            'output'         => array('h5'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin Bottom H5', 'laboom'),
            'top'     => false,
            'left'     => false,
            'right'     => false,
            'default'            => array(
                'margin-bottom'    => '15px',
            )
        ),
        array(
            'id' => 'font_h6',
            'type' => 'typography',
            'title' => esc_html__('H6', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'text-align' =>false,
            'all_styles' => true,
            'output'  => array('h6'),
            'units' => 'px',
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '#102035',
                'font-style' => '500',
                'font-family' => 'Quicksand',
                'google' => true,
                'font-size' => '18px',
                'line-height' => '36px',
            )
        ),
        array(
            'id'             => 'margin_h6',
            'type'           => 'spacing',
            'output'         => array('h6'),
            'mode'           => 'margin',
            'units'          => array('px'),
            'title'          => esc_html__('Margin Bottom H6', 'laboom'),
            'top'     => false,
            'left'     => false,
            'right'     => false,
            'default'            => array(
                'margin-bottom'    => '15px',
            )
        ),
    )
));

/* extra font. */
$custom_font_1 = Redux::getOption($opt_name, 'google-font-selector-1');
$custom_font_1 = !empty($custom_font_1) ? explode(',', $custom_font_1) : array();

Redux::setSection($opt_name, array(
    'title' => esc_html__('Extra Fonts', 'laboom'),
    'icon' => 'el el-fontsize',
    'subsection' => true,
    'fields' => array(
        array(
            'id' => 'google-font-1',
            'type' => 'typography',
            'title' => esc_html__('Custom Font', 'laboom'),
            'google' => true,
            'font-backup' => true,
            'all_styles' => true,
            'output'  =>  $custom_font_1,
            'units' => 'px',
            'subtitle' => esc_html__('Typography option with each property can be called individually.', 'laboom'),
            'default' => array(
                'color' => '',
                'font-style' => '',
                'font-weight' => '',
                'font-family' => '',
                'google' => true,
                'font-size' => '',
                'line-height' => '',
                'text-align' => ''
            )
        ),
        array(
            'id' => 'google-font-selector-1',
            'type' => 'textarea',
            'title' => esc_html__('Selector 1', 'laboom'),
            'subtitle' => esc_html__('add html tags ID or class (body,a,.class,#id)', 'laboom'),
            'validate' => 'no_html',
            'default' => '',
        )
    )
));
/**
 * Social Link
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Social Link', 'laboom'),
    'icon' => 'el el-smiley',
    'subsection' => false,
    'fields' => array(
        array(
            'id' => 'social_facebook_url',
            'type' => 'text',
            'title' => esc_html__('Facebook URL', 'laboom'),
            'default' => '',
        ),
        array(
            'id' => 'social_twitter_url',
            'type' => 'text',
            'title' => esc_html__('Twitter URL', 'laboom'),
            'default' => '',
        ),
        array(
            'id' => 'social_linkedin_url',
            'type' => 'text',
            'title' => esc_html__('Likedin URL', 'laboom'),
            'default' => '',
        ),
        array(
            'id' => 'social_instagram_url',
            'type' => 'text',
            'title' => esc_html__('Instagram URL', 'laboom'),
            'default' => '',
        ),
        array(
            'id' => 'social_google_url',
            'type' => 'text',
            'title' => esc_html__('Google plus URL', 'laboom'),
            'default' => '',
        ),
        array(
            'id' => 'social_printest_url',
            'type' => 'text',
            'title' => esc_html__('Printest', 'laboom'),
            'default' => '',
        ),
        array(
            'id' => 'social_dribbble_url',
            'type' => 'text',
            'title' => esc_html__('Dribbble', 'laboom'),
            'default' => '',
        ),

    )
));

/**
 * Footer
 *
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Footer', 'laboom'),
    'icon' => 'el el-website',
    'fields' => array(
        array(
            'id'                => 'footer_layout',
            'title'             => esc_html__('Layouts', 'laboom'),
            'subtitle'          => esc_html__('select a layout for footer', 'laboom'),
            'default'           => '1',
            'type'              => 'image_select',
            'options'           => array(
                '1' => get_template_directory_uri().'/assets/images/footer/footer1.jpg',
                '2' => get_template_directory_uri().'/assets/images/footer/footer2.jpg',
                '3' => get_template_directory_uri().'/assets/images/footer/footer3.jpg',
                '4' => get_template_directory_uri().'/assets/images/footer/footer4.jpg',
                '5' => get_template_directory_uri().'/assets/images/footer/footer5.jpg',
            )
        ),
        array(
            'title' => esc_html__('Social', 'laboom'),
            'id'      => 'cms_footer_social',
            'type'    => 'sorter',
            'desc'    => 'Choose social networks which are displayed on footer',
            'options' => array(
                'enabled'  => array(
                    'facebook'  => 'Facebook',
                    'twitter'   => 'Twitter',
                    'dribbble'  => 'Dribbble',
                    'instagram'  => 'Instagram',
                    'google'  => 'Google',
                    'printest'  => 'Printest',
                ),
                'disabled' => array(

                )
            ),
        ),
        array(
            'title' => esc_html__('Footer Top', 'laboom'),
            'type'  => 'section',
            'id' => 'footer_top_start',
            'indent' => true
        ),

        array(
            'title'             => esc_html__('Background', 'laboom'),
            'subtitle'          => esc_html__('Footer top background.', 'laboom'),
            'id'                => 'footer_top_background',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'preview'	=>false,
            'output'            => array( 'footer #footer-top' ),
        ),
        array(
            'title' => esc_html__('Logo', 'laboom'),
            'id' => 'footer_bottom_logo',
            'type' => 'media',
            'url' => false,
            'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-footer.png'
            ),

        ),
        array(
            'id'=>'cms_footer_address',
            'type' => 'textarea',
            'title' => esc_html__('Footer Address', 'laboom'),
            'validate' => 'html_custom',
            'default' => '',
            'subtitle' => esc_html__('Custom HTML Allowed (a,br,em,strong,span,p,div,h1->h6', 'laboom'),
            'allowed_html' => array(
                'a' => array(
                    'href' => array(),
                    'title' => array(),
                    'class' => array(),
                ),
                'br' => array(),
                'em' => array(),
                'strong' => array(),
                'span' => array(),
                'p' => array(),
                'div' => array(
                    'class' => array()
                ),
                'h1' => array(
                    'class' => array()
                ),
                'h2' => array(
                    'class' => array()
                ),
                'h3' => array(
                    'class' => array()
                ),
                'h4' => array(
                    'class' => array()
                ),
                'h5' => array(
                    'class' => array()
                ),
                'h6' => array(
                    'class' => array()
                ),
                'ul' => array(
                    'class' => array()
                ),
                'li' => array(),
            ),
        ),

        array(
            'title'             => esc_html__('Title widget color column 1', 'laboom'),
            'id'                => 'footer_top_title_widget_color1',
            'type'              => 'color',
            'output'            => array( 'footer #footer-top .footer-top1 .wg-title' ),

        ),
        array(
            'title'             => esc_html__('Title widget color column 2', 'laboom'),
            'id'                => 'footer_top_title_widget_color2',
            'type'              => 'color',
            'output'            => array( 'footer #footer-top .footer-top2 .wg-title' ),

        ),
        array(
            'title'             => esc_html__('Title widget color column 3', 'laboom'),
            'id'                => 'footer_top_title_widget_color3',
            'type'              => 'color',
            'output'            => array( 'footer #footer-top .footer-top3 .wg-title' ),

        ),
        array(
            'title'             => esc_html__('Text widget color', 'laboom'),
            'id'                => 'footer_top_text_widget_color',
            'type'              => 'color',
            'output'            => array( 'footer #footer-top .wg-title' ),

        ),
        array(
            'title'             => esc_html__('Social color', 'laboom'),
            'subtitle'          => esc_html__('Apply for column 3 og footer 3.', 'laboom'),
            'id'                => 'footer_top_social_color',
            'type'              => 'link_color',
            'active'            => false,
            'visited'           => false,
            'output'            => array( '#footer-top .footer-top3 .cms-footer-social li a' ),

        ),
        array(
            'title'             => esc_html__('Subtitle Widget color for column 2', 'laboom'),
            'id'                => 'footer_top_subtitle_widget_color2',
            'type'              => 'color',
            'output'            => array( 'footer #footer-top .footer-top2 .wg-subtitle' ),

        ),

        array(
            'title'             => esc_html__('Text color', 'laboom'),
            'id'                => 'footer_top_text_color',
            'type'              => 'color',
            'output'            => array( 'footer #footer-top' ),

        ),
        array(
            'id'                => 'footer_top_link_color',
            'type'              => 'link_color',
            'title'             => esc_html__( 'Links Color', 'laboom' ),
            'subtitle'          => esc_html__( 'Select links color in footer top', 'laboom' ),
            'regular'           => true,
            'hover'             => true,
            'active'            => false,
            'visited'           => false,
            'output'            => array( '#footer-top ul > li > a,#footer-top a,#footer-top .widget_nav_menu ul li a' ),

        ),
        array(
            'title' => esc_html__('Footer Bottom', 'laboom'),
            'type'  => 'section',
            'id' => 'footer_bottom_start',
            'indent' => true
        ),

        array(
            'title'             => esc_html__('Background', 'laboom'),
            'subtitle'          => esc_html__('Footer bottom background.', 'laboom'),
            'id'                => 'footer_bottom_background',
            'type'              => 'background',
            'background-repeat'	=>	false,
            'background-position'	=>	false,
            'background-clip'	=>	false,
            'background-origin'	=>	false,
            'background-size'	=>false,
            'background-attachment'	=>false,
            'preview'	=>false,
            'output'            => array( 'footer #footer-bottom' )
        ),
        array(

            'id' => 'footer_copyright',
            'type' => 'textarea',
            'title' => 'Copyright',
            'default' => '',
            'allowed_html' => array(
                'a' => array(
                    'href' => array(),
                    'title' => array()
                ),
                'br' => array(),
                'p' => array(),
                'span' => array(),

            ),
        ),
        array(
            'title' => esc_html__('Logo Footer', 'laboom'),
            'id' => 'footer_bottom_logo_logo2',
            'type' => 'media',
            'url' => false,
            'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-footer2.png'
            ),

        ),
        array(
            'title'             => esc_html__('Text color', 'laboom'),
            'id'                => 'footer_bottom_text_color',
            'type'              => 'color',
            'output'            => array( 'footer #footer-bottom' )
        ),
        array(
            'title'             => esc_html__('Border social color', 'laboom'),
            'id'                => 'footer_border_social_color',
            'type'              => 'color',
        ),

        array(
            'title' => esc_html__('Footer Google Map', 'laboom'),
            'type'  => 'section',
            'id' => 'footer_google_map_section',
            'indent' => true
        ),
        array(
            'title'             => esc_html__('Google Map Api key', 'laboom'),
            'id'                => 'map_api',
            'type'              => 'text',
            'placeholder'              => 'AIzaSyBAW_lHcTkvGxTvTSrg-a07ZvtYmDze7tI',
        ),
        array(
            'title'             => esc_html__('Address', 'laboom'),
            'id'                => 'map_address',
            'type'              => 'text',
        ),
        array(
            'title'             => esc_html__('Coordinate', 'laboom'),
            'id'                => 'map_coordinate',
            'type'              => 'text',
            'placeholder'              => '40.705565,-74.1180858',
        ),
        array(
            'title'             => esc_html__('Marker Coordinate', 'laboom'),
            'id'                => 'map_markercoordinate',
            'type'              => 'text',
            'placeholder'              => '40.705565,-74.1180858',

        ),
        array(
            'title'             => esc_html__('Marker Icon', 'laboom'),
            'id'                => 'map_markericon',
            'type'              => 'media',
        ),
    )
));
/**
 * Optimal Core
 * 
 * Optimal options for theme. optimal speed
 * @author Fox
 */
Redux::setSection($opt_name, array(
    'title' => esc_html__('Optimal Core', 'laboom'),
    'icon' => 'el-icon-idea',
    'fields' => array(
        array(
            'subtitle' => esc_html__('no minimize , generate css over time...', 'laboom'),
            'id' => 'dev_mode',
            'type' => 'switch',
            'title' => esc_html__('Dev Mode (not recommended)', 'laboom'),
            'default' => false
        )
    )
));