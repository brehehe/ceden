<?php
/**
 * Meta box config file
 */
if (! class_exists('MetaFramework')) {
    return;
}
function wp_organic_build_shortcode_rev_slider()
{
    if (class_exists('RevSlider')) {

        $slider = new RevSlider();
        $arrSliders = $slider->getArrSliders();

        $revsliders = array(''=>'');
        if ($arrSliders) {
            foreach ($arrSliders as $slider) {
                /* @var $slider RevSlider */
                $revsliders[$slider->getAlias()] = $slider->getTitle();
            }
        } else {
            $revsliders[__('No sliders found', 'laboom')] = 0;
        }
        return $revsliders;
    }
}
add_action('admin_head', 'wp_serenity_spa_metabox');

function wp_serenity_spa_metabox() {
    wp_enqueue_style('metabox', get_template_directory_uri() . '/inc/options/css/metabox.css');
}
$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name' => apply_filters('opt_meta', 'opt_meta_options'),
    // Set a different name for your global variable other than the opt_name
    'dev_mode' => false,
    // Allow you to start the panel in an expanded way initially.
    'open_expanded' => false,
    // Disable the save warning when a user changes a field
    'disable_save_warn' => true,
    // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
    'save_defaults' => false,

    'output' => false,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag' => false,
    // Show the time the page took to load, etc
    'update_notice' => false,
    // 'disable_google_fonts_link' => true, // Disable this in case you want to create your own google fonts loader
    'admin_bar' => false,
    // Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu' => false,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer' => false,
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export' => false,
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn' => false,
    // save meta to multiple keys.
    'meta_mode' => 'multiple'
);

// -> Set Option To Panel.
MetaFramework::setArgs($args);

add_action('admin_init', 'laboom_meta_boxs');

MetaFramework::init();

function laboom_meta_boxs()
{

    /** page options */
    MetaFramework::setMetabox(array(
        'id' => '_page_main_options',
        'label' => esc_html__('Page Setting', 'laboom'),
        'post_type' => 'page',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Header top', 'laboom'),
                'id' => 'tab-page-header',
                'icon' => 'el el-credit-card',
                'fields' => array(
                    array(
                        'id'                => 'custom_enable_header_top',
                        'type'              => 'switch',
                        'title'             => esc_html__('Custom Enable header Top', 'laboom'),
                        'subtitle'          => esc_html__( 'Apply for header layout 4 and 8 and 9', 'laboom' ),
                        'default'           => false,
                    ),
                    array(
                        'id'                => 'enable_header_top',
                        'type'              => 'switch',
                        'title'             => esc_html__('Enable header Top', 'laboom'),
                        'default'           => false,
                        'required'          => array( 'custom_enable_header_top', '=', '1' )
                    ),
                    array(
                        'id'                => 'header_top_layout',
                        'title'             => esc_html__('Layouts', 'laboom'),
                        'subtitle'          => esc_html__('select a layout for header top', 'laboom'),
                        'default'           => 'default',
                        'type'              => 'select',
                        'options'  => array(
                            '1' => 'Layout 1',
                            '2' => 'Layout 2',
                        ),
                        'default'  => '1',
                        'required'          =>array(
                            array( 'custom_enable_header_top', '=', 1 ),
                            array( 'enable_header_top', '=', 1 )
                        )
                    ),
                    array(
                        'id'                => 'header_top_color_hover',
                        'type'              => 'color',
                        'title'             => esc_html__( 'Text Color Top Hover', 'laboom' ),
                        'subtitle'          => esc_html__( 'Select text color hover in header', 'laboom' ),
                        'required'          =>array(
                            array( 'custom_enable_header_top', '=', 1 ),
                            array( 'enable_header_top', '=', 1 )
                        )
                    ),
                ),
            ),
            array(
                'title' =>esc_html__('Header', 'laboom'),
                'id' => 'tab-page-header',
                'icon' => 'el el-credit-card',
                'fields' => array(
                    array(
                        'id'       => 'custom_header',
                        'type'     => 'button_set',
                        'title'    => esc_html__('Custom', 'laboom'),
                        'options' => array(
                            '1' => 'Yes',
                            '' => 'No',
                        ),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_menu',
                        'type' => 'select',
                        'title' =>esc_html__('Select Menu', 'laboom'),
                        'subtitle' =>esc_html__('custom menu for current page', 'laboom'),
                        'options' => laboom_get_nav_menu(),
                        'default' => '',
                        'required' => array( 'custom_header', '=', '1' )
                    ),
                    array(
                        'id' => 'header_layout',
                        'title' => esc_html__('Layouts', 'laboom'),
                        'subtitle' => esc_html__('select a layout for header', 'laboom'),
                        'default' => 'default',
                        'type' => 'image_select',
                        'options' => array(
                            'default' => get_template_directory_uri() . '/assets/images/header/h-style-1.jpg',
                            'trans' => get_template_directory_uri() . '/assets/images/header/h-style-2.jpg',
                            'header3' => get_template_directory_uri().'/assets/images/header/h-style-3.jpg',
                            'header4' => get_template_directory_uri().'/assets/images/header/h-style-4.jpg',
                            'header5' => get_template_directory_uri().'/assets/images/header/h-style-5.jpg',
                        ),
                        'required' => array( 'custom_header', '=', '1' )
                    ),
                    array(
                        'title' => esc_html__('Select Logo Image', 'laboom'),
                        'id' => 'page_logo',
                        'type' => 'media',
                        'url' => false,
                        'default' => '',
                        'required' => array( 'custom_header', '=', '1' )
                    ),
                    array(
                        'subtitle'          => esc_html__('Set max height for logo.', 'laboom'),
                        'id'                => 'logo_max_height',
                        'type'              => 'dimensions',
                        'units'             => array('px'),
                        'width'             => false,
                        'title'             => esc_html__('Logo Height', 'laboom'),
                        'required' => array( 'custom_header', '=', '1' )
                    ),
                    array(
                        'id'                => 'header_bg_color',
                        'type'              => 'color',
                        'title'             => esc_html__( 'Background Color for header', 'laboom' ),
                        'required' => array( 'custom_header', '=', '1' )
                    ),
                    array(
                        'id'                => 'header_text_color',
                        'type'              => 'color',
                        'title'             => esc_html__( 'Text Color', 'laboom' ),
                        'subtitle'          => esc_html__( 'Select text color in header', 'laboom' ),
                        'required' => array( 'custom_header', '=', '1' )
                    ),
                    array(
                        'id'                => 'header_link_color',
                        'type'              => 'link_color',
                        'title'             => esc_html__( 'Links Color', 'laboom' ),
                        'subtitle'          => esc_html__( 'Select links color in header', 'laboom' ),
                        'regular'           => true,
                        'hover'             => true,
                        'active'            => false,
                        'visited'           => false,
                        'required' => array( 'custom_header', '=', '1' )

                    ),
                )
            ),
            array(
                'title' =>esc_html__('Page', 'laboom'),
                'id' => 'tab-page-padding',
                'icon' => 'el el-map-marker',
                'fields' => array(
                    array(
                        'title'             => esc_html__('Padding', 'laboom'),
                        'subtitle'          => esc_html__('Main content padding (top/bottom).', 'laboom'),
                        'id'                => 'page_padding',
                        'type'              => 'spacing',
                        'mode'              => 'padding',
                        'units'             => array( 'px'),
                        'top'               => true,
                        'right'             => false,
                        'bottom'            => true,
                        'left'              => false,
                    ),

                )
            ),
            array(
                'title' =>esc_html__('Body', 'laboom'),
                'id' => 'tab-body-padding',
                'icon' => 'el el-map-marker',
                'fields' => array(
                    array(
                        'title'             => esc_html__('Layout', 'laboom'),
                        'subtitle'          => esc_html__('Full width / Boxed.', 'laboom'),
                        'id'                => 'body_layout',
                        'type'              => 'button_set',
                        'options'           => array(
                            1 => esc_html__('Full width', 'laboom'),
                            0 => esc_html__('Boxed', 'laboom')
                        ),
                        'default'           => 1
                    ),
                    array(
                        'title'             => esc_html__('Body Background', 'laboom'),
                        'subtitle'          => esc_html__('Body background color', 'laboom'),
                        'id'                => 'body_background_color',
                        'type'              => 'background',
                        'background-clip'	=>	false,
                        'background-origin'	=>	false,
                        'preview'	=>false,
                    ),
                    array(
                        'title'             => esc_html__('Body Padding', 'laboom'),
                        'id'                => 'body_padding',
                        'type'              => 'spacing',
                        'mode'              => 'padding',
                        'units'             => array( 'px'),
                    ),
                )
            ),
            array(
                'title' =>esc_html__('Page Title & BC', 'laboom'),
                'id' => 'tab-page-title-bc',
                'icon' => 'el el-map-marker',
                'fields' => array(
                    array(
                        'id'       => 'custom_page_title',
                        'type'     => 'button_set',
                        'title'    => esc_html__('Custom Layout', 'laboom'),
                        'options' => array(
                            '1' => 'Yes',
                            '' => 'No',
                        ),
                        'default' => ''
                    ),
                    array(
                        'id' => 'page_title_layout',
                        'title' => esc_html__('Layouts', 'laboom'),
                        'subtitle' => esc_html__('select a layout for page title', 'laboom'),
                        'default' => '',
                        'type' => 'image_select',
                        'options' => array(
                            '' => get_template_directory_uri().'/assets/images/pagetitle/pt-s-0.jpg',
                            '1' => get_template_directory_uri().'/assets/images/pagetitle/pt-s-1.jpg',
                            '2' => get_template_directory_uri().'/assets/images/pagetitle/pt-s-2.jpg',

                        ),
                        'required' => array( 'custom_page_title', '=', '1' )
                    ),
                    array(
                        'title' => esc_html__('Select Background Image', 'laboom'),
                        'id' => 'page_bg_page_title',
                        'type' => 'media',
                        'url' => false,
                        'default' => '',
                        'required' => array( 'custom_page_title', '=', '1' )

                    ),
                    array(
                        'id' => 'page_title_padding',
                        'type'              => 'spacing',
                        'mode'              => 'padding',
                        'units'             => array( 'px'),
                        'top'               => true,
                        'right'             => false,
                        'bottom'            => true,
                        'left'              => false,
                        'title' => esc_html__('Page Title Padding', 'laboom'),
                        'required' => array( 'custom_page_title', '=', '1' )
                    ),
                    array(
                        'id' => 'page_title_text',
                        'type' => 'text',
                        'title' => esc_html__('Custom Title', 'laboom'),
                        'subtitle' => esc_html__('Custom current page title.', 'laboom'),
                        'required'          => array( 'page_title_layout', '!=', '2' ),
                         'required' => array( 'custom_page_title', '=', '1' )
                    ),
                    array(
                        'title'          => esc_html__('Custom breadcrumbs', 'laboom'),
                        'id'                => 'custom_breadcrumb',
                        'type'              => 'switch',
                        'default'           => false,
                        'required' => array( 'custom_page_title', '=', '1' )
                    ),
                    array(
                        'title'          => esc_html__('Enable breadcrumbs', 'laboom'),
                        'id'                => 'enable_breadcrumb',
                        'type'              => 'switch',
                        'default'           => false,
                        'required'          => array( 'custom_breadcrumb', '=', 1 )
                    ),
                )
            ),
            array(
                'title' =>esc_html__('Blog', 'laboom'),
                'id' => 'tab-page-blog',
                'icon' => 'el el-credit-card',
                'fields' => array(
                    array(
                        'title'=> esc_html__('Choose Revolution Slider', 'laboom'),
                        'id' => 'get_revslide',
                        'label' => esc_html__('Revolution','laboom'),
                        'type' => 'select',
                        'options' => wp_organic_build_shortcode_rev_slider(),
                    ),
                ),
            ),
            array(
                'title' =>esc_html__('Footer', 'laboom'),
                'id' => 'tab-page-footer',
                'icon' => 'el el-credit-card',
                'fields' => array(
                    array(
                        'id'       => 'custom_footer',
                        'type'     => 'button_set',
                        'title'    => esc_html__('Custom', 'laboom'),
                        'options' => array(
                            '1' => 'Yes',
                            '' => 'No',
                        ),
                        'default' => ''
                    ),
                    array(
                        'id'                => 'footer_layout',
                        'title'             => esc_html__('Layouts', 'laboom'),
                        'subtitle'          => esc_html__('select a layout for footer', 'laboom'),
                        'default'           => '2',
                        'type'              => 'image_select',
                        'options'           => array(
                            '1' => get_template_directory_uri().'/assets/images/footer/footer1.jpg',
                            '2' => get_template_directory_uri().'/assets/images/footer/footer2.jpg',
                            '3' => get_template_directory_uri().'/assets/images/footer/footer3.jpg',
                            '4' => get_template_directory_uri().'/assets/images/footer/footer4.jpg',
                            '5' => get_template_directory_uri().'/assets/images/footer/footer5.jpg',
                        ),
                        'required' => array( 'custom_footer', '=', '1' )
                    ),
                    array(
                        'title'             => esc_html__('Background Image', 'laboom'),
                        'subtitle'          => esc_html__('Background image for footer.', 'laboom'),
                        'id'                => 'footer_background_image',
                        'type' => 'media',
                        'url' => false,
                        'default' => '',
                        'required' => array( 'custom_footer', '=', '1' )
                    ),
                    array(
                        'title' => esc_html__('Logo Footer', 'laboom'),
                        'id' => 'footer_bottom_logo_logo2',
                        'type' => 'media',
                        'url' => false,
                        'required' => array( 'custom_footer', '=', '1' )

                    ),
                    array(
                        'id'                => 'footer_top_bg_color',
                        'type'              => 'color_rgba',
                        'title'             => esc_html__( 'Background Color for footer top', 'laboom' ),
                        'required' => array( 'custom_footer', '=', '1' )
                    ),
                    array(
                        'id'                => 'footer_bg_color',
                        'type'              => 'color',
                        'title'             => esc_html__( 'Background Color for footer bottom', 'laboom' ),
                        'required' => array( 'custom_footer', '=', '1' )
                    ),
                    array(
                        'id'                => 'footer_text_color',
                        'type'              => 'color',
                        'title'             => esc_html__( 'Text Color for footer bottom', 'laboom' ),
                        'required' => array( 'custom_footer', '=', '1' )
                    ),
                ),
            ),
            array(
                'title' =>esc_html__('One Page', 'laboom'),
                'id' => 'tab-one-page',
                'icon' => 'el el-download-alt',
                'fields' => array(
                    array(
                        'subtitle' => esc_html__('Enable one page mode for current page.', 'laboom'),
                        'id' => 'page_one_page',
                        'type' => 'switch',
                        'title' => esc_html__('Enable', 'laboom'),
                        'default' => false,
                    ),
                    array(
                        'id'            => 'page_one_page_speed',
                        'type'          => 'slider',
                        'title'         => esc_attr__( 'Speed', 'laboom' ),
                        'default'       => 1000,
                        'min'           => 500,
                        'step'          => 100,
                        'max'           => 5000,
                        'display_value' => 'text',
                        'required' => array('page_one_page', '=', 1)
                    ),
                )
            )
        )
    ));

    /** post options */
    MetaFramework::setMetabox(array(
        'id' => '_post_options',
        'label' => esc_html__('Post Settings', 'laboom'),
        'post_type' => 'post',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => true,
        'sections' => array(
            array(
                'title' => '',
                'id' => 'post-options-layout',
                'fields' => array(
                    array(
                        'id'       => 'enable_post_sidebar',
                        'type'     => 'switch',
                        'title'    => esc_html__('Custom sidebar', 'laboom'),
                        'default' => ''
                    ),
                    array(
                        'id'                => 'single_layout',
                        'title'             => esc_html__('Layouts', 'laboom'),
                        'subtitle'          => esc_html__('select a layout for single...', 'laboom'),
                        'default'           => 'right',
                        'type'              => 'image_select',
                        'options'           => array(
                            'left' => get_template_directory_uri().'/assets/images/content/right.png',
                            'full' => get_template_directory_uri().'/assets/images/content/full.png',
                            'right' => get_template_directory_uri().'/assets/images/content/left.png',
                        ),
                        'required' => array( 'enable_post_sidebar', '=', '1' )
                    )
                )
            )
        )
    ));

    /** post options */
    MetaFramework::setMetabox(array(
        'id' => '_page_post_format_options',
        'label' => esc_html__('Post Format', 'laboom'),
        'post_type' => 'post',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => true,
        'sections' => array(
            array(
                'title' => '',
                'id' => 'color-Color',
                'icon' => 'el el-laptop',
                'fields' => array(
                    array(
                        'id' => 'opt-video-type',
                        'type' => 'select',
                        'title' => esc_html__('Select Video Type', 'laboom'),
                        'subtitle' => esc_html__('Local video, Youtube, Vimeo', 'laboom'),
                        'options' => array(
                            'local' => esc_html__('Upload', 'laboom'),
                            'youtube' => esc_html__('Youtube', 'laboom'),
                            'vimeo' => esc_html__('Vimeo', 'laboom'),
                        )
                    ),
                    array(
                        'id' => 'otp-video-local',
                        'type' => 'media',
                        'url' => true,
                        'mode' => false,
                        'title' => esc_html__('Local Video', 'laboom'),
                        'subtitle' => esc_html__('Upload video media using the WordPress native uploader', 'laboom'),
                        'required' => array('opt-video-type', '=', 'local')
                    ),
                    array(
                        'id' => 'opt-video-youtube',
                        'type' => 'text',
                        'title' => esc_html__('Youtube', 'laboom'),
                        'subtitle' => esc_html__('Load video from Youtube.', 'laboom'),
                        'placeholder' => esc_html__('https://youtu.be/iNJdPyoqt8U', 'laboom'),
                        'required' => array('opt-video-type', '=', 'youtube')
                    ),
                    array(
                        'id' => 'opt-video-vimeo',
                        'type' => 'text',
                        'title' => esc_html__('Vimeo', 'laboom'),
                        'subtitle' => esc_html__('Load video from Vimeo.', 'laboom'),
                        'placeholder' => esc_html__('https://vimeo.com/155673893', 'laboom'),
                        'required' => array('opt-video-type', '=', 'vimeo')
                    ),
                    array(
                        'id' => 'otp-video-thumb',
                        'type' => 'media',
                        'url' => true,
                        'mode' => false,
                        'title' => esc_html__('Video Thumb', 'laboom'),
                        'subtitle' => esc_html__('Upload thumb image using the WordPress native uploader', 'laboom'),
                        'required' => array('opt-video-type', '=', 'local')
                    ),
                    array(
                        'id' => 'otp-audio',
                        'type' => 'media',
                        'url' => true,
                        'mode' => false,
                        'title' => esc_html__('Audio Media', 'laboom'),
                        'subtitle' => esc_html__('Upload audio media using the WordPress native uploader', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-gallery',
                        'type' => 'gallery',
                        'title' => esc_html__('Add/Edit Gallery', 'laboom'),
                        'subtitle' => esc_html__('Create a new Gallery by selecting existing or uploading new images using the WordPress native uploader', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-quote-title',
                        'type' => 'text',
                        'title' => esc_html__('Quote Title', 'laboom'),
                        'subtitle' => esc_html__('Quote title or quote name...', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-quote-subtitle',
                        'type' => 'text',
                        'title' => esc_html__('Quote Subtitle', 'laboom'),
                        'subtitle' => esc_html__('Quote subtitle or quote name...', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-quote-content',
                        'type' => 'textarea',
                        'title' => esc_html__('Quote Content', 'laboom'),
                    ),
                    array(
                        'id' => 'otp-avatar-thumb',
                        'type' => 'media',
                       'title'=>'Select avatar image',
                        'url' => false,
                        'default' => ''
                    ),
                    array(
                        'id' => 'opt-link-format',
                        'type' => 'text',
                        'title' => esc_html__('Link', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-chat-format1',
                        'type' => 'text',
                        'title' => esc_html__('Message 1:', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-chat-format2',
                        'type' => 'text',
                        'title' => esc_html__('Message 2:', 'laboom'),
                    ),
                    array(
                        'id' => 'opt-chat-format3',
                        'type' => 'text',
                        'title' => esc_html__('Message 3:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format4',
                        'type' => 'text',
                        'title' => esc_html__('Message 4:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format5',
                        'type' => 'text',
                        'title' => esc_html__('Message 5:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format6',
                        'type' => 'text',
                        'title' => esc_html__('Message 6:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format7',
                        'type' => 'text',
                        'title' => esc_html__('Message 7:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format8',
                        'type' => 'text',
                        'title' => esc_html__('Message 8:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format9',
                        'type' => 'text',
                        'title' => esc_html__('Message 9:', 'laboom'),
                    ),  array(
                        'id' => 'opt-chat-format10',
                        'type' => 'text',
                        'title' => esc_html__('Message 10:', 'laboom'),
                    ),
                )
            ),
        )
    ));

    /** service options */
    MetaFramework::setMetabox(array(
        'id' => '_service_main_options',
        'label' => esc_html__('Service Setting', 'laboom'),
        'post_type' => 'service',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Icon Service', 'laboom'),
                'id' => 'tab-service-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'icon_class_service',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon class', 'laboom'),
                    ),
                )
            ),

        )
    ));
    /** pricing options */
    MetaFramework::setMetabox(array(
        'id' => '_pricing_main_options',
        'label' => esc_html__('Pricing Setting', 'laboom'),
        'post_type' => 'pricing',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Pricing Subtitle', 'laboom'),
                'id' => 'tab-pricing-st',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id' => 'pricing_subtitle',
                        'title' => esc_html__('Pricing subtitle','laboom'),
                        'type' => 'text',
                    ),
                )
            ),
            array(
                'title' =>esc_html__('Pricing Price', 'laboom'),
                'id' => 'tab-service-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id' => 'pricing_currency',
                        'title' => esc_html__('Currency Unit','laboom'),
                        'type' => 'text',
                        'placeholder' => '$'
                    ),
                    array(
                        'id' => 'pricing_time',
                        'title' => esc_html__('Time','laboom'),
                        'type' => 'text',
                        'placeholder' => '/year',
                    ),
                    array(
                        'id' => 'pricing_price',
                        'title' => esc_html__('Price','laboom'),
                        'type' => 'text',
                        'placeholder' => '199'
                    ),
                )
            ),
            array(
                'title' =>esc_html__('Pricing Button', 'laboom'),
                'id' => 'tab-service-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id' => 'pricing_btn_text',
                        'title' => esc_html__('Button Text','laboom'),
                        'type' => 'text',
                        'placeholder' => 'Order now'
                    ),
                    array(
                        'id' => 'pricing_btn_link',
                        'title' => esc_html__('Button Url','laboom'),
                        'type' => 'text',
                        'placeholder' => '#'
                    ),



                )
            ),
            array(
                'title' =>esc_html__('Pricing Feature', 'laboom'),
                'id' => 'tab-pricing-feature',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id' => 'pricing_feature',
                        'title' => esc_html__('Pricing feature','laboom'),
                        'type' => 'switch',
                        'default'=>false,
                    ),
                )
            ),


        )
    ));
    /** portfolio options */
    MetaFramework::setMetabox(array(
        'id' => '_portfolio_main_options',
        'label' => esc_html__('Portfolio Setting', 'laboom'),
        'post_type' => 'portfolio',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Portfolio Setting', 'laboom'),
                'id' => 'tab-service-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'choose_layout_portfolio',
                        'type'     => 'select',
                        'title'    =>esc_html__('Select layout', 'laboom'),
                        'options'  => array(
                            'single_portfolio1' => 'Layout small images',
                            'single_portfolio2' => 'Layout big images',
                            'single_portfolio3' => 'Layout small slide',
                            'single_portfolio4' => 'Layout big slide',
                            'single_portfolio5' => 'Layout gallery',
                            'single_portfolio6' => 'Layout masonry',
                            'single_portfolio7' => 'Layout big masonry',
                        ),
                        'default'  => 'single_portfolio1',
                    ),
                    array(
                        'id' => 'portfolio_client',
                        'type' => 'text',
                        'title' =>esc_html__('Client ', 'laboom'),
                    ),
                    array(
                        'id' => 'portfolio_location',
                        'type' => 'text',
                        'title' =>esc_html__('Location ', 'laboom'),
                    ),
                    array(
                        'id'       => 'thumb_size',
                        'type'     => 'select',
                        'title'    =>esc_html__('Select size of thumbnail image', 'laboom'),
                        'options'  => array(
                            ''=>'Images size',
                            '2x'=>'2 Width',
                            '2x2y'=>'2 width and 2 Height ',
                            'xy'=>'Width Equal Height',
                        ),
                    ),
                    array(
                        'id' => 'portfolio_gallery',
                        'type' => 'gallery',
                        'title' =>esc_html__('Gallery ', 'laboom'),
                    ),


                )
            ),


        )
    ));
    /** testimonial options */
    MetaFramework::setMetabox(array(
        'id' => '_testimonial_main_options',
        'label' => esc_html__('Testimonial Setting', 'laboom'),
        'post_type' => 'testimonial',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Position testimonial', 'laboom'),
                'id' => 'tab-testimonial-position',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'testimonial_position',
                        'type'     => 'text',
                        'title'    => esc_html__('Position', 'laboom'),

                    ),
                )
            ),



        )
    ));
    /** team options */
    MetaFramework::setMetabox(array(
        'id' => '_team_main_options',
        'label' => esc_html__('Team Setting', 'laboom'),
        'post_type' => 'team',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Position team', 'laboom'),
                'id' => 'tab-team-position',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'team_position',
                        'type'     => 'text',
                        'title'    => esc_html__('Position', 'laboom'),

                    ),
                )
            ),

            array(
                'title' =>esc_html__('Social team', 'laboom'),
                'id' => 'tab-team-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'icon1',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 1', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'link_icon1',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 1', 'laboom'),

                    ),
                    array(
                        'id'       => 'icon2',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 2', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'link_icon2',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 2', 'laboom'),

                    ),
                    array(
                        'id'       => 'icon3',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 3', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'link_icon3',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 3', 'laboom'),

                    ),
                    array(
                        'id'       => 'icon4',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 4', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'link_icon4',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 4', 'laboom'),

                    ),
                    array(
                        'id'       => 'icon5',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 5', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'link_icon5',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 5', 'laboom'),

                    ),
                    array(
                        'id'       => 'icon6',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 6', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'link_icon6',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 6', 'laboom'),

                    ),


                )
            ),
            array(
                'title' =>esc_html__('Phone team', 'laboom'),
                'id' => 'tab-team-phone',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'phone_team',
                        'type'     => 'text',
                        'title'    => esc_html__('Phone', 'laboom'),

                    ),

                )
            ),
            array(
                'title' =>esc_html__('Mail team', 'laboom'),
                'id' => 'tab-team-mail',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'message_mail',
                        'type'     => 'text',
                        'title'    => esc_html__('Mail', 'laboom'),

                    ),

                )
            ),
            array(
                'title' =>esc_html__('Honors & Awards', 'laboom'),
                'id' => 'tab-honors-awards-mail',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'honors_awards_team',
                        'type'     => 'gallery',
                        'title'    => esc_html__('Honors & Awards', 'laboom'),

                    ),

                )
            ),



        )
    ));
    /** history options */
    MetaFramework::setMetabox(array(
        'id' => '_history_main_options',
        'label' => esc_html__('History Setting', 'laboom'),
        'post_type' => 'history',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Year', 'laboom'),
                'id' => 'tab-history-year',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'history_year',
                        'type'     => 'text',
                        'title'    => esc_html__('Year', 'laboom'),

                    ),
                )
            ),
            array(
                'title' =>esc_html__('Title Blur', 'laboom'),
                'id' => 'tab-history-blur',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'history_title_blur',
                        'type'     => 'text',
                        'title'    => esc_html__('Title Blur', 'laboom'),

                    ),
                )
            ),

        )
    ));
    function laboom_get_post($post_type = 'post'){

        $_post_options = array();

        $teachers_query = new WP_Query(array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => -1,
        ));

        if(!$teachers_query->have_posts())
            return $_post_options;

        foreach ($teachers_query->posts as $_post){
            $_post_options[$_post->ID] = $_post->post_title;
        }

        return $_post_options;
    }
    /** carousel options */
    MetaFramework::setMetabox(array(
        'id' => '_carousel_main_options',
        'label' => esc_html__('Carousel Setting', 'laboom'),
        'post_type' => 'carousel',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Button', 'laboom'),
                'id' => 'tab-carousel-button',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'carousel_button1',
                        'type'     => 'text',
                        'title'    => esc_html__('Button text1', 'laboom'),

                    ),
                    array(
                        'id'       => 'carousel_button_link1',
                        'type'     => 'text',
                        'title'    => esc_html__('Button link1', 'laboom'),

                    ),
                    array(
                        'id'       => 'carousel_button2',
                        'type'     => 'text',
                        'title'    => esc_html__('Button text2', 'laboom'),

                    ),
                    array(
                        'id'       => 'carousel_button_link2',
                        'type'     => 'text',
                        'title'    => esc_html__('Button link2', 'laboom'),

                    ),
                )
            ),
            array(
                'title' =>esc_html__('Title Blur', 'laboom'),
                'id' => 'tab-history-blur',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'history_title_blur',
                        'type'     => 'text',
                        'title'    => esc_html__('Title Blur', 'laboom'),

                    ),
                )
            ),

        )
    ));
    /* course post */
    MetaFramework::setMetabox(array(
        'id' => '_course_post_options',
        'label' => esc_html__('Setting', 'laboom'),
        'post_type' => 'lp_course',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => true,
        'sections' => array(
            array(
                'title' => '',
                'id' => 'tab-page-gallery',
                'fields' => array(
                    array(
                        'id'       => 'course-subtitle',
                        'type'     => 'text',
                        'title'    => esc_html__('Subtitle', 'laboom')
                    ),
                    array(
                        'id'       => 'opt-sale-price',
                        'type'     => 'text',
                        'title'    => esc_html__('Sale Price', 'laboom')
                    ),
                    array(
                        'id'       => 'opt-teachers',
                        'type'     => 'select',
                        'title'    => esc_html__( 'Teacher', 'laboom' ),
                        'options'  => laboom_get_post('teachers')
                    ),
                    array(
                        'id'       => 'degree_level',
                        'type'     => 'text',
                        'title'    => esc_html__('Degree Level', 'laboom')
                    ),
                    array(
                        'id'       => 'course_requirements',
                        'type'     => 'text',
                        'title'    => esc_html__('Requirements', 'laboom')
                    ),
                )
            ),
        )
    ));
    /* lesson post */
    MetaFramework::setMetabox(array(
        'id' => '_lesson_post_options',
        'label' => esc_html__('Setting', 'laboom'),
        'post_type' => 'lp_lesson',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => true,
        'sections' => array(
            array(
                'title' => '',
                'id' => 'tab-lesson',
                'fields' => array(
                    array(
                        'id'       => 'opt_lesson_icon',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon', 'laboom')
                    ),

                )
            ),
        )
    ));
    /** teacher options */
    MetaFramework::setMetabox(array(
        'id' => '_teacher_main_options',
        'label' => esc_html__('Team Setting', 'laboom'),
        'post_type' => 'teachers',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Position teachers', 'laboom'),
                'id' => 'tab-teacher-position',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'teacher_position',
                        'type'     => 'text',
                        'title'    => esc_html__('Position', 'laboom'),

                    ),
                )
            ),
            array(
                'title' =>esc_html__('Social teachers', 'laboom'),
                'id' => 'tab-teacher-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'teacher_icon1',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 1', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'teacher_link_icon1',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 1', 'laboom'),

                    ),
                    array(
                        'id'       => 'teacher_icon2',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 2', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'teacher_link_icon2',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 2', 'laboom'),

                    ),
                    array(
                        'id'       => 'teacher_icon3',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 3', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'teacher_link_icon3',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 3', 'laboom'),

                    ),
                    array(
                        'id'       => 'teacher_icon4',
                        'type'     => 'text',
                        'title'    => esc_html__('Icon 4', 'laboom'),
                        'placeholder' => 'ex: fa fa-facebook',

                    ),
                    array(
                        'id'       => 'teacher_link_icon4',
                        'type'     => 'text',
                        'title'    => esc_html__('Link Icon 4', 'laboom'),

                    ),


                )
            ),



        )
    ));
    /** event options */
    MetaFramework::setMetabox(array(
        'id' => '_events_main_options',
        'label' => esc_html__('Events Setting', 'laboom'),
        'post_type' => 'event',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Event Addresss', 'laboom'),
                'id' => 'tab-event-address',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'event_address',
                        'type'     => 'text',
                        'title'    => esc_html__('Event Address', 'laboom'),

                    ),
                    array(
                        'id'       => 'event_google_address',
                        'type'     => 'text',
                        'title'    => esc_html__('Event Address Link Google Map', 'laboom'),

                    ),
                )
            ),
            array(
                'title' =>esc_html__('Event Time', 'laboom'),
                'id' => 'tab-event-time',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'event_time',
                        'type'     => 'text',
                        'title'    => esc_html__('Event Time', 'laboom'),

                    ),
                )
            ),
            array(
                'title' =>esc_html__('Comming soon Event ', 'laboom'),
                'id' => 'tab-event-comming_soon',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'event_comming_date',
                        'type'     => 'date',
                        'title'    => esc_html__('Cooming Soon Event', 'laboom'),

                    ),

                )
            ),
            array(
                'title' =>esc_html__('Event Map ', 'laboom'),
                'id' => 'tab-event-map',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'event_map_add',
                        'type'     => 'text',
                        'title'    => esc_html__('Event Map Address', 'laboom'),

                    ),

                )
            ),

        )
    ));
    /** portfolio options */
    MetaFramework::setMetabox(array(
        'id' => '_gallery_main_options',
        'label' => esc_html__('Gallery Setting', 'laboom'),
        'post_type' => 'gallery',
        'context' => 'advanced',
        'priority' => 'default',
        'open_expanded' => false,
        'sections' => array(
            array(
                'title' =>esc_html__('Gallery Setting', 'laboom'),
                'id' => 'tab-service-bc',
                'icon' => 'el el-photo',
                'fields' => array(
                    array(
                        'id'       => 'gallery_thumb_size',
                        'type'     => 'select',
                        'title'    =>esc_html__('Select size of thumbnail image', 'laboom'),
                        'options'  => array(
                            ''=>'Images size',
                            '2x'=>'2 Width',
                            '2x2y'=>'2 width and 2 Height ',
                            'xy'=>'Width Equal Height',
                        ),
                        'default'  => 'xy',
                    ),
                )
            ),


        )
    ));
}