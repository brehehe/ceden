<?php
/**
 * demo data.
 *
 * config.
 */
function laboom_set_woo_page(){
    
    $woo_pages = array(
        'woocommerce_shop_page_id' => 'Shop',
        'woocommerce_cart_page_id' => 'Cart',
        'woocommerce_checkout_page_id' => 'Checkout'
    );
    
    foreach ($woo_pages as $key => $woo_page){
    
        $page = get_page_by_title($woo_page);
    
        if(!isset($page->ID))
            return ;
             
        update_option($key, $page->ID);
    
    }
}

add_action('ef3-import-finish', 'laboom_set_woo_page');

add_filter('ef3-theme-options-opt-name', 'laboom_set_demo_opt_name');

function laboom_set_demo_opt_name(){
    return 'opt_theme_options';
}

add_filter('ef3-replace-content', 'laboom_replace_content', 10 , 2);

function laboom_replace_content($replaces, $attachment){
    return array(
        //'/image="(.+?)"/' => 'image="'.$attachment.'"',
        '/tax_query:/' => 'remove_query:',
        '/categories:/' => 'remove_query:',
        //'/src="(.+?)"/' => 'src="'.ef3_import_export()->acess_url.'ef3-placeholder-image.jpg"'
    );
}

add_filter('ef3-replace-theme-options', 'laboom_replace_theme_options');

function laboom_replace_theme_options(){
    return array(
        'dev_mode' => 0,
    );
}
add_filter('ef3-enable-create-demo', 'laboom_enable_create_demo');

function laboom_enable_create_demo(){
    return false;
}
add_action('ef3-import-start', 'laboom_import_flex_restaurant_data_before',1,2);
function laboom_import_flex_restaurant_data_before($id,$folder_dir)
{
    if (file_exists($folder_dir . 'fr_taxonomies.json')){
        update_option('fr_taxonomies',json_decode(file_get_contents($folder_dir . 'fr_taxonomies.json'),true));
    }

    if (file_exists($folder_dir . 'frv_setting_page.json')){
        update_option('frv-setting-page',json_decode(file_get_contents($folder_dir . 'frv_setting_page.json'),true));
    }
    if (file_exists($folder_dir . 'fr_setting_page.json')){
        update_option('fr-setting-page',json_decode(file_get_contents($folder_dir . 'fr_setting_page.json'),true));
    }
}
add_action('ef3-import-finish', 'laboom_import_flex_restaurant_data_after' ,1,2);
function laboom_import_flex_restaurant_data_after($id,$folder_dir){

    if (file_exists($folder_dir . 'fr_term_meta.json')){
        $tax_termmeta = json_decode(file_get_contents($folder_dir . 'fr_term_meta.json'),true);
        foreach($tax_termmeta as $tax => $termmeta){
            foreach($termmeta as $term => $meta){
                $term_ = get_term_by('slug',$term,$tax);
                update_term_meta($term_->term_id,'layout',$meta['layout']);
                update_term_meta($term_->term_id,'background',$meta['background']);
            }
        }
    }
}
add_action('ef3-export','laboom_export_flex_restaurant_data',1,2);
function laboom_export_flex_restaurant_data($id,$folder_dir){
    global $wp_filesystem;
    $file_use_map = array(
        'fr_taxonomies'=>'fr_taxonomies.json',
        'frv-setting-page'=>'frv_setting_page.json',
        'fr-setting-page'=>'fr_setting_page.json',
    );
    foreach ($file_use_map as $option => $file)
    {
        $file_path = $folder_dir.$file;
        if(file_exists($file_path))
            continue;
        $file_contents = json_encode(get_option($option,array()));
        $wp_filesystem->put_contents( $file_path, $file_contents, FS_CHMOD_FILE);
    }
    $tax_termmeta_file = $folder_dir . 'fr_term_meta.json';
    if (!file_exists($tax_termmeta_file)){
        $tax_termmeta = array();
        $taxonomies = get_taxonomies(array('object_type' => array('flexrestaurants')));
        foreach ($taxonomies as $tax_slug) {
            $tax_termmeta[$tax_slug] = array();
            $terms = get_terms(array(
                'taxonomy' => 'post_tag',
                'hide_empty' => false,
            ) );
            if(!empty($terms))
                foreach ($terms as $term)
                {
                    if(!$term instanceof WP_Term)
                        continue;
                    $tax_termmeta[$tax_slug][$term->slug] = get_term_meta($term->term_id);
                }
        }
        $file_contents = json_encode($tax_termmeta);
        $wp_filesystem->put_contents( $tax_termmeta_file, $file_contents, FS_CHMOD_FILE);
    }
}