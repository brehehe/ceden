<?php
/**
 * get header layout.
 */
function laboom_header(){
    get_template_part('inc/header/header', laboom_get_header_layout_name());
}
function laboom_get_header_layout_name()
{
    global $opt_theme_options, $opt_meta_options;
    $header = 'header4';
    if(!empty($opt_theme_options['header_layout']))
        $header = $opt_theme_options['header_layout'];
    if(is_page() && !empty($opt_meta_options['custom_header']))
        $header =  $opt_meta_options['header_layout'];
    return $header;
}
function laboom_header_layout_class(){
    echo esc_attr(laboom_get_header_layout_name());
}
function laboom_slider_bg_overlay(){
    global $opt_theme_options, $opt_meta_options;
    if(is_page() && !empty($opt_meta_options['slider_bg_overlay']))
        echo ' slider-ovelay-'.$opt_meta_options['slider_bg_overlay'];
}
function laboom_header_top(){
    global $opt_theme_options,$opt_meta_options;
    $uniqid_id = uniqid('register-modal-');
    $uniqid_id_login = uniqid('login-modal-');
    if (is_page()){
        if(isset($opt_meta_options['custom_enable_header_top']) && $opt_meta_options['custom_enable_header_top']){
            $opt_theme_options['enable_header_top']=$opt_meta_options['enable_header_top'];
        }
    }
    if($opt_theme_options['enable_header_top']){?>

            <div id="cshero-header-top" class="container-fluid no-padding">
                <div class="container">
                    <div class="row">
                        <div class="header-left col-xs-12 col-sm-6 col-md-6 col-lg-6 contact-top">
                            <?php if(!empty($opt_theme_options['top_phone'])){?>
                                <span class="phone"><?php echo esc_html($opt_theme_options['top_phone']); ?></span>
                            <?php } ?>
                            <?php if(!empty($opt_theme_options['top_email'])){?>
                                <span> <?php echo esc_attr($opt_theme_options['top_email']); ?></span>
                            <?php } ?>
                        </div>
                        <div class="header-right-top col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div class="header-right-inner">
                                <?php if (is_active_sidebar('header-right-top')) { ?>
                                    <div class="header-top-right-menu hidden-xs">
                                        <?php dynamic_sidebar('header-right-top'); ?>
                                    </div>
                                <?php } ?>
                                <?php if(function_exists('up_get_template_part')): ?>
                                    <div class="login-wrap">
                                        <?php if(!is_user_logged_in()): ?>
                                            <a class="button-login progress-button show-login-form button-signin-form" data-toggle="modal" data-target="#<?php echo esc_attr($uniqid_id_login); ?>">
                                                <i class="fa fa-user" aria-hidden="true"></i> <span class="content"><?php esc_html_e('Login', 'laboom');?></span>
                                            </a>
                                            <a class="btn-register show-signin-form button-signup-form" data-toggle="modal" data-target="#<?php echo esc_attr($uniqid_id); ?>">
                                                <i class="fa fa-lock" aria-hidden="true"></i> <?php esc_html_e('Register','laboom');?>
                                            </a>
                                        <?php endif; ?>
                                        <?php if( is_user_logged_in()): ?>
                                            <a class="log_out" href="<?php echo wp_logout_url( get_permalink() ); ?>"><i class="fa fa-lock" aria-hidden="true"></i> <?php esc_html_e('Logout', 'laboom');?></a>
                                        <?php endif; ?>


                                    </div>
                                    <div class="modal fade form-login" id="<?php echo esc_attr($uniqid_id_login); ?>" tabindex="-1" >
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content clearfix modal-content-login">
                                                <div class="modal-header">
                                                    <h3> <?php esc_html_e('Login', 'laboom'); ?></h3>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-close"></i></span></button>
                                                </div>
                                                <div class="modal-body">

                                                        <?php  echo do_shortcode('[user-press layout="" form_type="login" is_logged="profile"]'); ?>
                                                         <?php if(!is_user_logged_in()): ?>
                                                            <div class="no-account"><?php echo esc_html__('Havent an account ','laboom');?> <a class="switch_to_sign_up"> <?php esc_html_e('Register','laboom');?></a></div>
                                                        <?php endif; ?>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade form-register" id="<?php echo esc_attr($uniqid_id); ?>" tabindex="-1" >
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content clearfix modal-content-register">

                                                <div class="modal-header">
                                                    <h3> <?php esc_html_e('Register', 'laboom'); ?></h3>
                                                    <!-- Modal -->
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                                </div>
                                                <div class="modal-body">
                                                    <?php up_get_template_part('default/form', 'register'); ?>
                                                    <div class="no-account"> <span><?php esc_html_e('Have an account? ','laboom');?></span> <a  class="switch_to_login"> <?php esc_html_e('Sign In','laboom');?></a></div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php laboom_cms_header_top_social()?>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
    <?php
    }
}
function laboom_header_book_table(){
    global $opt_theme_options;
    if(!class_exists('FlexReservations'))
        return;
    $uniqid_id_book = uniqid('book-modal-');
    $inline_script = "jQuery(document).ready(function($) {
            $('.modal.form-reservation').appendTo($('body'));
        });";
    wp_add_inline_script('laboom-main',$inline_script);
    if ($opt_theme_options['enable_book_table']) {
        ?>
        <a class="btn-book-table" data-toggle="modal" data-target="#<?php echo esc_attr($uniqid_id_book); ?>">
            <span class="lnr lnr-calendar-full"></span> <?php echo esc_html__('Book Table', 'laboom'); ?>
        </a>
        <div class="modal fade form-reservation" id="<?php echo esc_attr($uniqid_id_book); ?>" tabindex="-1">
            <div class="modal-dialog" role="document">
                <div class="modal-content clearfix modal-content-login">
                    <div class="modal-header">
                        <!-- Modal -->
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                class="lnr lnr-cross"></span></button>
                    </div>
                    <div class="modal-body">
                        <?php echo do_shortcode('[reservation]'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
function laboom_header_contact(){
    global $opt_theme_options;?>
    <div class="contact contact-phone">
        <i class="fa fa-phone" aria-hidden="true"></i>
        <div class="header-contact-right">
            <?php if(!empty($opt_theme_options['our_phone'])){?>
                <h3><?php echo esc_html($opt_theme_options['our_phone']);?></h3>
            <?php }?>
            <?php if(!empty($opt_theme_options['our_address'])){?>
                <span><?php echo esc_html($opt_theme_options['our_address']);?></span>
            <?php }?>
        </div>
    </div>
    <div class="contact contact-time">
        <i class="fa fa-map-marker" aria-hidden="true"></i>
        <?php if(!empty($opt_theme_options['our_hours'])){?>
            <div class="header-contact-right">
                <h3><?php echo esc_html__('Open Hours','laboom');?></h3>
                <span> <?php echo esc_html($opt_theme_options['our_hours']);?></span>
            </div>

        <?php }?>
    </div>

    <?php
}
function laboom_cms_header_top_social() {


    global $opt_theme_options;
if($opt_theme_options['enable_social_header_top']==0){
return;
}
    $cms_header_top_social = $opt_theme_options['cms_header_top_social']['enabled'];
    ?>
    <ul class="cms-header-top-social">
        <?php
        if ($cms_header_top_social): foreach ($cms_header_top_social as $key=>$value) {
            switch($key) {

                case 'facebook': echo '<li><a href="'.esc_url($opt_theme_options['social_facebook_url']).'"><i class="fa fa-facebook" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'twitter': echo '<li><a href="'.esc_url($opt_theme_options['social_twitter_url']).'"><i class="fa fa-twitter" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'instagram': echo '<li><a href="'.esc_url($opt_theme_options['social_instagram_url']).'"><i class="fa fa-instagram" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'printest': echo '<li><a href="'.esc_url($opt_theme_options['social_printest_url']).'"><i class="fa fa-pinterest-p" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'dribbble': echo '<li><a href="'.esc_url($opt_theme_options['social_dribbble_url']).'"><i class="fa fa-dribbble" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'google': echo '<li><a href="'.esc_url($opt_theme_options['social_google_url']).'"><i class="fa fa-google-plus" aria-hidden="true"></i>'.'</a></li>';
                    break;
            }
        }
        endif;
        ?>
    </ul>
    <?php
}
/**
 * get theme logo.
 */
function laboom_header_logo(){
    global $opt_theme_options,$opt_meta_options;
    $header_layout = laboom_get_header_layout_name();
    ?>
    <div class="main_logo-wrap <?php if($opt_theme_options['enable_header_top']){ echo '';} else{echo 'no-header-top';} if(isset($opt_theme_options['sticky_logo_type']) && $opt_theme_options['sticky_logo_type'] == 'img' && !empty($opt_theme_options['sticky_logo']['url'])) {
        echo 'hidden-sticky';
    } elseif (isset($opt_theme_options['sticky_logo_type']) && $opt_theme_options['sticky_logo_type'] == 'text' && !empty($opt_theme_options['sticky_logo_text'])){echo 'hidden-sticky';}?>">

   <?php if(isset($opt_theme_options['logo_type']) && $opt_theme_options['logo_type'] && !empty($opt_theme_options['main_logo']['url'])) {
        if (!empty($opt_meta_options['page_logo']['url'])){
                echo '<a class="main-logo logo-page" href="' . esc_url(home_url('/')) . '"><img alt="' . get_bloginfo("name") . '" src="' . esc_url($opt_meta_options['page_logo']['url']) . '"></a>';

        }
        else{
            echo '<a class="main-logo" href="' . esc_url(home_url('/')) . '"><img alt="' .  get_bloginfo( "name" ) . '" src="' . esc_url($opt_theme_options['main_logo']['url']) . '"></a>';
            if(($header_layout=='trans') || ($header_layout=='header4')){

                echo '<a  class="trans-logo" href="' . esc_url(home_url('/')) . '"><img alt="' .  get_bloginfo( "name" ) . '" src="' . esc_url($opt_theme_options['trans_logo']['url']) . '"></a>';
            }
        }

    } elseif (isset($opt_theme_options['logo_type']) && !$opt_theme_options['logo_type'] && !empty($opt_theme_options['logo_text'])){
        echo '<h1 class="site-title"><a href="' . esc_url( home_url( '/' )) . '" rel="home">' . esc_html($opt_theme_options['logo_text']) . '</a></h1>';

        if(!empty($opt_theme_options['logo_text_sologan']))
            echo '<p class="site-description">'.esc_html($opt_theme_options['logo_text_sologan']).'</p>';

    } else {
        echo '<a class="trans-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . esc_html__('Logo', 'laboom') . '" src="' . esc_url(get_template_directory_uri().'/assets/images/logo-trans.png') . '"></a>';

    }

    echo '</div>';

    laboom_header_sticky_logo();
}

/**
 * get theme logo.
 */
function laboom_header_sticky_logo(){
    global $opt_theme_options;

    /* sticky off. */
    if(!isset($opt_theme_options['menu_sticky']) || !$opt_theme_options['menu_sticky'])
        return;

    /* default logo. */
    if(!isset($opt_theme_options['sticky_logo_type']) || $opt_theme_options['sticky_logo_type'] == 'default')
        return;

    echo '<div class="sticky_logo hide">';

    if(isset($opt_theme_options['sticky_logo_type']) && $opt_theme_options['sticky_logo_type'] == 'img' && !empty($opt_theme_options['sticky_logo']['url'])) {
        echo '<a class="logo-sticky" href="' . esc_url(home_url('/')) . '"><img alt="' .  get_bloginfo( "name" ) . '" src="' . esc_url($opt_theme_options['sticky_logo']['url']) . '"></a>';
    } elseif (isset($opt_theme_options['sticky_logo_type']) && $opt_theme_options['sticky_logo_type'] == 'text' && !empty($opt_theme_options['sticky_logo_text'])){
        echo '<div class="logo-text">';
        echo '<h1 class="site-title"><a href="' . esc_url( home_url( '/' )) . '" rel="home">' . esc_html($opt_theme_options['sticky_logo_text']) . '</a></h1>';

        if(!empty($opt_theme_options['sticky_logo_text_sologan']))
            echo '<p class="site-description">'.esc_html($opt_theme_options['sticky_logo_text_sologan']).'</p>';
        echo '</div>';
    } else {
        echo '<a class="main-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . esc_html__('Logo', 'laboom') . '" src="' . esc_url(get_template_directory_uri().'/assets/images/main-logo.png') . '"></a>';
        echo '<a class="sticky-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . esc_html__('Logo Sticky', 'laboom') . '" src="' . esc_url(get_template_directory_uri().'/assets/images/sticky-logo.png') . '"></a>';
    }

    echo '</div>';
}

/**
 * get header class.
 */
function laboom_header_class($class = ''){
    global $opt_theme_options;

    if(!isset($opt_theme_options)){
        echo esc_attr($class);
        return;
    }

    if(isset($opt_theme_options['menu_sticky']) && $opt_theme_options['menu_sticky'])
        $class .= ' sticky-desktop';
    if(isset($opt_theme_options['sticky_tablet']) && $opt_theme_options['sticky_tablet'])
        $class .= ' sticky-tablet';
    if(isset($opt_theme_options['sticky_mobile']) && $opt_theme_options['sticky_mobile'])
        $class .= ' sticky-mobile';

    echo esc_attr($class);
}
function laboom_body_boxed($class = ''){
    global $opt_theme_options,$opt_meta_options;

    if(isset($opt_meta_options['body_layout'])){
        $opt_theme_options['general_layout']  = $opt_meta_options['body_layout'];
    }
    if ($opt_theme_options['general_layout']=='0'){
        $class=' body-boxed';
    }
    echo esc_attr($class);
}
/**
 * main navigation.
 */
function laboom_header_navigation(){

    global $opt_meta_options;

    $attr = array(
        'menu_class' => 'nav-menu menu-main-menu',
        'theme_location' => 'primary'
    );

    if(is_page() && !empty($opt_meta_options['header_menu']))
        $attr['menu'] = $opt_meta_options['header_menu'];

    /* enable mega menu. */
    if(class_exists('HeroMenuWalker')){ $attr['walker'] = new HeroMenuWalker(); }

    /* main nav. */
    if ( has_nav_menu( 'primary' ) ) {
        wp_nav_menu( $attr );
    } else { ?>
        <div class="new-item-menu"><a href="<?php echo get_admin_url(); ?>nav-menus.php"><?php esc_html_e('Creat New Menu', 'laboom'); ?></a></div>
    <?php }
}

function laboom_header_right(){
    global $opt_theme_options;

    if ((isset($opt_theme_options['enable_search']) && $opt_theme_options['enable_search']) || (isset($opt_theme_options['enable_cart']) && $opt_theme_options['enable_cart'])){?>
        <div class="header-right">
            <div class="nav-button-icon">
                <?php if (isset($opt_theme_options['enable_cart']) && $opt_theme_options['enable_cart']){?>
                     <span class="shopping-cart-wrapper">
                        <?php if ( is_active_sidebar( 'shop-cart' ) ) { ?>
                            <span class="lnr lnr-cart"></span>
                            <span class="couter_items-wrap"><span class="couter_items"><?php echo  sprintf (_n( '(%d)', '(%d)', WC()->cart->cart_contents_count, 'laboom' ), WC()->cart->cart_contents_count );?></span>  <?php echo esc_html__('items','laboom');?> - <?php echo WC()->cart->get_cart_total();?></span>
                        <?php } ?>
                    </span>
                    <?php if ( class_exists( 'WC_Widget_Cart' ) ): ?>
                        <div class="widget_shopping_cart">
                            <div class="mini-cart-wrap">
                                <div class="widget_shopping_cart_content">
                                    <?php woocommerce_mini_cart(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php }?>
                <?php if (isset($opt_theme_options['enable_search']) && $opt_theme_options['enable_search']){?>
                    <span class="lnr lnr-magnifier" data-display=".cms-search" data-no-display=".cms-tools, .cms-cart"></span>

                 <?php }?>
            </div>
        </div>
    <?php }

}
function laboom_header3_right(){
    global $opt_theme_options;

    if ((isset($opt_theme_options['enable_search1']) && $opt_theme_options['enable_search1']) || (isset($opt_theme_options['enable_cart1']) && $opt_theme_options['enable_cart1'])){?>
        <div class="header-right hidden-xs hidden-sm">
            <div class="nav-button-icon">
                <?php if (isset($opt_theme_options['enable_cart1']) && $opt_theme_options['enable_cart1']){?>
                    <span class="shopping-cart-wrapper">
                        <?php if ( is_active_sidebar( 'shop-cart' ) ) { ?>
                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            <span class="couter_items-wrap"><span class="couter_items"><?php echo  sprintf (_n( '%d', '%d', WC()->cart->cart_contents_count, 'laboom' ), WC()->cart->cart_contents_count ); ?></span></span>
                        <?php } ?>
                    </span>
                    <?php if ( class_exists( 'WC_Widget_Cart' ) ): ?>
                        <div class="widget_shopping_cart">
                            <div class="widget_shopping_cart_content">
                                <?php woocommerce_mini_cart(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php }?>
                <?php if (isset($opt_theme_options['enable_search1']) && $opt_theme_options['enable_search1']){?>
                    <i class="fa fa-search" aria-hidden="true"></i>
                <?php }?>
            </div>
        </div>
    <?php }

}
function laboom_cms_top_social() {

    global $opt_theme_options;

    $cms_menupopup_social = $opt_theme_options['cms_menupopup_social']['enabled'];
    ?>


    <ul class="cms-top-social">
        <?php
        if ($cms_menupopup_social): foreach ($cms_menupopup_social as $key=>$value) {
            switch($key) {

                case 'facebook': echo '<li><a href="'.esc_url($opt_theme_options['social_facebook_url']).'"><i class="fa fa-facebook" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'twitter': echo '<li><a href="'.esc_url($opt_theme_options['social_twitter_url']).'"><i class="fa fa-twitter" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'google': echo '<li><a href="'.esc_url($opt_theme_options['social_google_url']).'"><i class="fa fa-google-plus" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'linkedin': echo '<li><a href="'.esc_url($opt_theme_options['social_linkedin_url']).'"><i class="fa fa-linkedin" aria-hidden="true"></i>'.'</a></li>';
                    break;
            }
        }
        endif;
        ?>
    </ul>
    <?php
}
function laboom_cms_header_bottom_social() {

    global $opt_theme_options;

    $cms_header_bottom_social = $opt_theme_options['cms_header_bottom_social']['enabled'];
    ?>
    <ul class="cms-header-bottom-social">
        <?php
        if ($cms_header_bottom_social): foreach ($cms_header_bottom_social as $key=>$value) {
            switch($key) {

                case 'facebook': echo '<li><a href="'.esc_url($opt_theme_options['social_facebook_url']).'"><i class="fa fa-facebook" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'twitter': echo '<li><a href="'.esc_url($opt_theme_options['social_twitter_url']).'"><i class="fa fa-twitter" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'google': echo '<li><a href="'.esc_url($opt_theme_options['social_google_url']).'"><i class="fa fa-google-plus" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'linkedin': echo '<li><a href="'.esc_url($opt_theme_options['social_linkedin_url']).'"><i class="fa fa-linkedin" aria-hidden="true"></i>'.'</a></li>';
                    break;
            }
        }
        endif;
        ?>
    </ul>
    <?php
}
/**
 * get page title layout
 */
function laboom_page_title(){
    global $opt_theme_options, $opt_meta_options;
    /* get theme options */
    /* custom layout from page. */
    if(is_page() && !empty($opt_meta_options['custom_page_title'])) {
        $opt_theme_options['page_title_layout'] = $opt_meta_options['page_title_layout'];
    }
    /* BG image */
    if (is_page() && !empty($opt_meta_options['page_bg_page_title']['url'])) {
        $opt_theme_options['bg_page_title']['url'] = $opt_meta_options['page_bg_page_title']['url'];
    }
    if (function_exists('is_woocommerce') && is_woocommerce()){
        if (!empty($opt_theme_options['background_shop_title']['url'])) {
            $opt_theme_options['bg_page_title']['url'] = $opt_theme_options['background_shop_title']['url'];
        }
    }
    if (is_singular('post') && !empty($opt_theme_options['single_bg_page_title']) && $opt_theme_options['single_bg_page_title']) {
        $opt_theme_options['bg_page_title']['url'] = $opt_theme_options['single_bg_page_title']['url'];
    }
    if (isset($opt_meta_options['custom_breadcrumb']) && $opt_meta_options['custom_breadcrumb']) {
            $opt_theme_options['enable_breadcrumb'] = $opt_meta_options['enable_breadcrumb'];
    }
    if (function_exists('is_woocommerce') && is_woocommerce() && !is_singular('product')){
        $opt_theme_options['enable_breadcrumb'] = $opt_theme_options['shop_enable_breadcrumb'];
    }
    if (is_404()){
       return;
    }
    ?>
    <?php if($opt_theme_options['page_title_layout'] != '') : ?>

       <?php switch ($opt_theme_options['page_title_layout']){
            case '1':
            ?>
                <div id="page-title" class="page-title" style="background-image: url(<?php echo esc_url($opt_theme_options['bg_page_title']['url']); ?>)">
                     <div class="container">
                         <div class="row">
                            <div id="page-title-text" class="s1 col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="page-title-inner">
                                    <h1><?php laboom_get_page_title(); ?></h1>
                                    <div class="page-title-content"><?php laboom_get_page_subtitle()?></div>
                                    <?php if($opt_theme_options['enable_breadcrumb'] != '0') : ?>
                                        <div id="breadcrumbs">
                                             <div id="breadcrumb-text" class=""><?php laboom_get_bread_crumb(); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                         </div>
                     </div>
                    <svg class="row-svg-bottom" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 147.7 35.2" style="enable-background:new 0 0 147.7 35.2;" xml:space="preserve"><g><g><path class="st0" d="M147.7,35.2c-49.2,0-98.5,0-147.7,0c10.4-3.6,18.7-10.6,27.5-16.9c7.7-5.6,16.1-10,24.9-13.8c14.5-6.2,28.8-6.1,43.2,0.1c9.9,4.2,19.2,9.4,27.8,15.9C130.9,26.4,138.6,31.9,147.7,35.2z"></path></g></g></svg>
                    <div class="custom-row-image scroll-bellow" style="background-image:url(<?php echo get_template_directory_uri(). '/assets/images/icon1.png'?>);" ></div>
                </div><!-- #page-title -->

                <?php
                break;
                case '2':?>
                    <div id="page-title" class="page-title" style="background-image: url(<?php echo esc_url($opt_theme_options['bg_page_title']['url']); ?>)">
                        <div class="container">
                            <div class="row">
                                <div id="page-title-text" class="s1 col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="page-title-inner">
                                        <h1><?php laboom_get_page_title(); ?></h1>
                                        <div class="page-title-content"><?php laboom_get_page_subtitle()?></div>
                                        <?php if($opt_theme_options['enable_breadcrumb'] != '0') : ?>
                                            <div id="breadcrumbs">
                                                <div id="breadcrumb-text" class=""><?php laboom_get_bread_crumb(); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- #page-title -->
                    <?php
                    break;
                    } ?>

    <?php endif; ?>

    <?php
    if(!$opt_theme_options){?>
        <div id="page-title" class="page-title style1 theme-blank" style="background-image: url(<?php echo get_template_directory_uri(). '/assets/images/page-title.jpg" alt=""'; ?>);">
            <div class="container">
                <div class="row">

                    <div id="page-title-text" class="s1 col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="page-title-inner">
                            <h1><?php
                                laboom_get_page_title();

                                ?></h1>

                        </div>
                    </div>

                </div>
            </div>
        </div><!-- #page-title -->
        <?php      return;
    }

}

/**
 * page title
 */
function laboom_get_page_title(){

    global $opt_meta_options;

    if (!is_archive()){
        /* page. */
        if(is_page()) :
            /* custom title. */

            if(!empty($opt_meta_options['page_title_text'])):
                echo esc_html($opt_meta_options['page_title_text']);
            else :
                the_title();
            endif;
        elseif (is_front_page()):
            esc_html_e('Blog', 'laboom');
        /* search */
        elseif (is_search()):
            printf( esc_html__( 'Search Results for: %s', 'laboom' ), '<span>' . get_search_query() . '</span>' );
        /* 404 */
        elseif (is_404()):
            esc_html_e( 'Error Page', 'laboom');
//        elseif (is_singular('post')):
//            esc_html_e( 'Blog Single', 'laboom');
        elseif (is_singular('team')):
           the_title();
//        elseif (is_singular('product')):
//            esc_html_e( 'Shop Single', 'laboom');
        /* other */
        else :
            the_title();
        endif;
    } else {
        /* category. */
        if ( is_category() ) :
            single_cat_title();
        elseif ( is_tag() ) :
            /* tag. */
            single_tag_title();
        /* author. */
        elseif ( is_author() ) :
            printf( esc_html__( 'Author: %s', 'laboom' ), '<span class="vcard">' . get_the_author() . '</span>' );
        /* date */
        elseif ( is_day() ) :
            printf( esc_html__( 'Day: %s', 'laboom' ), '<span>' . get_the_date() . '</span>' );
        elseif ( is_month() ) :
            printf( esc_html__( 'Month: %s', 'laboom' ), '<span>' . get_the_date() . '</span>' );
        elseif ( is_year() ) :
            printf( esc_html__( 'Year: %s', 'laboom' ), '<span>' . get_the_date() . '</span>' );
        /* post format */
        elseif ( is_tax( 'post_format', 'post-format-aside' ) ) :
            esc_html_e( 'Asides', 'laboom' );
        elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) :
            esc_html_e( 'Galleries', 'laboom');
        elseif ( is_tax( 'post_format', 'post-format-image' ) ) :
            esc_html_e( 'Images', 'laboom');
        elseif ( is_tax( 'post_format', 'post-format-video' ) ) :
            esc_html_e( 'Videos', 'laboom' );
        elseif ( is_tax( 'post_format', 'post-format-quote' ) ) :
            esc_html_e( 'Quotes', 'laboom' );
        elseif ( is_tax( 'post_format', 'post-format-link' ) ) :
            esc_html_e( 'Links', 'laboom' );
        elseif ( is_tax( 'post_format', 'post-format-status' ) ) :
            esc_html_e( 'Statuses', 'laboom' );
        elseif ( is_tax( 'post_format', 'post-format-audio' ) ) :
            esc_html_e( 'Audios', 'laboom' );
        elseif ( is_tax( 'post_format', 'post-format-chat' ) ) :
            esc_html_e( 'Chats', 'laboom' );
        /* woocommerce */
        elseif (function_exists('is_woocommerce') && is_woocommerce()):
            woocommerce_page_title();

        /* Portfolio */
        elseif (is_tax('portfolio_categories')):
            $term = get_term_by( 'slug', get_query_var( 'portfolio_categories' ), get_query_var( 'taxonomy' ) );
            echo apply_filters('the_title', $term->name);
        elseif (is_post_type_archive('portfolio')):
            esc_html_e('Portfolios', 'laboom');
        else :
            /* other */
            the_title();
        endif;
    }
}
/**
 * page subtitle*/
function laboom_get_page_subtitle(){

    global $opt_meta_options,$opt_theme_options;

    if(!empty($opt_meta_options['page-title-content'])){
        echo esc_html($opt_meta_options['page-title-content']);

    }
    elseif (function_exists('is_woocommerce') && is_woocommerce()){
        if (!empty($opt_theme_options['woo_subtitle'])){
            echo esc_attr($opt_theme_options['woo_subtitle']);
        }
    }
    elseif (is_404()){
        if (!empty($opt_theme_options['page404_subtitle'])){
            echo esc_attr($opt_theme_options['page404_subtitle']);
        }
    }


}
/**
 * Breadcrumb
 *
 * @since 1.0.0
 */
function laboom_get_bread_crumb($separator = '') {
    global $opt_theme_options, $post;

    echo '<ul class="breadcrumbs">';
    /* not front_page */
    if ( !is_front_page() ) {
        echo '<li><a href="';
        echo esc_url(home_url('/'));
        echo '">';
        echo isset($opt_theme_options['breacrumb_home_prefix']) ? esc_html($opt_theme_options['breacrumb_home_prefix']) : esc_html__('Home', 'laboom');
        echo "</a></li>";
    }

    $params['link_none'] = '';

    /* category */
    if (is_category()) {
        $category = get_the_category();
        $ID = $category[0]->cat_ID;
        echo is_wp_error( $cat_parents = get_category_parents($ID, TRUE, '', FALSE ) ) ? '' : '<li>'.wp_kses_post($cat_parents).'</li>';
    }
    /* tax */
    if (is_tax()) {
        $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
        $link = get_term_link( $term );

        if ( is_wp_error( $link ) ) {
            echo sprintf('<li>%s</li>', $term->name );
        } else {
            echo sprintf('<li><a href="%s" title="%s">%s</a></li>', $link, $term->name, $term->name );
        }
    }
    /* home */
    if ( is_front_page() ) {
        echo isset($opt_theme_options['breacrumb_home_prefix']) ? esc_html($opt_theme_options['breacrumb_home_prefix']) : esc_html__('Home', 'laboom');
    }
    /* page not front_page */
    if(is_page() && !is_front_page()) {
        $parents = array();
        $parent_id = $post->post_parent;
        while ( $parent_id ) :
            $page = get_page( $parent_id );
            if ( $params["link_none"] )
                $parents[]  = get_the_title( $page->ID );
            else
                $parents[]  = '<li><a href="' . esc_url(get_permalink( $page->ID )) . '" title="' . esc_attr(get_the_title( $page->ID )) . '">' . esc_html(get_the_title( $page->ID )) . '</a></li>' . $separator;
            $parent_id  = $page->post_parent;
        endwhile;
        $parents = array_reverse( $parents );
        echo join( '', $parents );
        echo '<li>'.esc_html(get_the_title()).'</li>';
    }
    /* single */
    if(is_single()) {
        $categories_1 = get_the_category($post->ID);
        if($categories_1):
            foreach($categories_1 as $cat_1):
                $cat_1_ids[] = $cat_1->term_id;
            endforeach;
            $cat_1_line = implode(',', $cat_1_ids);
        endif;
        if( isset( $cat_1_line ) && $cat_1_line ) {
            $categories = get_categories(array(
                'include' => $cat_1_line,
                'orderby' => 'id'
            ));
            if ( $categories ) :
                foreach ( $categories as $cat ) :
                    $cats[] = '<li><a href="' . esc_url(get_category_link( $cat->term_id )) . '" title="' . esc_attr($cat->name) . '">' . esc_html($cat->name) . '</a></li>';
                endforeach;
                echo join( '', $cats );
            endif;
        }
        echo '<li>'.get_the_title().'</li>';
    }
    /* tag */
    if( is_tag() ){ echo '<li>'."Tag: ".single_tag_title('',FALSE).'</li>'; }
    /* search */
    if( is_search() ){ echo '<li>'.esc_html__("Search", 'laboom').'</li>'; }
    /* date */
    if( is_year() ){ echo '<li>'.get_the_time().'</li>'; }
    /* 404 */
    if( is_404() ) {
        echo '<li>'.esc_html__("404 - Page not Found", 'laboom').'</li>';
    }
    /* archive */
    if( is_archive() && is_post_type_archive() ) {
        $title = post_type_archive_title( '', false );
        echo '<li>'. esc_html($title) .'</li>';
    }
    echo "</ul>";
}

/**
 * Display an optional post detail.
 */
function laboom_post_date_detail(){
    global $opt_theme_options;
    if(!isset($opt_theme_options['single_date']) || (isset($opt_theme_options['single_date']) && $opt_theme_options['single_date'])): ?>
    <div class="detail-date">
        <span class="day"><?php echo get_the_date('d');?></span>
        <span class="month"><?php echo get_the_date('M');?></span>
    </div>
     <?php endif;
 }
function laboom_post_detail(){
    global $opt_theme_options;

    ?>
    <div class="meta-info">
        <ul class="archive_detail">
            <?php if(!isset($opt_theme_options['single_author']) || (isset($opt_theme_options['single_author']) && $opt_theme_options['single_author'])): ?>

                <li class="avt">
                    <i class="fa fa-user" aria-hidden="true"></i> <span class="detail-author"><?php the_author_posts_link(); ?> </span>
                </li>
            <?php endif; ?>
            <?php if(!isset($opt_theme_options['single_comment']) || (isset($opt_theme_options['single_comment']) && $opt_theme_options['single_comment'])): ?>

                <li class="detail-comment"> <i class="fa fa-comments-o" aria-hidden="true"></i> <?php echo esc_html(comments_number('0','1','%')); ?> <?php esc_html_e('Comments', 'laboom'); ?></li>

            <?php endif; ?>
            <?php if(has_category() && (!isset($opt_theme_options['single_categories']) || (isset($opt_theme_options['single_categories']) && $opt_theme_options['single_categories']))): ?>

                <li class="detail-terms"><i class="fa fa-folder-open-o" aria-hidden="true"></i> <?php the_terms( get_the_ID(), 'category', '', ', ' ); ?></li>

            <?php endif; ?>
            <?php if(has_tag() && (!isset($opt_theme_options['single_tag']) || (isset($opt_theme_options['single_tag']) && $opt_theme_options['single_tag']))): ?>

                <li class="detail-tags"><i class="fa fa-tags" aria-hidden="true"></i> <?php the_tags('', ', ' ); ?></li>

            <?php endif; ?>
        </ul>
    </div>

    <?php
}

/**
 * Display an optional post video.
 */
function laboom_post_video() {

    global $opt_meta_options, $wp_embed;

    /* no video. */
    if(empty($opt_meta_options['opt-video-type'])) {
        laboom_post_thumbnail();
        return;
    }

    if($opt_meta_options['opt-video-type'] == 'local' && !empty($opt_meta_options['otp-video-local']['id'])){

        $video = wp_get_attachment_metadata($opt_meta_options['otp-video-local']['id']);

        echo do_shortcode('[video width="'.esc_attr($opt_meta_options['otp-video-local']['width']).'" height="'.esc_attr($opt_meta_options['otp-video-local']['height']).'" '.$video['fileformat'].'="'.esc_url($opt_meta_options['otp-video-local']['url']).'" poster="'.esc_url($opt_meta_options['otp-video-thumb']['url']).'"][/video]');

    } elseif($opt_meta_options['opt-video-type'] == 'youtube' && !empty($opt_meta_options['opt-video-youtube'])) {

        echo do_shortcode($wp_embed->run_shortcode('[embed]'.esc_url($opt_meta_options['opt-video-youtube']).'[/embed]'));

    } elseif($opt_meta_options['opt-video-type'] == 'vimeo' && !empty($opt_meta_options['opt-video-vimeo'])) {

        echo do_shortcode($wp_embed->run_shortcode('[embed]'.esc_url($opt_meta_options['opt-video-vimeo']).'[/embed]'));

    }
}

/**
 * Display an optional post audio.
 */
function laboom_post_audio() {
    global $opt_meta_options;

    /* no audio. */
    if(empty($opt_meta_options['otp-audio']['id'])) {
        laboom_post_thumbnail();
        return;
    }

    $audio = wp_get_attachment_metadata($opt_meta_options['otp-audio']['id']);

    echo do_shortcode('[audio '.$audio['fileformat'].'="'.esc_url($opt_meta_options['otp-audio']['url']).'"][/audio]');
}

/**
 * Display an optional post gallery.
 */
function laboom_post_gallery(){
    global $opt_meta_options;

    /* no audio. */
    if(empty($opt_meta_options['opt-gallery'])) {
        laboom_post_thumbnail();
        return;
    }

    $array_id = explode(",", $opt_meta_options['opt-gallery']);

    ?>
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php $i = 0; ?>
            <?php foreach ($array_id as $image_id): ?>
                <?php
                $attachment_image = wp_get_attachment_image_src($image_id, 'full', false);
                if($attachment_image[0] != ''):?>
                    <li data-target="#carousel-example-generic" data-slide-to="<?php echo esc_attr($i);?>" class="<?php if( $i == 0 ){ echo 'active'; } ?>"></li>
                    <?php $i++; endif; ?>
            <?php endforeach; ?>
        </ol>
        <div class="carousel-inner">
            <?php $i = 0; ?>
            <?php foreach ($array_id as $image_id): ?>
                <?php
                $attachment_image = wp_get_attachment_image_src($image_id, 'full', false);
                if($attachment_image[0] != ''):?>
                    <div class="item <?php if( $i == 0 ){ echo 'active'; } ?>">
                        <img style="width:100%;" data-src="holder.js" src="<?php echo esc_url($attachment_image[0]);?>" alt="" />
                    </div>
                <?php $i++; endif; ?>
            <?php endforeach; ?>
        </div>
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="fa fa-angle-left"></span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="fa fa-angle-right"></span>
        </a>

    </div>
    <?php
}

/**
 * Display an optional post quote.
 */
function laboom_post_quote() {
    global $opt_meta_options;

    if(empty($opt_meta_options['opt-quote-content'])){
        laboom_post_thumbnail();
        return;
    }

    $opt_meta_options['opt-quote-title'] = !empty($opt_meta_options['opt-quote-title']) ? '<span>'.esc_html($opt_meta_options['opt-quote-title']).'</span>' : '' ;
    $opt_meta_options['opt-quote-subtitle'] = !empty($opt_meta_options['opt-quote-subtitle']) ? '<span>'.esc_html($opt_meta_options['opt-quote-subtitle']).'</span>' : '' ;

    echo '<blockquote>'.esc_html($opt_meta_options['opt-quote-content']).'<h3>'.wp_kses_post($opt_meta_options['opt-quote-title']).'</h3><h5>'.wp_kses_post($opt_meta_options['opt-quote-subtitle']).'</blockquote>';
}

/**
 * Display an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index
 * views, or a div element when on single views.
 */
function laboom_post_thumbnail() {
    if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
        return;
    }

    echo '<div class="post-thumbnail">';
            the_post_thumbnail();
    echo '</div>';
}

function laboom_post_sidebar(){
    global $opt_theme_options,$opt_meta_options;

    $_sidebar = 'right';
    if(isset($opt_meta_options['enable_post_sidebar']) && $opt_meta_options['enable_post_sidebar']){
        $_sidebar = $opt_meta_options['single_layout'];
    }
    elseif(isset($opt_theme_options['single_layout']))
        $_sidebar = $opt_theme_options['single_layout'];

    return 'is-sidebar-' . esc_attr($_sidebar);
}

function laboom_post_class(){
    global $opt_theme_options,$opt_meta_options;

    $_class = "col-xs-12 col-sm-8 col-md-8 col-lg-8";
    if(isset($opt_meta_options['enable_post_sidebar']) && $opt_meta_options['enable_post_sidebar']){
        $opt_theme_options['single_layout'] = $opt_meta_options['single_layout'];
    }
    if(isset($opt_theme_options['single_layout']) && $opt_theme_options['single_layout'] == 'full')
        $_class = "col-xs-12 col-sm-12 col-md-10 col-lg-10 col-md-offset-1 col-lg--offset-1";
    echo esc_attr($_class);
}

/**
 * Display an optional archive detail.
 */
function laboom_archive_detail(){
    global $opt_theme_options;
    ?>
        <div class="meta-info">
            <ul class="archive_detail">
                <?php if(!isset($opt_theme_options['archive_author']) || (isset($opt_theme_options['archive_author']) && $opt_theme_options['archive_author'])): ?>
                        <li class="detail-author"><i class="fa fa-user" aria-hidden="true"></i><?php esc_html_e('By', 'laboom'); ?> <?php the_author_posts_link(); ?> </li>
                <?php endif; ?>

                <?php if(!isset($opt_theme_options['archive_comment']) || (isset($opt_theme_options['archive_comment']) && $opt_theme_options['archive_comment'])): ?>

                    <li class="detail-comment">
                        <a href="<?php the_permalink(); ?>">
                            <i class="fa fa-comments-o" aria-hidden="true"></i> <?php echo esc_html(comments_number('0','1','%')); ?> <?php esc_html_e('Comments', 'laboom'); ?>
                        </a>
                    </li>

                <?php endif; ?>
                <?php if(has_category() && (!isset($opt_theme_options['archive_categories']) || (isset($opt_theme_options['archive_categories']) && $opt_theme_options['archive_categories']))): ?>

                    <li class="detail-terms"><i class="fa fa-folder-open-o" aria-hidden="true"></i> <?php the_terms( get_the_ID(), 'category', '', ', ' ); ?></li>

                <?php endif; ?>
                <?php if(has_tag() && (!isset($opt_theme_options['archive_tag']) || (isset($opt_theme_options['archive_tag']) && $opt_theme_options['archive_tag']))): ?>

                    <li class="detail-tags"><i class="fa fa-tags" aria-hidden="true"></i> <?php the_tags('', ', ' ); ?></li>

                <?php endif; ?>
             </ul>
        </div>

    <?php
}
function laboom_date_detaile(){
    global $opt_theme_options;
    if(!isset($opt_theme_options['archive_date']) || (isset($opt_theme_options['archive_date']) && $opt_theme_options['archive_date'])): ?>
       <div class="detail-date">
           <span class="day"><?php echo get_the_date('d');?></span>
           <span class="month"><?php echo get_the_date('M');?></span>
       </div>

    <?php endif;
}


function laboom_archive_sidebar(){
    global $opt_theme_options;

    $_sidebar = 'right';

    if(isset($opt_theme_options['archive_layout']))
        $_sidebar = $opt_theme_options['archive_layout'];

    return 'is-sidebar-' . esc_attr($_sidebar);
}

function laboom_archive_class(){
    global $opt_theme_options;

    $_class = "col-xs-12 col-sm-8 col-md-8 col-lg-8";

    if(isset($opt_theme_options['archive_layout']) && $opt_theme_options['archive_layout'] == 'full')
        $_class = "col-xs-12 col-sm-12 col-md-12 col-lg-12";

    echo esc_attr($_class);
}
function laboom_footer(){
    global $opt_theme_options, $opt_meta_options;
    if(!isset($opt_theme_options)){
        get_template_part('inc/footer/footer', '-1');
        return;
    }
    if (is_404()){
        return;
    }
    if(is_page() && !empty($opt_meta_options['custom_footer']))
        $opt_theme_options['footer_layout'] = $opt_meta_options['footer_layout'];
    /* load custom header template. */
    get_template_part('inc/footer/footer', $opt_theme_options['footer_layout']);
}

/*footer top*/
function laboom_footer_top1(){
    global $opt_theme_options,$opt_meta_options;
    if (is_404()){
        return;

    }?>
        <div id="footer-top" style="fill:<?php if(!empty($opt_theme_options['footer_top_background']['background-color'])){ echo esc_html($opt_theme_options['footer_top_background']['background-color']);}?>">
            <svg class="row-svg-bottom" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 147.7 35.2" style="enable-background:new 0 0 147.7 35.2;" xml:space="preserve"><g><g><path class="st0" d="M147.7,35.2c-49.2,0-98.5,0-147.7,0c10.4-3.6,18.7-10.6,27.5-16.9c7.7-5.6,16.1-10,24.9-13.8c14.5-6.2,28.8-6.1,43.2,0.1c9.9,4.2,19.2,9.4,27.8,15.9C130.9,26.4,138.6,31.9,147.7,35.2z"></path></g></g></svg>
            <div class="container">
                <div class="row">
                    <div class="footer-top2 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <?php
                        if (!empty($opt_theme_options['footer_bottom_logo']['url'])){
                            echo '<a class="footer-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . get_bloginfo("name") . '" src="' . esc_url($opt_theme_options['footer_bottom_logo']['url']) . '"></a>';
                        }
                        if (!empty($opt_theme_options['cms_footer_address'])) {
                            echo wp_kses_post($opt_theme_options['cms_footer_address']);
                        }
                        ?>

                    </div>

                </div>
            </div>
        </div><!-- #footer-top -->
        <?php
}
function laboom_footer_top2(){
    global $opt_theme_options,$opt_meta_options;
    if (is_404()){
        return;

    }?>
        <div id="footer-top" class="layout2">
            <div class="container">
                <div class="row">
                    <div class="footer-top2 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <?php
                        if (!empty($opt_theme_options['cms_footer_address'])) {
                            echo wp_kses_post($opt_theme_options['cms_footer_address']);
                        }
                        ?>

                    </div>

                </div>
            </div>
        </div><!-- #footer-top -->
        <?php
}
function laboom_footer_top3(){
    global $opt_theme_options,$opt_meta_options;
    if (is_404()){
        return;

    }?>
        <div id="footer-top" class="layout4">
            <div class="container">
                <div class="row">
                    <div class="footer-top1 col-lg-3 col-md-3 col-sm-4 col-xs-12">
                        <?php
                        if (!empty($opt_theme_options['footer_bottom_logo']['url'])){
                            echo '<a class="footer-logo4" href="' . esc_url(home_url('/')) . '"><img alt="' . get_bloginfo("name") . '" src="' . esc_url($opt_theme_options['footer_bottom_logo']['url']) . '"></a>';
                        }
                        if (!empty($opt_theme_options['cms_footer_address'])) {
                            echo wp_kses_post($opt_theme_options['cms_footer_address']);
                        }
                        ?>


                    </div>
                    <div class="footer-top2 col-lg-6 col-md-6 col-sm-4 col-xs-12">
                        <?php if ( is_active_sidebar( 'sidebar-footer-top-1' ) ) : ?>
                               <?php dynamic_sidebar( 'sidebar-footer-top-1' ); ?>
                        <?php endif; ?>

                    </div>
                    <div class="footer-top3 col-lg-3 col-md-3 col-sm-4 col-xs-12">
                        <?php if ( is_active_sidebar( 'sidebar-footer-top-2' ) ) : ?>
                            <?php dynamic_sidebar( 'sidebar-footer-top-2' ); ?>
                        <?php endif;
                        laboom_cms_footer_social();

                        ?>

                    </div>
                </div>
            </div>
        </div><!-- #footer-top -->
        <?php
}
function laboom_footer_top4(){
    global $opt_theme_options;
    if (is_404()){
        return;

    }?>
        <div id="footer-top" class="layout5" style="fill:<?php if(!empty($opt_theme_options['footer_top_background']['background-color'])){ echo esc_html($opt_theme_options['footer_top_background']['background-color']);}?>">
                <svg class="row-svg-bottom" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 147.7 35.2" style="enable-background:new 0 0 147.7 35.2;" xml:space="preserve"><g><g><path class="st0" d="M147.7,35.2c-49.2,0-98.5,0-147.7,0c10.4-3.6,18.7-10.6,27.5-16.9c7.7-5.6,16.1-10,24.9-13.8c14.5-6.2,28.8-6.1,43.2,0.1c9.9,4.2,19.2,9.4,27.8,15.9C130.9,26.4,138.6,31.9,147.7,35.2z"></path></g></g></svg>

                            <?php
                            if (!empty($opt_theme_options['footer_bottom_logo']['url'])){
                                echo '<a class="footer-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . get_bloginfo("name") . '" src="' . esc_url($opt_theme_options['footer_bottom_logo']['url']) . '"></a>';
                            }
                            ?>



            <div class="container">
                <div class="row">
                    <div class="footer-top1 col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <?php if ( is_active_sidebar( 'sidebar-footer-top-3' ) ) : ?>
                            <?php dynamic_sidebar( 'sidebar-footer-top-3' ); ?>
                        <?php endif;
                        laboom_cms_footer_social();
                        ?>
                    </div>
                    <div class="footer-top2 col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <?php if ( is_active_sidebar( 'sidebar-footer-top-4' ) ) : ?>
                               <?php dynamic_sidebar( 'sidebar-footer-top-4' ); ?>
                        <?php endif; ?>

                    </div>
                    <div class="footer-top3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <?php if ( is_active_sidebar( 'sidebar-footer-top-5' ) ) : ?>
                            <?php dynamic_sidebar( 'sidebar-footer-top-5' ); ?>
                        <?php endif; ?>

                    </div>
                     <div class="footer-top4 col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <?php if ( is_active_sidebar( 'sidebar-footer-top-6' ) ) : ?>
                            <?php dynamic_sidebar( 'sidebar-footer-top-6' ); ?>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div><!-- #footer-top -->
        <?php
}

function laboom_cms_footer_social() {

    global $opt_theme_options;

    $cms_footer_social = $opt_theme_options['cms_footer_social']['enabled'];
    ?>
    <ul class="cms-footer-social">
        <?php
        if ($cms_footer_social): foreach ($cms_footer_social as $key=>$value) {
            switch($key) {
                case 'facebook': echo '<li><a href="'.esc_url($opt_theme_options['social_facebook_url']).'"><i class="fa fa-facebook" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'twitter': echo '<li><a href="'.esc_url($opt_theme_options['social_twitter_url']).'"><i class="fa fa-twitter" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'instagram': echo '<li><a href="'.esc_url($opt_theme_options['social_instagram_url']).'"><i class="fa fa-instagram" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'printest': echo '<li><a href="'.esc_url($opt_theme_options['social_printest_url']).'"><i class="fa fa-pinterest-p" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'dribbble': echo '<li><a href="'.esc_url($opt_theme_options['social_dribbble_url']).'"><i class="fa fa-dribbble" aria-hidden="true"></i>'.'</a></li>';
                    break;
                case 'google': echo '<li><a href="'.esc_url($opt_theme_options['social_google_url']).'"><i class="fa fa-google-plus" aria-hidden="true"></i>'.'</a></li>';
                    break;
            }
        }
        endif;
        ?>
    </ul>
    <?php
}
function laboom_footer_bottom()
{
    global $opt_theme_options;
 ?>
    <div id="footer-bottom">
        <div class="container">
            <div class="container-inner">
                <div class="row">
                    <div class="copyrighter col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <?php if(!empty($opt_theme_options['footer_copyright'])){
                            echo wp_kses_post($opt_theme_options['footer_copyright']);
                        }
                        else { echo 'Copyright &copy;'.date(' Y').esc_html__(' Polygon Theme. All rights reserved.','laboom');
                        }

                        ?>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <?php
                        laboom_cms_footer_social();
                        ?>
                    </div>
                </div>
            </div>

        </div>
    </div><!-- #footer-top -->
    <div id="footer-google-map">
        <svg class="row-svg-bottom" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 147.7 35.2" style="enable-background:new 0 0 147.7 35.2;" xml:space="preserve"><g><g><path class="st0" d="M147.7,35.2c-49.2,0-98.5,0-147.7,0c10.4-3.6,18.7-10.6,27.5-16.9c7.7-5.6,16.1-10,24.9-13.8c14.5-6.2,28.8-6.1,43.2,0.1c9.9,4.2,19.2,9.4,27.8,15.9C130.9,26.4,138.6,31.9,147.7,35.2z"></path></g></g></svg>
            <div class="button-google-map">
                <i class="lnr lnr-map-marker"></i>
                <span><?php echo esc_html__('Find us on Map','laboom');?></span>

            </div>
    </div><!-- #footer-top -->
    <div id="footer-google-map-wrap">
        <div class="button-google-map">
            <i class="lnr lnr-map-marker"></i>
            <span><?php echo esc_html__('Find us on Map','laboom');?></span>

        </div>
        <svg class="row-svg-bottom" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 147.7 35.2" style="enable-background:new 0 0 147.7 35.2;" xml:space="preserve"><g><g><path class="st0" d="M147.7,35.2c-49.2,0-98.5,0-147.7,0c10.4-3.6,18.7-10.6,27.5-16.9c7.7-5.6,16.1-10,24.9-13.8c14.5-6.2,28.8-6.1,43.2,0.1c9.9,4.2,19.2,9.4,27.8,15.9C130.9,26.4,138.6,31.9,147.7,35.2z"></path></g></g></svg>
        <?php  if (!empty($opt_theme_options['map_markericon']['url'])){

            $image_url = $opt_theme_options['map_markericon']['url'];
        }
        else{
            $image_url='';
        }?>
        <?php
        $map_address = !empty($opt_theme_options['map_address']) ? $opt_theme_options['map_address']: '';
        $map_api = !empty($opt_theme_options['map_api']) ? $opt_theme_options['map_api']: 'AIzaSyBAW_lHcTkvGxTvTSrg-a07ZvtYmDze7tI';
        $map_coordinate = !empty($opt_theme_options['map_coordinate']) ? $opt_theme_options['map_coordinate']: '';
        $map_markercoordinate = !empty($opt_theme_options['map_markercoordinate']) ? $opt_theme_options['map_markercoordinate']: '';
        echo do_shortcode('[cms_googlemap api="'.$map_api.'" address="'.$map_address.'" coordinate="'. $map_coordinate.'" markercoordinate="'.$map_markercoordinate.'" markericon="'.$image_url.'" style="custom" height="455px"]JTVCJTBBJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZmVhdHVyZVR5cGUlMjIlM0ElMjAlMjJhbGwlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJlbGVtZW50VHlwZSUyMiUzQSUyMCUyMmxhYmVscy50ZXh0LmZpbGwlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyc2F0dXJhdGlvbiUyMiUzQSUyMDM2JTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjA0MCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIyYWxsJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZWxlbWVudFR5cGUlMjIlM0ElMjAlMjJsYWJlbHMudGV4dC5zdHJva2UlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIydmlzaWJpbGl0eSUyMiUzQSUyMCUyMm9uJTIyJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAxNiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIyYWxsJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZWxlbWVudFR5cGUlMjIlM0ElMjAlMjJsYWJlbHMuaWNvbiUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMnN0eWxlcnMlMjIlM0ElMjAlNUIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJ2aXNpYmlsaXR5JTIyJTNBJTIwJTIyb2ZmJTIyJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVEJTBBJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZmVhdHVyZVR5cGUlMjIlM0ElMjAlMjJhZG1pbmlzdHJhdGl2ZSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmVsZW1lbnRUeXBlJTIyJTNBJTIwJTIyZ2VvbWV0cnkuZmlsbCUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMnN0eWxlcnMlMjIlM0ElMjAlNUIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJjb2xvciUyMiUzQSUyMCUyMiUyMzAwMDAwMCUyMiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmxpZ2h0bmVzcyUyMiUzQSUyMDIwJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVEJTBBJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZmVhdHVyZVR5cGUlMjIlM0ElMjAlMjJhZG1pbmlzdHJhdGl2ZSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmVsZW1lbnRUeXBlJTIyJTNBJTIwJTIyZ2VvbWV0cnkuc3Ryb2tlJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyc3R5bGVycyUyMiUzQSUyMCU1QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmNvbG9yJTIyJTNBJTIwJTIyJTIzMDAwMDAwJTIyJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIybGlnaHRuZXNzJTIyJTNBJTIwMTclMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJ3ZWlnaHQlMjIlM0ElMjAxLjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUQlMEElMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJmZWF0dXJlVHlwZSUyMiUzQSUyMCUyMmxhbmRzY2FwZSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmVsZW1lbnRUeXBlJTIyJTNBJTIwJTIyZ2VvbWV0cnklMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAyMCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIycG9pJTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZWxlbWVudFR5cGUlMjIlM0ElMjAlMjJnZW9tZXRyeSUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMnN0eWxlcnMlMjIlM0ElMjAlNUIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJjb2xvciUyMiUzQSUyMCUyMiUyMzAwMDAwMCUyMiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmxpZ2h0bmVzcyUyMiUzQSUyMDIxJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTVEJTBBJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZmVhdHVyZVR5cGUlMjIlM0ElMjAlMjJyb2FkLmhpZ2h3YXklMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJlbGVtZW50VHlwZSUyMiUzQSUyMCUyMmdlb21ldHJ5LmZpbGwlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAxNyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIycm9hZC5oaWdod2F5JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyZWxlbWVudFR5cGUlMjIlM0ElMjAlMjJnZW9tZXRyeS5zdHJva2UlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAyOSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMndlaWdodCUyMiUzQSUyMDAuMiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIycm9hZC5hcnRlcmlhbCUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmVsZW1lbnRUeXBlJTIyJTNBJTIwJTIyZ2VvbWV0cnklMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAxOCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIycm9hZC5sb2NhbCUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmVsZW1lbnRUeXBlJTIyJTNBJTIwJTIyZ2VvbWV0cnklMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAxNiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIydHJhbnNpdCUyMiUyQyUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmVsZW1lbnRUeXBlJTIyJTNBJTIwJTIyZ2VvbWV0cnklMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJzdHlsZXJzJTIyJTNBJTIwJTVCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyY29sb3IlMjIlM0ElMjAlMjIlMjMwMDAwMDAlMjIlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJsaWdodG5lc3MlMjIlM0ElMjAxOSUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3RCUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU1RCUwQSUyMCUyMCUyMCUyMCU3RCUyQyUwQSUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmZlYXR1cmVUeXBlJTIyJTNBJTIwJTIyd2F0ZXIlMjIlMkMlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjJlbGVtZW50VHlwZSUyMiUzQSUyMCUyMmdlb21ldHJ5JTIyJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIyc3R5bGVycyUyMiUzQSUyMCU1QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMmNvbG9yJTIyJTNBJTIwJTIyJTIzMDAwMDAwJTIyJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdEJTJDJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTdCJTBBJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIwJTIybGlnaHRuZXNzJTIyJTNBJTIwMTclMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlN0QlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlNUQlMEElMjAlMjAlMjAlMjAlN0QlMEElNUQ=[/cms_googlemap]');?>
    </div><!-- #footer-top -->

    <?php
}

 function laboom_footer_bottom2()
{
    global $opt_theme_options;
    ?>
    <div id="footer-bottom" class="layout2">
        <div class="container">
            <div class="container-inner">
                <div class="row">
                    <div class="copyrighter col-lg-5 col-md-5 col-sm-7 col-xs-12">
                        <?php if(!empty($opt_theme_options['footer_copyright'])){
                            echo wp_kses_post($opt_theme_options['footer_copyright']);
                        }
                        else { echo 'Copyright &copy;'.date(' Y').esc_html__(' Polygon Theme. All rights reserved.','laboom');
                        }

                        ?>
                    </div>
                    <div class="logo-footer col-lg-2 col-md-2 hidden-xs hidden-sm">
                        <?php if (!empty($opt_meta_options['footer_bottom_logo_logo2']['url'])){
                        $footer_logo_bottom = $opt_meta_options['footer_bottom_logo_logo2']['url'];
                        }
                        else{
                        $footer_logo_bottom = $opt_theme_options['footer_bottom_logo_logo2']['url'];
                        }
                        if (!empty( $footer_logo_bottom)){
                        echo '<a class="footer-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . get_bloginfo("name") . '" src="' . esc_url($footer_logo_bottom) . '"></a>';
                        }?>
                    </div>

                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                        <?php
                        laboom_cms_footer_social();
                        ?>
                    </div>
                </div>
            </div>

        </div>
    </div><!-- #footer-top -->
    <?php
}
function laboom_footer_bottom3()
{
    global $opt_theme_options,$opt_meta_options;
    ?>
    <div id="footer-bottom" class="layout3">
        <div class="container">
            <div class="container-inner">
                <div class="row">
                    <div class="copyrighter col-lg-5 col-md-5 col-sm-7 col-xs-12">
                        <?php if(!empty($opt_theme_options['footer_copyright'])){
                            echo wp_kses_post($opt_theme_options['footer_copyright']);
                        }
                        else { echo 'Copyright &copy;'.date(' Y').esc_html__(' Polygon Theme. All rights reserved.','laboom');
                        }

                        ?>
                    </div>
                    <div class="logo-footer col-lg-2 col-md-2 hidden-xs hidden-sm">
                        <?php
                        if (!empty($opt_meta_options['footer_bottom_logo_logo2']['url'])){
                            $footer_logo_bottom = $opt_meta_options['footer_bottom_logo_logo2']['url'];
                        }
                        else{
                            $footer_logo_bottom = $opt_theme_options['footer_bottom_logo_logo2']['url'];
                        }
                        if (!empty( $footer_logo_bottom)){
                            echo '<a class="footer-logo" href="' . esc_url(home_url('/')) . '"><img alt="' . get_bloginfo("name") . '" src="' . esc_url($footer_logo_bottom) . '"></a>';
                        }?>
                    </div>

                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                        <?php
                        laboom_cms_footer_social();
                        ?>
                    </div>
                </div>
            </div>

        </div>
    </div><!-- #footer-top -->
    <?php
}
function laboom_footer_bottom4()
{
    global $opt_theme_options,$opt_meta_options;
    ?>
    <div id="footer-bottom" class="layout4">
        <div class="container">
            <div class="container-inner">
                <div class="row">
                    <div class="copyrighter col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <?php if(!empty($opt_theme_options['footer_copyright'])){
                            echo wp_kses_post($opt_theme_options['footer_copyright']);
                        }
                        else { echo 'Copyright &copy;'.date(' Y').esc_html__(' Polygon Theme. All rights reserved.','laboom');
                        }

                        ?>
                    </div>

                </div>
            </div>

        </div>
    </div><!-- #footer-top -->
    <?php
}
function laboom_footer_bottom5()
{
    global $opt_theme_options,$opt_meta_options;
    ?>
    <div id="footer-bottom" class="layout5">
        <div class="container">
            <div class="container-inner">
                <div class="row">
                    <div class="copyrighter col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <?php if(!empty($opt_theme_options['footer_copyright'])){
                            echo wp_kses_post($opt_theme_options['footer_copyright']);
                        }
                        else { echo 'Copyright &copy;'.date(' Y').esc_html__(' Polygon Theme. All rights reserved.','laboom');
                        }

                        ?>
                    </div>

                </div>
            </div>

        </div>
    </div><!-- #footer-top -->
    <?php
}
function laboom_footer_back_to_top(){
    global $opt_theme_options;

    $_back_to_top = true;

    if(isset($opt_theme_options['general_back_to_top']))
        $_back_to_top = $opt_theme_options['general_back_to_top'];

    if($_back_to_top)
        echo '<div class="ef3-back-to-top"><i class="lnr lnr-arrow-up"></i></div>';
}
function laboom_search_popup() {?>

        <div class="cshero-popup-search <?php laboom_body_boxed();?> <?php laboom_header_layout_class();?>">
            <div class="cshero-search-inner container placeholder-gray">
                <?php get_search_form(); ?>
            </div>
        </div>
       <?php

}
/**
* social team
 */
function laboom_position_team(){
    global $opt_meta_options;
    $team_position = !empty($opt_meta_options['team_position']) ? $opt_meta_options['team_position']: '';
     echo esc_attr($team_position);
}
/** social team
 */
function laboom_social_team()
{
    global $opt_meta_options;
    ?>
    <?php if (isset($opt_meta_options['link_icon1']) && isset($opt_meta_options['icon1'])) { ?>
    <div class="social-item">
        <a class="<?php echo esc_attr($opt_meta_options['icon1']);?>" href="<?php echo esc_url($opt_meta_options['link_icon1']);?>"></a>
    </div>
<?php }?>
    <?php if (!empty($opt_meta_options['link_icon2']) && !empty($opt_meta_options['icon2'])) { ?>
    <div class="social-item">
        <a class="<?php echo esc_attr($opt_meta_options['icon2']);?>" href="<?php echo esc_url($opt_meta_options['link_icon2']);?>"></a>
    </div>
<?php }?>
    <?php if (!empty($opt_meta_options['link_icon3']) && !empty($opt_meta_options['icon3'])) { ?>
    <div class="social-item">
        <a class="<?php echo esc_attr($opt_meta_options['icon3']);?>" href="<?php echo esc_url($opt_meta_options['link_icon3']);?>"></a>
    </div>
<?php }?>
    <?php if (!empty($opt_meta_options['link_icon4']) && !empty($opt_meta_options['icon4'])) { ?>
    <div class="social-item">
        <a class="<?php echo esc_attr($opt_meta_options['icon4']);?>" href="<?php echo esc_url($opt_meta_options['link_icon4']);?>"></a>
    </div>
<?php }?>
    <?php if (!empty($opt_meta_options['link_icon5']) && !empty($opt_meta_options['icon5'])) { ?>
    <div class="social-item">
        <a class="<?php echo esc_attr($opt_meta_options['icon5']);?>" href="<?php echo esc_url($opt_meta_options['link_icon5']);?>"></a>
    </div>
<?php }?>
    <?php if (!empty($opt_meta_options['link_icon6']) && !empty($opt_meta_options['icon6'])) { ?>
    <div class="social-item">
        <a class="<?php echo esc_attr($opt_meta_options['icon6']);?>" href="<?php echo esc_url($opt_meta_options['link_icon6']);?>"></a>
    </div>
<?php }?>
    <?php
}

function laboom_portfolio_info(){
    global $opt_meta_options;
    ?>
    <ul class="portfolio-info">
        <li><?php echo esc_html__('Client:','laboom');?> <span><?php echo esc_attr($opt_meta_options['portfolio_client']);?></span></li>
        <li><?php echo esc_html__('Location:','laboom');?> <span><?php echo esc_attr($opt_meta_options['portfolio_location']);?></span></li>
        <li><?php echo esc_html__('Date:','laboom');?> <span><?php the_time(get_option('date_format'))?></span></li>
        <li><?php echo esc_html__('Category:','laboom');?> <span><?php the_terms( get_the_ID(), 'portfolio_categories', '', ', ' ); ?></span></li>
    </ul>
<?php
}
/* Related Pportfolio */
function laboom_related_portfolio($id) {
    global $post;
    $_group = array();
    $category_name = array();

    $post_terms = get_the_terms($post->ID, 'portfolio-categories' );

    foreach ($post_terms as $p_term){
        $_group[] = $p_term->slug;
        $category_name[] = $p_term->name;
    }

    $query_data = array(
        'post_type' => 'portfolio',
        'posts_per_page' => 3,
        'post_status'=> 'publish',
        'post__not_in'=>array($id),
        'tax_query' => array(
            array(
                'taxonomy' => 'portfolio-categories',
                'field' => 'slug',
                'terms' => $category_name,
            )
        )
    );
    $query = new WP_Query($query_data);

    if($query->have_posts()){
        ?> <div class="cms-related-post  template-cms_grid--layout-portfolio template-cms_grid--layout-portfolio2 clearfix">
             <h4 class="title"><?php echo esc_html__('Related items','laboom');?></h4>
             <div class="row">
            <?php
            while ($query->have_posts()): $query->the_post();
                ?>
                <div class="item-post cms-grid-item col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="cms-grid-3columns">
                        <?php
                        if(has_post_thumbnail()):
                            $thumbnail = the_post_thumbnail('wp_ laboom_portfolio800X600');
                            $thumbnail_url = wp_get_attachment_url(get_the_post_thumbnail('full'));
                        else:
                            $thumbnail = '<img src="'.esc_url(CMS_IMAGES).'no-image.jpg" alt="'.get_the_title().'" />';
                            $thumbnail_url = '' .get_template_directory_uri(). '/assets/images/no-image.jpg';
                        endif;
                        echo '<div class="cms-grid-media">'.$thumbnail.'</div>';
                        ?>
                        <div class="text-hide">
                            <div class="text-hide-inner">
                                <div class="cms-gallery-item">
                                    <a class="cms-prettyphoto p-view" href="<?php echo esc_url($thumbnail_url);?>">K</a>
                                </div>
                                <div class="combine"> <a href="<?php the_permalink(); ?>">9</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="text-left">

                        <h4 class="title">
                            <a href="<?php the_permalink(); ?>"><?php the_title();?></a>
                        </h4>
                        <p> <?php echo wp_trim_words(strip_tags(strip_shortcodes(get_the_content())),20,'.') ?></p>
                    </div>
                </div>
                <?php
            endwhile;

            ?> </div> </div><?php
    }

    wp_reset_postdata();
}
/*call to action portfolio*/
function laboom_cta_portfolio() {
    global $opt_theme_options;?>
    <div class="cta-portfolio">
        <div class="container">
            <div class="row">
                <div class="col-sm-7 col-xs-12">
                    <aside class="">
                        <h2><?php echo esc_attr($opt_theme_options['cta-portfolio-title']);?></h2>
                        <p><?php echo esc_attr($opt_theme_options['cta-portfolio-subtitle']);?></p>
                    </aside>
                </div>
                <div class="col-sm-5 col-xs-12 text-right">
                    <?php if(!empty($opt_theme_options['cta-portfolio-button-text']))?>
                    <a type="button" href="<?php echo esc_url($opt_theme_options['cta-portfolio-button-link']);?>" class="btn btn-primary btn-lg pull-right btn-default2"><span class="<?php echo esc_attr($opt_theme_options['cta-portfolio-button-icon']);?>"></span> <?php echo esc_attr($opt_theme_options['cta-portfolio-button-text']);?></a>
               </div>
            </div>

        </div>
    </div>
<?php
}
/* Related Post */
function laboom_related_post($id) {
    global $post;

    $posttags = get_the_category($post->ID);

    if(empty($posttags)) return ;

    $tags = array();

    foreach ($posttags as $tag) {

        $tags[] = $tag->term_id;
    }

    $query = new WP_Query(array('posts_per_page'=> 3, 'post_type' => 'post',   'post__not_in'=>array($id),'post_status'=> 'publish', 'category__in'=>$tags));

    if($query->have_posts()){
        ?> <div class="cms-single-related-post clearfix">
             <h3 class="related-title"><span><?php esc_html_e('Related Posts', 'laboom'); ?></span></h3>
            <div class="row">
                <?php
                while ($query->have_posts()): $query->the_post();
                    ?>
                    <div class="item-post col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="item-inner">
                                <?php if(has_post_thumbnail()):
                                    the_post_thumbnail('wp_ laboom_blog250X176');
                                else :?>

                                    <img src= "<?php echo esc_url(get_template_directory_uri(). '/assets/images/no-image.jpg');?>" alt="" />

                                <?php endif; ?>
                                <div class="content-overlay">
                                    <div class="title">
                                                <h3 class="ft-helveticaneue-medium"><a href="<?php echo get_the_permalink(); ?>"><?php echo laboom_get_limit_str(get_the_title(), 0,40); ?></a></h3>
                                        <div class="date">
                                            <?php echo get_the_date(get_option( 'date_format' ));?>
                                        </div>
                                    </div>

                                </div>

                            </div>
                    </div>
                    <?php
                endwhile;

            ?> </div> </div><?php
    }

    wp_reset_postdata();
}
/* Post view */
function laboom_post_views($post_ID) {

    //Set the name of the Posts Custom Field.
    $count_key = 'post_views_count';

    //Returns values of the custom field with the specified key from the specified post.
    $count = get_post_meta($post_ID, $count_key, true);

    $count = $count ? (int)$count : 0 ;

    if(is_single()){

        $count++;

        update_post_meta($post_ID, $count_key, $count);

    }

    return $count;

}
/**
 *Admin info
 */
function laboom_admin_info(){
    global $opt_theme_options;
    ?>

    <div class="admin-avt">
        <?php echo get_avatar( get_the_author_meta( 'ID' ), 252 ); ?>
    </div>
    <div class="admin-info">
         <h3 class="author">   <?php the_author_posts_link();

             ?></h3>
        <div class="admin-des">

            <?php the_author_meta( 'description' ); ?>
        </div>
        <div class="admin-social">
            <ul>
                <li><a class="facebook" href="<?php echo esc_url($opt_theme_options['_admin_fb']); ?>" data-placement="bottom" data-toggle="tooltip" href="#" data-original-title="Facebook"><i class="fa fa-facebook"></i></a></li>
                <li><a class="twitter" href="<?php echo esc_url($opt_theme_options['_admin_tw']); ?>" data-placement="bottom" data-toggle="tooltip" href="#" data-original-title="Twitter"><i class="fa fa-twitter"></i></a></li>
                <li><a class="google" href="<?php echo esc_url($opt_theme_options['_admin_google']); ?>" data-placement="bottom" data-toggle="tooltip" href="#" data-original-title="Google"><i class="fa fa-google"></i></a></li>

            </ul>
        </div>
    </div>
    <?php
}
function laboom_carousel_post_popular(){

    global $wp_query;
    $wp_query = new WP_Query(array(
        'post_type' => 'post',
        'posts_per_page' => 9,
        'meta_query' => array(
            array(
                'key'=> 'post_views_count',
            ),
        ),
        'meta_key'   => 'post_views_count',
        'orderby'    => 'meta_value_num',
        'order'      => 'DESC',
    ));?>
    <h5 class="title-carousel ft-helveticaneue-medium"><?php echo esc_html__('Popular posts','laboom')?></h5>
    <div class=" carousel_post_popular template-cms_carousel-blog">
        <?php if ( have_posts() ) : ?>
            <?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
                /* Include the post format-specific template for the content. If you want to
                 * this in a child theme then include a file called called content-___.php
                 * (where ___ is the post format) and that will be used instead.
                 */
               ?>
                <div class="cms-carousel-item">
                    <div class="cms-carousel-item-inner">
                        <?php
                        if(has_post_thumbnail()):
                            $class = ' has-thumbnail';
                            $thumbnail = the_post_thumbnail('wp_ laboom_blog320X175');
                        else:
                            $class = ' no-image';
                            $thumbnail = '<img src="'.get_template_directory_uri(). '/assets/images/no-image.jpg" alt="'.get_the_title().'" />';
                        endif;
                        echo '<div class="cms-grid-media '.esc_attr($class).'">'.$thumbnail.'</div>';
                        ?>
                        <div class="content-right">
                            <h4 class="cms-carousel-title ft-helveticaneue-b">
                                <?php the_title();?>
                            </h4>
                            <div class="date">
                                <i class="zmdi zmdi-calendar-note"></i><?php echo get_the_date(get_option( 'date_format' ));?>
                            </div>
                            <div class="cms-carousel-content">
                                <?php echo wp_trim_words(strip_tags(strip_shortcodes(get_the_content())),20,'.') ?>
                            </div>
                            <div class="cms-more">
                                <a href="<?php the_permalink(); ?>"><?php echo esc_html__('Read more','laboom');?><i class="zmdi zmdi-caret-right-circle"></i></a>
                            </div>
                        </div>

                    </div>

                </div>
        <?php
            endwhile; // end of the loop.
        endif;
        ?>
    </div>
    <?php wp_reset_postdata();;
}
/**
 * Excerpt content.
 *
 * @param (int) string limited.
 * @return echo.
 */
if(!function_exists('wp_ laboom_the_excerpt')){
    function laboom_the_excerpt($limit = 50 , $before = '', $after = ''){

        $_wp_content = strip_tags(strip_shortcodes(get_the_content()));

        echo (strlen($_wp_content) <= $limit ) ? $_wp_content :  $before . substr($_wp_content, 0, (int)$limit) . $after;
    }
}
function laboom_single_team_info()
{
    global  $opt_meta_options;?>

    <div class="team-info">
           <?php echo esc_html__('Phone: ','laboom');?>  <?php echo esc_html($opt_meta_options['phone_team']);?>
        </div>
    <div class="team-info">
        <?php echo esc_html__('Email: ','laboom');?>  <?php echo esc_html($opt_meta_options['message_mail']);?>
    </div>
<?php
}
function laboom_single_awward_info()
{
    global $opt_meta_options;
    if(empty($opt_meta_options['honors_awards_team'])){
        return;
    }
    ?>
 <div class="team-award-wrap-all">
    <h3 class="team-carousel-title">
        <?php echo esc_html__('Honors & Awards','laboom');?>
    </h3>
    <div class="team-award-wrap">
       <?php
       $ids = explode(',',$opt_meta_options['honors_awards_team']);
       foreach ($ids as $id) {

           $image = wp_get_attachment_image_url($id,'estate_slide653X435');
           //echo $image;
           echo '<div class="gallery-item"><img class="img" src="' . esc_url($image) . '" alt=""/></div>';

       }?>
    </div>
 </div>
    <?php
}
function laboom_get_socials_share(){
    ?>
    <ul class="left">
        <li><label><?php  echo esc_html__('Share','laboom');?></label></li>
    <li><a title="Facebook" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink();?>"><i class="fa fa-facebook"></i></a></li>
    <li><a title="Twitter" target="_blank" href="https://twitter.com/home?status=<?php esc_html_e('Check out this article', 'laboom');?>:%20<?php the_title();?>%20-%20<?php the_permalink();?>"><i class="fa fa-twitter"></i></a></li>
    <li><a title="Google Plus" target="_blank" href="https://plus.google.com/share?url=<?php the_permalink();?>"><i class="fa fa-google-plus"></i></a></li>
    <li><a title ="Pinterest" target="_blank" href="https://pinterest.com/pin/create/button/??u=<?php the_permalink();?>"><i class="fa fa-pinterest"></i></a>   </li></ul>
    <?php
}
/*submit thi xoa tag di di*/
function laboom_post_wrap_bottom(){?>
    <div class="post-bottom-wrap">
        <?php laboom_get_socials_share();?>
        <?php if(has_tag()): ?>
           <div class="detail-tags right"><label><?php  echo esc_html__('Tags','laboom');?></label><?php the_tags('', '' ); ?></div>

        <?php endif; ?>
    </div>
<?php
}



