
    <?php laboom_footer_top1(); ?>
    <?php laboom_footer_bottom(); ?>