<?php

vc_map(array(
    "name" => 'Flex Appointment',
    "base" => "fsfa",
    "icon" => "cs_icon_for_vc",
    "category" => esc_html__('CmsSuperheroes Shortcodes', 'laboom'),
));

class WPBakeryShortCode_cms_flex_appointment extends CmsShortCode
{
    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}
