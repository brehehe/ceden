<?php
	vc_map( array(
		"name"            => 'CMS Reservation ',
		"base"            => "reservation",
		"icon"            => "cs_icon_for_vc",
		"category"        => esc_html__( 'CmsSuperheroes Shortcodes', "laboom" ),
		"params" => array(
		),
	) );
	
	class WPBakeryShortCode_cms_reservation extends CmsShortCode {
		protected function content( $atts, $content = null ) {
			return parent::content( $atts, $content );
		}
	}

?>