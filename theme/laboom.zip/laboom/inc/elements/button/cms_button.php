<?php
vc_map(array(
    "name" => 'CMS Button',
    "base" => "cms_button",
    "icon" => "cs_icon_for_vc",
    "category" => esc_html__('CmsSuperheroes Shortcodes', 'laboom'),
    "params" => array(
        array(
            "type" => "textfield",
            "heading" => __ ( 'Text on the button', 'laboom' ),
            "param_name" => "button_text",
            "value" => 'button',
            "group" => esc_html__("Button Settings", 'laboom')
        ),
        array(
            "type" => "vc_link",
            "class" => "",
            "heading" => esc_html__("Link button", 'laboom'),
            "param_name" => "link_button",
            "value" => '',
            "group" => esc_html__("Button Settings", 'laboom')
        ),
        /* Start Icon */
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon library', 'laboom' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'laboom' ) => 'fontawesome',
                esc_html__( 'Open Iconic', 'laboom' ) => 'openiconic',
                esc_html__( 'Typicons', 'laboom' ) => 'typicons',
                esc_html__( 'Entypo', 'laboom' ) => 'entypo',
                esc_html__( 'Linecons', 'laboom' ) => 'linecons',
                esc_html__( 'Pixel', 'laboom' ) => 'pixelicons',
                esc_html__( 'P7 Stroke', 'laboom' ) => 'pe7stroke',
                esc_html__( 'RT Icon', 'laboom' ) => 'rticon',
            ),
            'param_name' => 'icon_type',
            'description' => esc_html__( 'Select icon library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_fontawesome',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'fontawesome',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_openiconic',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'openiconic',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'openiconic',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_typicons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'typicons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'typicons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_entypo',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'entypo',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'entypo',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_linecons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'linecons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'linecons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_pixelicons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'pixelicons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'pixelicons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_pe7stroke',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'pe7stroke',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'pe7stroke',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'laboom' ),
            'param_name' => 'icon_rticon',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'rticon',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'rticon',
            ),
            'description' => esc_html__( 'Select icon from library.', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        /* End Icon */
        array(
            "type" => "dropdown",
            "class" => "",
            "heading" => esc_html__("Icon Align", 'laboom'),
            "admin_label" => true,
            "param_name" => "icon_align",
            "value" => array(
                "Left" => "left",
                "Right" => "right"
            ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Button Style", 'laboom'),
            'param_name' => 'button_style',
            'value' => array(
                'Theme Default' => 'btn-default',
                'Button Secondary' => 'btn-secondary',
                'Button Default Alt' => 'btn-default-alt1',
                'Button Default Alt style1' => 'btn-default-alt',
                '3D Style' => 'btn-3d',
                '3D Style2' => 'btn-3d2',

            ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),  
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Button Size", 'laboom'),
            'param_name' => 'button_size',
            'value' => array(
                'Default' => '',
                'Large' => 'btn-lg',
                'X-Large' => 'btn-xlg',
                'Medium' => 'btn-md',
                'Medium2' => 'btn-md2',
                'Normal' => 'btn-normal',
                'Small' => 'btn-sm',


            ),
            'description' => esc_html__( 'Do not apply for Slide Icon type', 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__("Button Shape", 'laboom'),
            'param_name' => 'button_shape',
            'value' => array(
                'Default' => '',
                'Square' => 'btn-square',
                'Outline' => 'btn-outline',
                'Outline Rounded' => 'btn-outline-rounded',
                'Rounded' => 'btn-rounded',

            ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__("Button Hover Effect", 'laboom'),
            'param_name' => 'button_hover',
            'value' => array(
                'Default' => '',
                'Fill from top' => 'btn-fill-from-top',
                'Expand - Horizontal' => 'btn-expand-horizontal',
                'Fill From Right' => 'btn-fill-from-right',
                'Expand - Vertical' => 'btn-expand-vertical',
                'Fill From Left' => 'btn-fill-from-left',
                'Expand - Diagonal' => 'btn-expand-diagonal',
                'Fill From Bottom' => 'btn-fill-from-bottom',
            ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__("Background Color", 'laboom'),
            'param_name' => 'button_color',
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__("Button Color", 'laboom'),
            'param_name' => 'button_text_color',
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__("Button Border Color", 'laboom'),
            'param_name' => 'button_border_color',
            "group" => esc_html__("Button Settings", 'laboom'),
        ),
        array(
            "type" => "textfield",
            "heading" => __ ( "Icon class custom", 'laboom' ),
            "param_name" => "icon_custom",
            "group" => esc_html__("Button Settings", 'laboom'),
        ),

        array(
            "type" => "textfield",
            "heading" => __ ( "Extra class name", 'laboom' ),
            "param_name" => "el_class",
            "description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'laboom' ),
            "group" => esc_html__("Button Settings", 'laboom'),
        ),

    )
));

class WPBakeryShortCode_cms_button extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>