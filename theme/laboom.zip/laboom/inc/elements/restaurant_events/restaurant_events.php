<?php

vc_map(array(
    "name" => 'Restaurant Events',
    "base" => "fr_events",
    "icon" => "cs_icon_for_vc",
    "category" => esc_html__('CmsSuperheroes Shortcodes', 'laboom'),
));

class WPBakeryShortCode_cms_restaurant_event extends CmsShortCode
{
    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}
