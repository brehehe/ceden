<?php
vc_map(array(
    "name" => 'CMS Process',
    "base" => "cms_process",
    "icon" => "cs_icon_for_vc",
    "category" => esc_html__('CmsSuperheroes Shortcodes', 'laboom'),
    "params" => array(
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style", 'laboom'),
            "param_name" => "process_style",
            "value" => array(
                "Style1" => "style1",
                "Style2" => "style2",
            ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title", 'laboom'),
            "param_name" => "process_title1",
            "group" => esc_html__("Item 1", 'laboom'),
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__("Description", 'laboom'),
            "param_name" => "process_description1",
            "group" => esc_html__("Item 1", 'laboom'),

        ),
        array(
            "type" => "attach_images",
            "heading" => esc_html__("Item 1 Images",'laboom'),
            "param_name" => "image_item1",
            "group" => esc_html__("Item 1", 'laboom'),
            "dependency" => array(
                "element"=>"cms_template",
                "value"=>array(
                    "cms_process.php",
                    "cms_process--layout2.php",
                )
            ),

        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title", 'laboom'),
            "param_name" => "process_title2",
            "group" => esc_html__("Item 2", 'laboom'),
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__("Description", 'laboom'),
            "param_name" => "process_description2",
            "group" => esc_html__("Item 2", 'laboom'),

        ),
        array(
            "type" => "attach_images",
            "heading" => esc_html__("Item 2 Images",'laboom'),
            "param_name" => "image_item2",
            "group" => esc_html__("Item 2", 'laboom'),
            "dependency" => array(
                "element"=>"cms_template",
                "value"=>array(
                    "cms_process.php",
                    "cms_process--layout2.php",
                )
            ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title", 'laboom'),
            "param_name" => "process_title3",
            "group" => esc_html__("Item 3", 'laboom'),
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__("Description", 'laboom'),
            "param_name" => "process_description3",
            "group" => esc_html__("Item 3", 'laboom'),

        ),
        array(
            "type" => "attach_images",
            "heading" => esc_html__("Item 3 Images",'laboom'),
            "param_name" => "image_item3",
            "group" => esc_html__("Item 3", 'laboom'),
            "dependency" => array(
                "element"=>"cms_template",
                "value"=>array(
                    "cms_process.php",
                    "cms_process--layout2.php",
                )
            ),

        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title", 'laboom'),
            "param_name" => "process_title4",
            "group" => esc_html__("Item 4", 'laboom'),
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__("Description", 'laboom'),
            "param_name" => "process_description4",
            "group" => esc_html__("Item 4", 'laboom'),

        ),
        array(
            "type" => "attach_images",
            "heading" => esc_html__("Item 4 Images",'laboom'),
            "param_name" => "image_item4",
            "group" => esc_html__("Item 4", 'laboom'),
            "dependency" => array(
                "element"=>"cms_template",
                "value"=>array(
                    "cms_process.php",
                    "cms_process--layout2.php",
                )
            ),

        ),

        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            "shortcode" => "cms_process",
            "heading" => esc_html__("Select Template",'laboom'),
            "admin_label" => true,
            "group" => esc_html__("Template", 'laboom'),
        ),
    )
));

class WPBakeryShortCode_cms_process extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>