<?php
if (!function_exists('fr_get_tax_by')) {
    return;
}
function laboom_shortcode_menu()
{
    $menus_type=fr_get_categories();
        $menutype = array();

            foreach ($menus_type as $menu_type) {
                $menutype[$menu_type['name']] = $menu_type['slug'];
            }
        return $menutype;

}
function laboom_shortcode_menu_default()
{
    $grid_menu_options = laboom_shortcode_menu();
    if(empty($grid_menu_options))
        return 'none';
    $grid_menu_option_keys = array_keys($grid_menu_options);
    $grid_menu_options_default = $grid_menu_options[$grid_menu_option_keys[0]];
    return $grid_menu_options_default;
}
vc_map(array(
    "name" => 'Restaurant Menu',
    "base" => "cms_restaurant_menu",
    "icon" => "cs_icon_for_vc",
    "category" => esc_html__('CmsSuperheroes Shortcodes', 'laboom'),
    "params" => array(
        array(
            'type' => 'dropdown',
            'heading' => esc_html__("Choose Menus Type", 'laboom'),
            'param_name' => 'choose_menu',
            'value' => laboom_shortcode_menu(),
        ),
        array(
            "type" => "textfield",
            "heading" => __ ( 'Number menu', 'laboom' ),
            "param_name" => "number_menu",
        ),
        array(
            "type" => "vc_link",
            "class" => "",
            "heading" => esc_html__("Link full page", 'laboom'),
            "param_name" => "link_button",
            "value" => '',
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Filter Style", 'laboom'),
            "param_name" => "filter_style",
            "value" => array(
                "Style1" => "style1",
                "Style2" => "style2",
                "Style3" => "style3",
                "Style4" => "style4",
            ),
            "group" => esc_html__("Template", 'laboom'),
            "template" => array(
                "cms_restaurant_menu--layout2.php",
            ),

        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Content Color', 'laboom' ),
            'param_name' => 'menu_desc_color',
            'description' => '',
            "group" => esc_html__("Template", 'laboom'),
            "template" => array(
                "cms_restaurant_menu--layout2.php",
            ),


        ),


        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            "shortcode" => "cms_restaurant_menu",
            "heading" => esc_html__("Shortcode Template",'laboom'),
            "admin_label" => true,
            "group" => esc_html__("Template", 'laboom'),
        ),
    )
));

class WPBakeryShortCode_cms_restaurant_menu extends CmsShortCode
{
    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
    protected function loadTemplate($atts, $content = null)
    {
        wp_enqueue_script('cms-shuffle', get_template_directory_uri() . '/assets/js/jquery.shuffle.cms.js', array('jquery-shuffle'));
        $output = '';
        $cms_template = isset($atts['cms_template']) ? $atts['cms_template'] : $this->shortcode . '.php';
        $files = $this->findShortcodeTemplates();
        if ($cms_template && isset($files[$cms_template])) {
            $this->setTemplate($files[$cms_template]->uri);
        } else {
            $this->findShortcodeTemplate();
        }
        if ($this->html_template) {
            $public_atts = $atts;
            if(isset($public_atts['cms_template']) && count($template_name_exp = explode('--',$public_atts['cms_template'])) > 1)
                $public_atts['cms_template'] = str_replace('.php','',$template_name_exp[1]);
            else
                unset($public_atts['cms_template']);
            ob_start();
            ?>
            <div class="cms_restaurant_menu-raw-element" data-atts="<?php echo esc_attr(json_encode($public_atts)) ?>">
                <?php laboom_shortcode_loading_element() ?>
            </div>
            <?php
            //include($this->html_template);
            $output = ob_get_clean();
        } else {
            trigger_error(sprintf(__('Template file is missing for `%s` shortcode. Make sure you have `%s` file in your theme folder.', 'js_composer'), $this->shortcode, 'wp-content/themes/[ your_theme ]/vc_templates/' . $this->shortcode . '.php'));
        }
        wp_reset_postdata();
        wp_reset_query();
        return apply_filters('vc_shortcode_content_filter_after', $output, $this->shortcode);
    }
}
add_action('wp_ajax_cms_restaurant_menu_get_content', 'laboom_cms_restaurant_menu_get_content');
add_action('wp_ajax_nopriv_cms_restaurant_menu_get_content', 'laboom_cms_restaurant_menu_get_content');
function laboom_cms_restaurant_menu_get_content()
{
    $template = "cms_restaurant_menu".(isset($_POST['data']['cms_template']) ? '--'.$_POST['data']['cms_template'] : '').".php";
    $atts = $_POST['data'];
    $atts  = wp_parse_args($atts,array(
        'choose_menu'=>laboom_shortcode_menu_default(),
        'carousel-restaurant-style'=>'style1'
    ));
    include get_template_directory() . '/vc_templates/'.$template;
    exit();
}
