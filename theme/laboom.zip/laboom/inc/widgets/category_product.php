<?php
add_action('widgets_init', 'cs_category_product_widgets');
global $opt_taxonomy_options;

function cs_category_product_widgets() {
    register_widget('CS_Category_Product_Woocomerce');
}

class CS_Category_Product_Woocomerce extends WP_Widget {

    function __construct() {
        parent::__construct(
                'cs_category_product', esc_html__('Category Product','laboom'), array('description' => esc_html__('Category Product Widget.', 'laboom'),)
        );
    }

    function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        echo '<aside class="cms-category-product">';
        if($title) {
            echo balanceTags($before_title.$title.$after_title);
        }
        $extra_class = !empty($instance['extra_class']) ? $instance['extra_class'] : "";

        // no 'class' attribute - add one with the value of width
        if( strpos($before_widget, 'class') === false ) {
            $before_widget = str_replace('>', 'class="'. $extra_class . '"', $before_widget);
        }
        // there is 'class' attribute - append width value to it
        else {
            $before_widget = str_replace('class="', 'class="'. $extra_class . ' ', $before_widget);
        }
        ?>

            <div class="cms-category-product-inner">
                <ul class="cms-category-product-wrapper">
                    <li class="all-product"><?php echo esc_html__('All','laboom');?>
                        <span class="number-product">
                                (<?php echo wp_count_posts('product')->publish; ?>)
                        </span>
                    </li>
                    <?php $_categories = get_terms('product_cat'); ?>

                    <?php if($_categories): foreach ($_categories as $_cat): ?>

                        <li>
                            <a href="<?php echo get_term_link( $_cat->slug, $_cat->taxonomy ); ?>">
                                <?php echo esc_html($_cat->name); ?>
                                <span class="number-courses">(<?php echo esc_attr($_cat->count);?>)</span>
                            </a>

                        </li>

                    <?php endforeach; endif; ?>

                </ul>
            </div>

            <?php
        echo '</aside>';
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['extra_class'] = $new_instance['extra_class'];

        return $instance;
    }

    function form($instance) {
        $title = isset($instance['title']) ? esc_attr($instance['title']) : '';?>
        <p>
            <label for="<?php echo ''.$this->get_field_id('title'); ?>"><?php esc_html_e( 'Title:', 'laboom' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo ''.$this->get_field_id('extra_class'); ?>">Extra Class:</label>
            <input class="widefat" id="<?php echo ''.$this->get_field_id('extra_class'); ?>" name="<?php echo esc_attr($this->get_field_name('extra_class')); ?>" value="<?php if(isset($instance['extra_class'])){echo esc_attr($instance['extra_class']);} ?>" />
        </p>
        <?php
    }
}
?>