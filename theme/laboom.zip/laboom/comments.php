<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">
	<?php if ( have_comments() ) : ?>

		<div class="comment-list-wrap box-blog">
			<h2 class="comments-title">
				<?php comments_number(__('Comments', "laboom"),__('1 Comment', "laboom"),__('% Comments', "laboom")); ?>
			</h2>

			<?php laboom_comment_nav(); ?>

			<ol class="comment-list">
				<?php
				wp_list_comments( array(
					'avatar_size' => 100,
					'style'       => 'ol',
					'short_ping'  => true,
					'format' => 'html5'
				) );
				?>
			</ol><!-- .comment-list -->

			<?php laboom_comment_nav(); ?>
		</div>

	<?php endif; // have_comments() ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'laboom' ); ?></p>
	<?php endif; ?>

	<div class="comment-form-wrap">
		<?php
		$commenter = wp_get_current_commenter();
		$req = get_option( 'require_name__mail' );
		$aria_req = ( $req ? " aria-required='true'" : '' );
		$args = array(
			'id_form'           => 'commentform',
			'id_submit'         => 'submit',
			'title_reply'       => '<span>'.esc_html__( 'Leave a Reply','laboom').'</span>',
			'title_reply_to'    => esc_html__( 'Leave a comment to ','laboom') . '%s',
			'cancel_reply_link' => esc_html__( 'Cancel Reply','laboom'),
			'label_submit'      => esc_html__( 'SEND COMMENT','laboom'),
			'comment_notes_before' => '',
			'fields' => apply_filters( 'comment_form_default_fields', array(

					'author' =>
						'<div class="comment-form-author col-xs-12 col-sm-12 col-md-6 col-lg-6">'.
						'<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
						'" size="30"' . $aria_req . ' placeholder="'.esc_html__('Name*', 'laboom').'"/></div>',

					'email' =>
						'<div class="comment-form-email col-xs-12 col-sm-12 col-md-6 col-lg-6">'.
						'<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
						'" size="30"' . $aria_req . ' placeholder="'.esc_html__('Email*', 'laboom').'"/></div>',

				)
			),
			'comment_field' =>  '<div class="comment-form-comment col-xs-12 col-sm-12 col-md-12 col-lg-12"><textarea id="comment" name="comment" cols="45" rows="8" placeholder="'.esc_html__('Comment*', 'laboom').'" aria-required="true">' .
				'</textarea></div>',
		);
		comment_form($args);
		?>
	</div>



</div><!-- .comments-area -->
