<?php
/**fixed
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<li <?php post_class('product-list'); ?>>
	<div class="product-inner  clearfix">
		<div class="sameheight product-thumb">
			<a href="<?php the_permalink(); ?>">
				<?php wc_get_template( 'loop/sale-flash.php' ); ?>
				<?php echo woocommerce_get_product_thumbnail('laboom_team400X400'); ?>
			</a>
		</div>
		<div class="product-content sameheight">
			<h3 class="cms-grid-product-title">
				<a href="<?php the_permalink(); ?>"><?php the_title();?></a>
			</h3>
			<div class="product-desc">
				<?php
				echo  apply_filters( 'woocommerce_short_description', $post->post_excerpt );

				?>
			</div>
			<?php /**
			/**
			 * woocommerce_after_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_template_loop_rating - 5
			 * @hooked woocommerce_template_loop_price - 10
			 */
			do_action( 'woocommerce_after_shop_loop_item_title' );

			/**
			 * woocommerce_after_shop_loop_item hook.
			 *
			 * @hooked woocommerce_template_loop_product_link_close - 5
			 * @hooked woocommerce_template_loop_add_to_cart - 10
			 */
			?>
			<div class="bottom-product">
			<?php
			do_action( 'woocommerce_after_shop_loop_item' );

			?>

			</div>
		</div>
	</div>

</li>
