<?php
/* custom billing fields */
function wp_barberia_override_checkout_fields( $fields ) {
	$fields['billing']['billing_first_name']['placeholder'] = esc_html__('First name *','laboom');
	$fields['billing']['billing_last_name']['placeholder'] = esc_html__('Last name *','laboom');
	$fields['billing']['billing_company']['placeholder'] = esc_html__('Company','laboom');
	$fields['billing']['billing_email']['placeholder'] = esc_html__('Email address *','laboom');
	$fields['billing']['billing_phone']['placeholder'] = esc_html__('Phone number *','laboom');
	$fields['billing']['billing_address_1']['placeholder'] = esc_html__('Address *','laboom');
	$fields['billing']['billing_postcode']['placeholder'] = esc_html__('Postal code','laboom');
	$fields['billing']['billing_city']['placeholder'] = esc_html__('City *','laboom');
	
	$fields['shipping']['shipping_first_name']['placeholder'] = esc_html__('First name *','laboom');
	$fields['shipping']['shipping_last_name']['placeholder'] = esc_html__('Last name *','laboom');
	$fields['shipping']['shipping_company']['placeholder'] = esc_html__('Company','laboom');
	$fields['shipping']['shipping_address_1']['placeholder'] = esc_html__('Address *','laboom');
	$fields['shipping']['shipping_postcode']['placeholder'] = esc_html__('Postal code','laboom');
	$fields['shipping']['shipping_city']['placeholder'] = esc_html__('City *','laboom');

	return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'wp_barberia_override_checkout_fields' );

 