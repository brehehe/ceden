<?php
/*
Name: Feed style2
Version: 1.0.0
*/
?>

<?php foreach ($twitter as $index => $item): ?>

	<?php
	/* open row. */
	if ($row_index == 0 ): ?><div class="news-twitter-item"><?php endif; ?>

	<div class="item-content template-layout2">
		<i class="fa fa-twitter"></i>
		<div class="content-right">
		<a href="http://twitter.com/<?php echo esc_attr($item['user']['screen_name']); ?>/statuses/<?php echo esc_attr($item['id_str']); ?>"><?php echo esc_html($item['user']['name']);?></a>
		 - <?php
		$tweet_content = $item['text'];
		$tweet_content = preg_replace('/http:\/\/([a-z0-9_\.\-\+\&\!\#\~\/\,]+)/i', '&nbsp;<a href="http://$1" target="_blank">http://$1</a>&nbsp;', $tweet_content);
		$tweet_content = preg_replace('/@([a-z0-9_]+)/i', '&nbsp;<a href="http://twitter.com/$1" target="_blank">@$1</a>&nbsp;', $tweet_content);
		echo wp_kses_post($tweet_content); ?>
		<small class="date"><?php
			$date = new DateTime($item['user']['created_at']);
			echo esc_html($date->format('d F Y'));

			?></small>
		</div>
		</div>

	<?php $row_index++; ?>

	<?php
	/* close row. */
	if ($row_index == $row || $items_count == $index ): $row_index = 0; ?></div><?php endif; ?>

<?php endforeach; ?>