<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

<div id="primary" class="page404">
	<main id="main" class="site-main text-center" role="main">
		<div class="cms-content404">
			<div class="container">
				<section class="error-404 not-found">
					<h1 class="page-title"><?php esc_html_e( '404', 'laboom' ); ?></h1>
					<div class="page-content">
						<h3><?php  echo esc_html__( 'PAGE NOT FOUND', 'laboom' ); ?></h3>
						<p><?php  echo esc_html__( 'Sorry, We could not find the page you are looking for. ', 'laboom' ); ?></p>
						<p><?php  echo esc_html__( ' Try returning to the', 'laboom' ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'homepage', 'laboom' ); ?></a></p>

					</div><!-- .page-content -->
				</section><!-- .error-404 -->
			</div>
		</div>

	</main><!-- .site-main -->
</div><!-- .content-area -->

<?php get_footer(); ?>


