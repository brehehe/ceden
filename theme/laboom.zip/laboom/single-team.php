<?php
/**
 * The Template for displaying all single posts
 *
 * @package CMSSuperHeroes
 * @subpackage CMS Theme
 * @since 1.0.0
 */
/* get side-bar position. */
$curent_id=0;
get_header(); ?>

<div id="primary" class="container single-post-blog single-team">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <main id="main" class="site-main" role="main">

                <?php
                // Start the loop.
                while ( have_posts() ) : the_post();$curent_id=get_the_ID();

                    // Include the single content template.
                    get_template_part( 'single-templates/single-team/content', get_post_format() );
                    // If comments are open or we have at least one comment, load up the comment template.

                    // End the loop.
                endwhile;
                ?>

            </main>
        </div><!-- #main -->
    </div>
</div><!-- #primary -->

<?php get_footer(); ?>