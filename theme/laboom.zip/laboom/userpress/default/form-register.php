<?php
/**
 * The template for displaying register form.
 *
 * Override this template by copying it to yourtheme/userpress/layoutname/form-register.php
 *
 * @author 		UserPress
 * @package 	UserPress/Templates
 * @version     1.0.0
 */
if (! defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}
?>

<div class="user-press user-press-register" style="background:url(<?php echo esc_url(get_option( 'user_press_bg_img', '')); ?>) no-repeat center">
	<div class="register-form" style="background:<?php echo esc_attr(get_option( 'user_press_bg_color', '')) ;?>">
		<div class="fields-content">
			<div class="field-group">
				<input id="res_user" type="text" class="input" data-validate="<?php esc_html_e('Required Field', 'laboom'); ?>" data-user-length="<?php esc_html_e('Username too short. At least 4 characters is required.', 'laboom'); ?>" data-special-char="<?php esc_html_e("The value of text field can't contain any of the following characters: \ / : * ? \" < > space", 'laboom'); ?>" placeholder="<?php esc_html_e('Username', 'laboom'); ?>">
			</div>
			<div class="field-group">
				<input id="res_pass1" type="password" class="input" data-type="password" data-validate="<?php esc_html_e('Required Field', 'laboom'); ?>" data-pass-length="<?php esc_html_e( 'Password length must be greater than 5.', 'laboom' ); ?>" placeholder="<?php esc_html_e('Password', 'laboom'); ?>">
			</div>
			<div class="field-group">
				<input id="res_pass2" type="password" class="input" data-type="password" data-validate="<?php esc_html_e('Required Field', 'laboom'); ?>" data-pass-confirm="<?php esc_html_e('Your password and confirmation password do not match.', 'laboom'); ?>" placeholder="<?php esc_html_e('Repeat Password', 'laboom'); ?>">
			</div>
			<div class="field-group">
				<input id="res_email" type="text" class="input" data-validate="<?php esc_html_e('Required Field', 'laboom'); ?>"  data-email-format="<?php esc_html_e('The Email address is incorrect!', 'laboom'); ?>" placeholder="<?php esc_html_e('Email', 'laboom'); ?>">
			</div>
			<div class="field-group">
				<button type="button" class="button btn btn-up-register"><?php esc_html_e('Register now', 'laboom');?></button>
			</div>
		</div>
	</div>
</div>