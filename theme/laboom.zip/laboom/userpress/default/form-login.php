<?php
/**
 * The template for displaying login form.
 *
 * Override this template by copying it to yourtheme/userpress/layoutname/form-login.php
 *
 * @author 		UserPress
 * @package 	UserPress/Templates
 * @version     1.0.0
 */
global $user_press;
if (! defined ( 'ABSPATH' )) {
	exit (); // Exit if accessed directly
}
//$user_press['background']
$uniqid_id = uniqid('register-modal-');

?>
<div class="user-press-login">
	<div class="login-form" style="background:<?php echo esc_attr(get_option ( 'user_press_bg_color', '' )) ;?>" >
		<div class="login-content">
			<div class="login-group login-group-icon">
				<input type="text" class="input user_name" data-validate="<?php esc_html_e('Required Field', 'laboom'); ?>" placeholder="<?php esc_html_e('Username', 'laboom'); ?>">
			</div>
			<div class="login-group password-group login-group-icon">
				<input type="password" class="input password" data-type="password" data-validate="<?php esc_html_e('Required Field', 'laboom'); ?>" placeholder="<?php esc_html_e('Password', 'laboom'); ?>">
			</div>
			<div class="login-remember">
				<div class="remember-wrap">
					<input id="check" type="checkbox" class="remember-check check" checked>
					<label class="remember" for="check"><?php esc_html_e('Remember me', 'wp-diplomia');?></label>
				</div>

				<?php if(!is_user_logged_in()): ?>
					<div class="forgot-pass"><a class="forget" href="<?php echo wp_lostpassword_url(get_permalink()); ?>"><?php esc_html_e('Forgot Your Password?', 'laboom') ?></a></div>
				<?php endif; ?>
			</div>
			<div class="login-group">
				<button type="button" class="btn button-login progress-button" data-style="fill">
					<span class="content"><?php esc_html_e('Login', 'laboom');?></span>
					<span class="progress"><span class="progress-inner notransition" style="width: 50%; opacity: 1;"></span></span>
				</button>

			</div>

			<!-- Button trigger modal -->

		</div>
		
	</div>
</div>
