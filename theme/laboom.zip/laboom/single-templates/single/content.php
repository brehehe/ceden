<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @since 1.0.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="post-thumbnail">
		<?php the_post_thumbnail('laboom_blog1140X501');
		laboom_post_date_detail();
		?>
	</div>
	<div class="content-right">
		<div class="content-main">
			<div class="entry-meta">

				<?php laboom_post_detail(); ?>

			</div><!-- .entry-meta -->
				<header class="entry-header">

					<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>


				</header><!-- .entry-header -->


				<div class="entry-content">
					<?php
					/* translators: %s: Name of current post */
					the_content( sprintf(
						__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'laboom' ),
						the_title( '<span class="screen-reader-text">', '</span>', false )
					) );

					wp_link_pages( array(
						'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'laboom' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
					) );
					?>
				</div><!-- .entry-content -->

		</div>


	</div>
	<?php laboom_post_wrap_bottom();?>
	<div class="single-post-nav clearfix">
		<?php laboom_post_nav();?>
	</div>
</article><!-- #post-## -->



