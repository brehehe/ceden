<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package CMSSuperHeroes
 * @subpackage CMS Theme
 * @since 1.0.0
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="post-thumbnail">
			<?php laboom_post_gallery(); ?>
			<?php laboom_date_detaile();?>
		</div>
	<div class="content-right <?php if(!has_post_thumbnail()){echo 'no-thumb';}?>">
		<div class="content-main">
			<header class="entry-header">
				<div class="entry-meta">

					<?php laboom_archive_detail(); ?>

				</div><!-- .entry-meta -->
				<h3 class="entry-title">
					<a href="<?php the_permalink(); ?>">
						<?php
						if(is_sticky()){
						echo "<i class='fa fa-thumb-tack'></i>";
						}
						?>
						<?php echo get_the_title(); ?>
					</a>
				</h3>
				<?php edit_post_link('<i class="fa fa-pencil-square-o" aria-hidden="true"></i>'); ?>


			</header><!-- .entry-header -->


			<div class="entry-content">
				<?php
				/* translators: %s: Name of current post */
				echo wp_trim_words(strip_tags(strip_shortcodes(get_the_content())),20,'.');

				wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'laboom' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				) );
				?>
			</div><!-- .entry-content -->
			<a class="more" href="<?php the_permalink(); ?>"><span><?php esc_html_e('Read More', 'laboom') ?></span> <i class="lnr lnr-arrow-right"></i></a>

		</div>

	</div>

</article><!-- #post-## -->
