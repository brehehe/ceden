<?php
	$params = array(
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Row", 'laboom'),
            "param_name" => "number_row",
            "value" => array(
                "Row 1" => "1",
                "Row 2" => "2",
            ),
            "template" => array(
                "cms_carousel--layout-client.php"
            ),
            "group" => esc_html__("Template", 'laboom'),
        ),

        array(
            "type" => "dropdown",
            "heading" => esc_html__("Testimonial Style", 'laboom'),
            "param_name" => "test_style",
            "value" => array(
                "Style1" => "style1",
                "Style2" => "style2"
            ),
            "template" => array(
                "cms_carousel--layout-testimonial2.php",
            ),
            "group" => esc_html__("Template", 'laboom'),
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style", 'laboom'),
            "param_name" => "blog2_style",
            "value" => array(
                "Style1" => "style1",
                "Style2" => "style2"
            ),
            "template" => array(
                "cms_carousel--layout-blog2.php",
            ),
            "group" => esc_html__("Template", 'laboom'),
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style", 'laboom'),
            "param_name" => "blog_default_style",
            "value" => array(
                "Style1" => "style1",
                "Style2" => "style2"
            ),
            "template" => array(
                "cms_carousel.php",
            ),
            "group" => esc_html__("Template", 'laboom'),
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Team Style", 'laboom'),
            "param_name" => "team_style",
            "value" => array(
                "Style1" => "style1",
                "Style2" => "style2",
                "Style3" => "style3",
                "Style4" => "style4"
            ),
            "template" => array(
                "cms_carousel--layout-team1.php",
            ),
            "group" => esc_html__("Template", 'laboom'),
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Content Color",'laboom'),
            "param_name" => "testimonial_content_color",
            "value" => "",
            "template" => array(
                "cms_carousel--layout-testimonial2.php",
            ),
            "group" => esc_html__("Template", 'laboom'),

        ),

        
	);

    vc_remove_param('cms_carousel','l_icon_type');
    vc_remove_param('cms_carousel','l_icon_fontawesome');
    vc_remove_param('cms_carousel','l_icon_openiconic');
    vc_remove_param('cms_carousel','l_icon_typicons');
    vc_remove_param('cms_carousel','l_icon_entypo');
    vc_remove_param('cms_carousel','l_icon_glyphicons');
    vc_remove_param('cms_carousel','l_icon_rticon');
    vc_remove_param('cms_carousel','l_icon_pe7stroke');
    vc_remove_param('cms_carousel','l_icon_pixelicons');
    vc_remove_param('cms_carousel','l_icon_linecons');

    vc_remove_param('cms_carousel','r_icon_type');
    vc_remove_param('cms_carousel','r_icon_type');
    vc_remove_param('cms_carousel','r_icon_fontawesome');
    vc_remove_param('cms_carousel','r_icon_openiconic');
    vc_remove_param('cms_carousel','r_icon_typicons');
    vc_remove_param('cms_carousel','r_icon_entypo');
    vc_remove_param('cms_carousel','r_icon_glyphicons');
    vc_remove_param('cms_carousel','r_icon_rticon');
    vc_remove_param('cms_carousel','r_icon_pe7stroke');
    vc_remove_param('cms_carousel','r_icon_pixelicons');
    vc_remove_param('cms_carousel','r_icon_linecons');
    
	vc_remove_param('cms_carousel','cms_template');
	$cms_template_attribute = array(
		'type' => 'cms_template_img',
	    'param_name' => 'cms_template',
	    "shortcode" => "cms_carousel",
	    "heading" => esc_html__("Shortcode Template",'laboom'),
	    "admin_label" => true,
	    "group" => esc_html__("Template", 'laboom'),
		);
	vc_add_param('cms_carousel',$cms_template_attribute);
?>