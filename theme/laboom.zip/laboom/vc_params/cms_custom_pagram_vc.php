<?php
/*
 * Contact form-7
 */
vc_add_param("vc_row", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => __("CMS Custom Style", 'laboom'),
    "param_name" => "el_class",
    "value" => array(
        'None' => 'no-overlay',
        'Background Left Bottom' => 'bg-left-bottom',
        'Background Left Top' => 'bg-left-top',
        'Background Center Top' => 'bg-center-top',
        'Background Right Top' => 'bg-right-top',
        'Background Right Bottom' => 'bg-right-bottom',
        'Half of left Background' => 'half-left-background',
        'Half of right Background' => 'half-right-background',
    ),
    "description" => ""
));
$cms_template_attribute = array(
    "type" => "dropdown",
    "class" => "",
    "heading" => __("Style", 'laboom'),
    "param_name" => "tab_style",
    "value" => array(
        'Style Default' => 'style-default',
        'Style 1' => 'style1',
    ),
    "description" => ""
);
vc_add_param('vc_bootstrap_tabs',$cms_template_attribute);