<?php
	$params = array(
		array(
			"type" => "dropdown",
			"heading" => esc_html__("Filter Style", 'laboom'),
			"param_name" => "filter_style",
			"value" => array(
				"Style1" => "style1",
				"Style2" => "style2"
			),
			"template" => array(
				"cms_grid--layout-gallery.php",
			),
			"group" => esc_html__("Template", 'laboom'),
		),
		array(
			"type" => "dropdown",
			"heading" => esc_html__("Show load more", 'laboom'),
			"param_name" => "show_load_more",
			"value" => array(
				"Yes" => "yes",
				"NO" => "no"
			),
			"template" => array(
				"cms_grid--layout-gallery.php",
			),
			"group" => esc_html__("Template", 'laboom'),
		),
		array(
			"type" => "dropdown",
			"heading" => esc_html__("No Padding Item", 'laboom'),
			"param_name" => "no_padding_item",
			"value" => array(
				"No" => "no",
				"Yes" => "yes"
			),
			"template" => array(
				"cms_grid--layout-gallery.php",
			),
			"group" => esc_html__("Template", 'laboom'),
		),
	);
	vc_remove_param('cms_grid','cms_template');
	$cms_template_attribute = array(
		'type' => 'cms_template_img',
	    'param_name' => 'cms_template',
	    "shortcode" => "cms_grid",
	    "heading" => esc_html__("Shortcode Template",'laboom'),
	    "admin_label" => true,
	    "group" => esc_html__("Template", 'laboom'),
		);
	vc_add_param('cms_grid',$cms_template_attribute);
?>