<?php
/**
 * Add column params
 * 
 * @author Fox
 * @since 1.0.0
 */

     vc_add_param("vc_column_inner", array(
        "type" => "colorpicker",
        "class" => "",
        "heading" => esc_html__('Font Color', 'laboom'),
        "param_name" => "font_color",
        "description" => ''
    ));
    vc_add_param("vc_column", array(
        "type" => "dropdown",
        "class" => "",
        "heading" => esc_html__("Animation", 'laboom'),
        "admin_label" => true,
        "param_name" => "animation",
        "value" => array(
            "None" => "",
            "FadeIn" => "rda_fadeIn",
            "FadeInDown" => "rda_fadeInDown",
            "FadeInUp" => "rda_fadeInUp",
            "FadeInLeft" => "rda_fadeInLeft",
            "FadeInRight" => "rda_fadeInRight",
            "BounceIn" => "rda_bounceIn",
            "BounceInDown" => "rda_bounceInDown",
            "BounceInUp" => "rda_bounceInUp",
            "BounceInLeft" => "rda_bounceInLeft",
            "BounceInRight" => "rda_bounceInRight",
            "ZoomIn" => "rda_zoomIn",
            "FlipInX" => "rda_flipInX",
            "FlipInY" => "rda_flipInY",
            "Bounce" => "rda_bounce",
            "Flash" => "rda_flash",
            "Shake" => "rda_shake",
            "Pulse" => "rda_pulse",
            "Swing" => "rda_swing",
            "RubberBand" => "rda_rubberBand",
            "Wobble" => "rda_wobble",
            "Tada" => "rda_tada"
        )
    ));
    vc_add_param("vc_column_inner", array(
        "type" => "dropdown",
        "class" => "",
        "heading" => esc_html__("Animation", 'laboom'),
        "admin_label" => true,
        "param_name" => "animation",
        "value" => array(
            "None" => "",
            "FadeIn" => "rda_fadeIn",
            "FadeInDown" => "rda_fadeInDown",
            "FadeInUp" => "rda_fadeInUp",
            "FadeInLeft" => "rda_fadeInLeft",
            "FadeInRight" => "rda_fadeInRight",
            "BounceIn" => "rda_bounceIn",
            "BounceInDown" => "rda_bounceInDown",
            "BounceInUp" => "rda_bounceInUp",
            "BounceInLeft" => "rda_bounceInLeft",
            "BounceInRight" => "rda_bounceInRight",
            "ZoomIn" => "rda_zoomIn",
            "FlipInX" => "rda_flipInX",
            "FlipInY" => "rda_flipInY",
            "Bounce" => "rda_bounce",
            "Flash" => "rda_flash",
            "Shake" => "rda_shake",
            "Pulse" => "rda_pulse",
            "Swing" => "rda_swing",
            "RubberBand" => "rda_rubberBand",
            "Wobble" => "rda_wobble",
            "Tada" => "rda_tada"
        )
    ));
    vc_add_param("vc_column", array(
        "type" => "dropdown",
        "class" => "",
        "heading" => esc_html__("Text Align", 'laboom'),
        "admin_label" => true,
        "param_name" => "text_align",
        "value" => array(
            "None" => "align-none",
            "Left" => "left",
            "Center" => "center",
            "Right" => "right",
        )
    ));
    vc_add_param("vc_column_inner", array(
        "type" => "dropdown",
        "class" => "",
        "heading" => esc_html__("Text Align", 'laboom'),
        "admin_label" => true,
        "param_name" => "text_align",
        "value" => array(
            "None" => "align-none",
            "Left" => "left",
            "Center" => "center",
            "Right" => "right",
        )
    ));

    vc_add_param('vc_column', array(
        'type' => 'dropdown',
        'heading' => esc_html__("Background Overlay Color", 'laboom'),
        'param_name' => 'column_background_overlay_color',
        'value' => array(
            'No' => '',
            'Yes' => 'yes'
        ),
    ));
vc_add_param("vc_column", array(
    "type" => "colorpicker",
    "class" => "",
    "heading" => esc_html__('Select Color', 'laboom'),
    "param_name" => "column_overlay_color",
    "dependency" => array(
        "element" => "column_background_overlay_color",
        "value" => array(
            "yes"
        )
    ),
    "description" => ''
));
vc_add_param("vc_column", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Blockquote Style", "laboom"),
    "admin_label" => true,
    "param_name" => "blockquote_style",
    "value" => array(
        "None" => "blockquote-none",
        "Style 1" => "blockquote-style1",
        "Style 2" => "blockquote-style2",
        "Style 3" => "blockquote-style3"
    )
));
vc_add_param("vc_column", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Reservation Style", "laboom"),
    "admin_label" => true,
    "param_name" => "reservation_style",
    "value" => array(
        "Style 1" => "reservation-style1",
        "Style 2" => "reservation-style2",
        "Style 3" => "reservation-style3"
    )
));
vc_add_param("vc_column_inner", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Blockquote Style", "laboom"),
    "admin_label" => true,
    "param_name" => "blockquote_style",
    "value" => array(
        "None" => "blockquote-none",
        "Style 1" => "blockquote-style1",
        "Style 2" => "blockquote-style2",
        "Style 3" => "blockquote-style3"
    )
));


vc_add_param("vc_column", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => __("Position", "laboom"),
    "admin_label" => true,
    "param_name" => "position_in_row",
    "value" => array(
        "None" => "position-none",
        "Left" => "position-left",
        "Right" => "position-right",
    )
));
vc_add_param("vc_column", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Position Offset", 'laboom'),
    "admin_label" => true,
    "param_name" => "position_offset",
    "value" => array(
        "None" => "",
        "Offset Left" => "section-offset-left",
        "Offset Right" => "section-offset-right",
    ),
));


