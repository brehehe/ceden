<?php
/**
 * Add row params
 * 
 * @author Fox
 * @since 1.0.0
 */
    vc_add_param('vc_row', array(
        'type' => 'dropdown',
        'heading' => esc_html__("Background Overlay Color", 'laboom'),
        'param_name' => 'background_overlay_color',
        'value' => array(
            'No' => '',
            'Yes' => 'yes'
        ),
        'group' => 'CMS Customs'
    ));
    vc_add_param("vc_row", array(
        "type" => "colorpicker",
        "class" => "",
        "heading" => esc_html__('Select Color', 'laboom'),
        "param_name" => "row_overlay_color",
        'group' => 'CMS Customs',
        "dependency" => array(
            "element" => "background_overlay_color",
            "value" => array(
                "yes"
            )
        ),
        "description" => ''
    ));

    vc_add_param('vc_row_inner', array(
        'type' => 'dropdown',
        'heading' => esc_html__("Background position", 'laboom'),
        'param_name' => 'background_position_row_inner',
        'value' => array(
            ' ' => 'default',
            'Background Right Center' => 'bg-right-center',
            'Background Right Top' => 'bg-right-top',
            'Background Right Bottom' => 'bg-right-bottom',
        ),
        'group' => 'CMS Customs'
    ));
vc_add_param('vc_row_inner', array(
    'type' => 'dropdown',
    'heading' => esc_html__("Background Overlay Color", 'laboom'),
    'param_name' => 'row_inner_background_overlay_color',
    'value' => array(
        'No' => '',
        'Yes' => 'yes'
    ),
    'group' => 'CMS Customs'
));
vc_add_param("vc_row_inner", array(
    "type" => "colorpicker",
    "class" => "",
    "heading" => esc_html__('Select Color', 'laboom'),
    "param_name" => "row_inner_overlay_color",
    'group' => 'CMS Customs',
    "dependency" => array(
        "element" => "row_inner_background_overlay_color",
        "value" => array(
            "yes"
        )
    ),
    "description" => ''
));
    vc_add_param("vc_row", array(
        "type" => "textfield",
        "class" => "",
        "heading" => esc_html__("Arrow Icon Class", 'laboom'),
        "admin_label" => true,
        "param_name" => "custom_responsive",
        'group' => 'CMS Customs',
    ));
vc_add_param("vc_row", array(
    "type" => "colorpicker",
    "class" => "",
    "heading" => esc_html__('Arrow Icon Color', 'laboom'),
    "param_name" => "arrow_icon_color",
    'group' => 'CMS Customs',
));
    vc_add_param("vc_row", array(
        "type" => "colorpicker",
        "class" => "",
        "heading" => esc_html__('Arrow Background', 'laboom'),
        "param_name" => "arrow_background",
        'group' => 'CMS Customs',
    ));
    vc_add_param("vc_row", array(
        "type" => "dropdown",
        "class" => "",
        "heading" => esc_html__("Over follow CSS", 'laboom'),
        "admin_label" => true,
        "param_name" => "custom_over_follow",
        "value" => array(
            "None" => "",
            "Initial" => "over_follow_initial",
            "Initial for only Chrome" => "over_follow_initial-chrome",
        ),
        'group' => 'CMS Customs',
    ));

    vc_add_param("vc_row",array(
        'type' => 'attach_image',
        'heading' => esc_html__( 'Icon Image', 'laboom' ),
        'param_name' => 'custom_row_image',
        'value' => '',
        'description' => esc_html__( 'Select image from media library.', 'laboom' ),
        'group' => 'CMS Customs',
    ));
    vc_add_param('vc_row', array(
        'type' => 'dropdown',
        'heading' => esc_html__("Custom Row Arrow", 'laboom'),
        'param_name' => 'custom_row_image_right',
        'value' => array(
            'Row Default' => 'row-default',
            'Row Arrow' => 'row-arrow',
            'Row Instagram' => 'row-instagram',
        ),
        'group' => 'CMS Customs'
    ));


