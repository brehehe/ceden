<?php
	$params = array(
		array(
			'type' => 'cms_template_img',
		    'param_name' => 'cms_template',
		    "shortcode" => "cms_counter_single",
		    "heading" => esc_html__("Shortcode Template",'laboom'),
		    "admin_label" => true,
		    "group" => esc_html__("Template", 'laboom'),
		),
		array(
			"type" => "colorpicker",
			"heading" => esc_html__("Icon Color",'laboom'),
			"param_name" => "icon_color",
			"value" => "",
			"group" => esc_html__("Template", 'laboom')
		),
		array(
			"type" => "colorpicker",
			"heading" => esc_html__("Digit Color",'laboom'),
			"param_name" => "digit_color",
			"value" => "",
			"group" => esc_html__("Template", 'laboom')
		),
		array(
			"type" => "colorpicker",
			"heading" => esc_html__("Title Color",'laboom'),
			"param_name" => "title_color",
			"value" => "",
			"group" => esc_html__("Template", 'laboom')
		),
		array(
			"type" => "attach_image",
			"heading" => esc_html__("Image Icon",'laboom'),
			"param_name" => "image_icon",
			"group" => esc_html__("Template", 'laboom'),
			"template" => array(
				"cms_counter_single--layout2.php",
				"cms_counter_single--layout3.php"
			),
		),

	);
vc_remove_param( "cms_counter_single", "description" );
vc_remove_param( "cms_counter_single", "title" );
vc_remove_param( "cms_counter_single", "content_align" );
?>