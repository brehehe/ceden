<?php
/**
 * Add row params
 * 
 * @author Fox
 * @since 1.0.0
 */

vc_add_param("vc_pie", array(
    "type" => "colorpicker",
    "class" => "",
    "heading" => __('Title Color', 'laboom'),
    "param_name" => "title_color",
    "description" => ''
));

vc_remove_param("vc_pie", "color");
vc_remove_param("vc_pie", "label_value");
vc_add_param("vc_pie", array(
    'type' => 'colorpicker',
    'heading' => __('Pie color progress', 'laboom'),
    'param_name' => 'color',
    'value' => '#efbd0e', // $pie_colors,
    'description' => __('Select pie chart color.', 'laboom'),
    'admin_label' => true,
    'param_holder_class' => 'vc-colored-dropdown'
));
vc_add_param("vc_pie", array(
    'type' => 'colorpicker',
    'heading' => __('Pie border color', 'laboom'),
    'param_name' => 'pie_border_color',
    'value' => '#bdbdbd',
    'admin_label' => true,
));

