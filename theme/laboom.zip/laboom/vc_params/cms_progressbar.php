<?php
	vc_remove_param('cms_progressbar','cms_template');
	vc_remove_param('cms_progressbar','height');
	vc_remove_param('cms_progressbar','width');
	vc_remove_param('cms_progressbar','mode');
	vc_remove_param('cms_progressbar','border_radius');
	$cms_color_value = array(
		"type" => "colorpicker",
		"heading" => esc_html__("Value color",'laboom'),
		"param_name" => "value_color",
		"value" => "",
		"group" => esc_html__("Template", 'laboom'),
		"template" => array(
			"cms_progressbar.php",
		),
	);
	vc_add_param('cms_progressbar',$cms_color_value);
	$cms_color_value = array(
		"type" => "colorpicker",
		"heading" => esc_html__("Title color",'laboom'),
		"param_name" => "title_color",
		"value" => "",
		"group" => esc_html__("Template", 'laboom'),
		"template" => array(
			"cms_progressbar.php",
		),
	);
	vc_add_param('cms_progressbar',$cms_color_value);
	$cms_template_attribute = array(
		'type' => 'cms_template_img',
	    'param_name' => 'cms_template',
	    "shortcode" => "cms_progressbar",
	    "heading" => esc_html__("Shortcode Template",'laboom'),
	    "admin_label" => true,
	    "group" => esc_html__("Template", 'laboom'),
		);
	vc_add_param('cms_progressbar',$cms_template_attribute);
?>