<?php
	/** Add pamrams **/
	$params = array(
		array(
			"type" => "textfield",
			"heading" => esc_html__("Custom Icon -  Add Class Icon",'laboom'),
			"param_name" => "icon_custom",
			"value" => "",
			"group" => esc_html__("Template", 'laboom'),
		),
		array(
			"type" => "attach_images",
			"heading" => esc_html__("Icon Image",'laboom'),
			"param_name" => "image_icon1",
			"group" => esc_html__("Template", 'laboom'),
			"template" => array(
				"cms_fancybox_single--layout2.php",
			),

		),
		array(
			"type" => "attach_images",
			"heading" => esc_html__("Icon Image Hover",'laboom'),
			"param_name" => "image_icon_hover",
			"group" => esc_html__("Template", 'laboom'),
			"template" => array(
				"cms_fancybox_single--layout2.php",
			),

		),
		array(
			"type" => "colorpicker",
			"heading" => esc_html__("Icon Color",'laboom'),
			"param_name" => "icon_color",
			"value" => "",
			"group" => esc_html__("Template", 'laboom'),
			"template" => array(
				"cms_fancybox_single.php",
			),
		),
		array(
			"type" => "colorpicker",
			"heading" => esc_html__("Content Color",'laboom'),
			"param_name" => "content_color",
			"value" => "",
			"group" => esc_html__("Template", 'laboom'),
			"template" => array(
				"cms_fancybox_single.php",
			),
		),
		array(
			"type" => "colorpicker",
			"heading" => esc_html__("Title Color",'laboom'),
			"param_name" => "title_color",
			"value" => "",
			"group" => esc_html__("Template", 'laboom'),
			"template" => array(
				"cms_fancybox_single.php",
			),
		),
		array(
			'type' => 'cms_template_img',
		    'param_name' => 'cms_template',
		    "shortcode" => "cms_fancybox_single",
		    "heading" => esc_html__("Shortcode Template",'laboom'),
		    "admin_label" => true,
		    "group" => esc_html__("Template", 'laboom'),
		),



	);


	/** Remove pamrams **/
	vc_remove_param( "cms_fancybox_single", "title" );
	vc_remove_param( "cms_fancybox_single", "description" );
	vc_remove_param( "cms_fancybox_single", "content_align" );
	
?>