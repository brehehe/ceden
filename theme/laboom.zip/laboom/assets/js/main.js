jQuery(document).ready(function($) {
	"use strict";
	/* window */
	var window_width, window_height, scroll_top;
	/* admin bar */
	var adminbar = $('#wpadminbar');
	var adminbar_height = 0;
	/* header menu */
	var header = $('#cshero-header');
	var header_top = 0;
	/* scroll status */
	var scroll_status = '';
	/**
	 * window load event.
	 *
	 * Bind an event handler to the "load" JavaScript event.
	 * @author Fox
	 */
	$(window).on('load', function() {
		/** current scroll */
		scroll_top = $(window).scrollTop();
		/** current window width */
		window_width = $(window).width();
		/** current window height */
		window_height = $(window).height();
		/* get admin bar height */
		adminbar_height = adminbar.length > 0 ? adminbar.outerHeight(true) : 0 ;
		/* get top header menu */
		header_top = header.length > 0 ? header.offset().top - adminbar_height : 0 ;
		/* check sticky menu. */
		cms_stiky_menu();
		cms_page_loading();
		same_height();
		template_cms_grid_layout_menu();
		header_height();
		cms_enscroll();
		cms_section_offset();
		cms_mega_resize();
		cms_carousel_image();
		menu_width_border();
		body_boxed_width_row();
		template_team_award();
		cms_carousel_thumbnail_product();
		cms_carousel_related_product()

	});
	/**
	 * reload event.
	 *
	 * Bind an event handler to the "navigate".
	 */
	window.onbeforeunload = function(){
		cms_page_loading(1);
	}

	/**
	 * resize event.
	 *
	 * Bind an event handler to the "resize" JavaScript event, or trigger that event on an element.
	 * @author Fox
	 */
	$(window).on('resize', function(event, ui) {
		/** current window width */
		window_width = $(event.target).width();
		/** current window height */
		window_height = $(window).height();
		/** current scroll */
		scroll_top = $(window).scrollTop();
		/* check sticky menu. */
		cms_stiky_menu();
		same_height();
		header_height();
		cms_enscroll();
		cms_section_offset();
		cms_mega_resize();
		cms_carousel_image();
		menu_width_border();
		body_boxed_width_row();
		template_team_award();
		cms_carousel_thumbnail_product();

	});

	/**
	 * scroll event.
	 *
	 * Bind an event handler to the "scroll" JavaScript event, or trigger that event on an element.
	 * @author Fox
	 */
	$(window).on('scroll', function() {
		/** current scroll */
		scroll_top = $(window).scrollTop();
		/* check sticky menu. */
		cms_stiky_menu();
		cms_back_to_top();
	});
	/**
	 * Stiky menu
	 *
	 * Show or hide sticky menu.
	 * @author Fox
	 * @since 1.0.0
	 */
	function cms_stiky_menu() {
		if (0 < scroll_top) {
			switch (true) {
				case (header.hasClass('sticky-desktop') && window_width >=992):
					header.addClass('header-fixed');
					$('body').addClass('hd-fixed');
					// $('.widget_shopping_cart').removeClass('open');
					// $('.cshero-popup-search').removeClass('open');
					if($('.sticky_logo').length > 0) {
						$('.sticky_logo').removeClass('hide');
						$('.main_logo').addClass('hide');
					}
					break;
				case (header.hasClass('sticky-tablet') && window_width <= 992 && window_width >= 768):
					header.addClass('header-fixed');
					$('body').addClass('hd-fixed');
					if($('.sticky_logo').length > 0) {
						$('.sticky_logo').removeClass('hide');
						$('.main_logo').addClass('hide');
					}
					break;
				case (header.hasClass('sticky-mobile') && window_width < 768):
					header.addClass('header-fixed');
					$('body').addClass('hd-fixed');
					if($('.sticky_logo').length > 0) {
						$('.sticky_logo').removeClass('hide');
						$('.main_logo').addClass('hide');
					}
					break;
			}
		} else {
			header.removeClass('header-fixed');
			$('body').removeClass('hd-fixed');
			if($('.sticky_logo').length > 0) {
				$('.sticky_logo').addClass('hide');
				$('.main_logo').removeClass('hide');
			}
		}
	}
	/**
	 * Mobile menu
	 *
	 * Show or hide mobile menu.
	 * @author Fox
	 * @since 1.0.0
	 */

	$('body').on('click', '#cshero-menu-mobile', function(){
		var navigation = $(this).parent().find('#cshero-header-navigation');
		if(!navigation.hasClass('open')){
			navigation.addClass('open');
		} else {
			navigation.removeClass('open');
		}
	});
	/**
	 * Page Loading.
	 */
	function cms_page_loading($load) {
		switch ($load) {
			case 1:
				$('#cms-loadding').css('display','block')
				break;
			default:
				$('#cms-loadding').css('display','none')
				break;
		}
	}
	$('.sidebar-close').click(function(){
		$('.cshero-hidden-sidebar').removeClass('open');
		$('#cms-theme').removeClass('hidden-sidebar-active');
	});
	$("#cshero-header .hidden-sidebar").click(function(){
		$('.cshero-hidden-sidebar').toggleClass('open');
		$('#cms-theme').toggleClass('hidden-sidebar-active');
	})
	/**
	 * Back to top
	 */
	$('body').on('click', '.ef3-back-to-top', function () {
		$('body,html').animate({scrollTop:0}, '1000');
	})
	$('body').on('click', 'a.page-scroll', function(event) {
		var $anchor = $(this);
		$('body,html').stop().animate({
			scrollTop:$($anchor.attr('href')).offset().top
			}, '1000');
		event.preventDefault();
	});
	/* Show or Hide Buttom  */
	function cms_back_to_top(){
		/* Back To Top */
		if (scroll_top < window_height) {
			$('.ef3-back-to-top').addClass('off').removeClass('on');
		} else {
			$('.ef3-back-to-top').removeClass('off').addClass('on');
		}
	}
	/**
	 * One page
	 *
	 * @author Fox
	 */
	if(typeof(one_page_options) != "undefined"){
		one_page_options.speed = parseInt(one_page_options.speed);
		$('#site-navigation,.site-navigation').singlePageNav(one_page_options);
	}
	$('.cshero-popup-search #searchform').find("input[type='text']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Search");
		}
	});
	$('#sidebar #searchform').find("input[type='text']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Search");
		}
	});
	$('#cshero-header-navigation .main-navigation .menu-main-menu > li.menu-item-has-children').find(".multicolumn").each(function(ev) {
		$(this).parent().css('position','static');
	});
	$('.error404 .cms-content404 > div .error-404 #searchform').find("input[type='text']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Search our website....");
		}
	});
	$('.vc_wp_search #searchform').find("input[type='text']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Type and hit enter ...");
		}
	});
	$('#sidebar_learnpress #searchform').find("input[type='text']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Search");
		}
	});
	$('.widget_newsletterwidget').find("input[type='email']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Email Address");
		}
	});
	$('#cshero-header-inner #cshero-header-navigation .main-navigation #menu-menu-onepage > li > a.is-one-page.current').parent().addClass('current-onepage');
	$(".nav-button-icon .lnr-magnifier").click(function(){
		$('.cshero-popup-search').toggleClass('open');
		$('.widget_shopping_cart').removeClass('open');
		$(".nav-button-icon .lnr-magnifier").toggleClass('open');
	});
	$('#cshero-header-logo').find(".logo-sticky").each(function(ev) {
		$('#cshero-header-logo').addClass('has_logo-sticky');
	});
	$('#cshero-header-logo').find(".logo-text").each(function(ev) {
		$('#cshero-header-logo').addClass('has_logo-sticky');
	});
	$(".nav-button-icon .shopping-cart-wrapper").on('click',function(){
		$('.widget_shopping_cart').toggleClass('open');
		$('.cshero-popup-search').removeClass('open');
		$(".nav-button-icon .lnr-magnifier").removeClass('open');
	})
	$(".widget_shopping_cart_content .woocommerce-mini-cart__empty-message").parents('.widget_shopping_cart').addClass('widget_shopping_cart_empty');
	/* CMS Gallery Popup */
	$('.cms-gallery-item').magnificPopup({
		delegate: 'a.p-view', // child items selector, by clicking on it popup will open
		type: 'image',
		gallery: {
			enabled: true
		},
		mainClass: 'mfp-fade'
	});
	/* Video Light Box */
	$('.cms-button-video').magnificPopup({
		//disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: false
	});
	$('form input.update-cart').removeAttr('disabled');
	/* Show Tooltip */
	$('[data-toggle="tooltip"]').tooltip();
	/* Custom Owl Carousel*/
	function cms_enscroll() {
		$('#cshero-header .widget_shopping_cart .widget_shopping_cart_content').enscroll();
		$('#cshero-header-top .widget_shopping_cart .widget_shopping_cart_content').enscroll();
	}
	$('.cshero-menu-mobile i').click(function(){
		$('#page').find('#cshero-header-inner').toggleClass('open');
	});
	function template_cms_grid_layout_menu() {
		$('.cms_restaurant_grid_menu-raw-element').each(function () {
			var _this = $(this),_parent=_this.parent(),atts= _this.attr('data-atts');
			$.post(ajax_data.url,{
				action:'cms_restaurant_grid_menu_get_content',
				data:JSON.parse(atts)
			}).done(function(response) {
				_this.replaceWith(response);
				_parent.find('.template-cms_grid--layout-menu').owlCarousel({
                    navigation: false,
                    smartSpeed: 1000,
                    paginationSpeed: 3000,
                    rewindSpeed: 1000,
                    singleItem: true,
                    responsiveClass: true,
                    dots:false,
                    nav: true,
                    loop: true,
                    margin: 0,
                    responsive: {
                        0: {
                            items: 1,
                        },
                        768: {
                            items: 2,
                        },
                        992: {
                            items: 3,
                        },
                        1200: {
                            items: 3,
                        }
                    }
                });
            });
        });
        $('.cms_restaurant_menu-raw-element').each(function () {
            var _this = $(this),_parent=_this.parent(),atts= _this.attr('data-atts');
            $.post(ajax_data.url,{
                action:'cms_restaurant_menu_get_content',
                data:JSON.parse(atts)
            }).done(function(response) {
                _this.replaceWith(response);
                menu_width_border();
            });
        });
	}
	function template_team_award() {
		if($('.team-award-wrap').length > 0) {
			$('.team-award-wrap').owlCarousel({
				navigation: false,
				smartSpeed: 1000,
				paginationSpeed: 3000,
				rewindSpeed: 1000,
				singleItem: true,
				responsiveClass: true,
				dots:false,
				nav: true,
				loop: true,
				margin: 0,
				responsive: {
					0: {
						items: 1,
					},
					768: {
						items: 2,
					},
					992: {
						items: 3,
					},
					1200: {
						items: 4,
					}
				}
			});
		}
	}
	/* Video Light Box */
	$('.cms-video-popup').magnificPopup({
		//disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: false
	});

	/*same height*/
	function same_height(){
		if ( window_width > 767){
			$('#content ul.products li').matchHeight();
			$('.vc_row-o-equal-height .wpb_column').matchHeight();
			$('.blog-standand .same-height').matchHeight();
		}
		if ( window_width > 991){
			$('.woocommerce.archive .sameheight').matchHeight();
			$('.modal-content-register .modal-content-child').matchHeight();
			$('.modal-content-login .modal-content-child').matchHeight();
		}
	}
	function body_boxed_width_row(){
		if ( window_width > 1200){
			var $boy_width = $('.body-boxed').width();
			$('.body-boxed .vc_row[data-vc-stretch-content]').css('width',$boy_width);
			$('.body-boxed .vc_row[data-vc-full-width]').css('width',$boy_width);
		}

	}
	function header_height(){
		var h_top = $('header.header3').height() + $('#wpadminbar').height();
		var h_top2 = $('#cshero-header').height() + 29 ;
		$('.cshero-popup-search.header3').css('top',h_top+'px');
		$('.cshero-popup-search.default').css('top',h_top2+'px');
		$('#cshero-header-top .header-right .nav-button-icon .widget_shopping_cart').css('top',h_top2+'px');
	}
	$('.vc_wp_search #searchform').find("input[type='text']").each(function(ev) {
		if(!$(this).val()) {
			$(this).attr("placeholder", "Type and hit enter ...");
		}
	});
	function menu_width_border(){
		$('.cms-menu-food .menu-type-item .menu-post .post-item .content-right').find("h5").each(function(ev) {
			var title_width = $(this).children('.title').width() + 7;
			var price_width = $(this).children('.price').width() + 25;
			var title_wrap_width=$(this).width();
			$(this).children('.border').css('width',title_wrap_width-title_width-price_width+'px');
			$(this).children('.border').css('left',title_width+'px');
		});
	}
	$('body').on('click', '.lnr-magnifier',function(){
		setTimeout(function(){$('.cshero-popup-search .searchform input#s').focus()}, 500);
	});
	$('.getting-started').each(function(){
		var count_down = $(this).data("count-down");
		$(this).countdown(count_down, function(event) {
			$(this).html(event.strftime(''
				+ '<div class="col-xs-12 col-sm-3 col-md-3"><div class="countdown-item-container"><span class="countdown-amount">%D</span><span class="countdown-period">Days</span></div></div>'
				+ '<div class="col-xs-12 col-sm-3 col-md-3"><div class="countdown-item-container"><span class="countdown-amount">%H</span><span class="countdown-period">Hours</span></div></div>'
				+ '<div class="col-xs-12 col-sm-3 col-md-3"><div class="countdown-item-container"><span class="countdown-amount">%M</span><span class="countdown-period">Minutes</span></div></div>'
				+ '<div class="col-xs-12 col-sm-3 col-md-3"><div class="countdown-item-container"><span class="countdown-amount">%S</span><span class="countdown-period">Seconds</span></div></div>'));
		})});
	/* google Popup */
	$(".button-google-map").on('click',function(){
		$('#footer-google-map-wrap').toggleClass('open');
	});
	if($(window).width() < 991) {
		$(".button-google-map").on('click',function(){
			$('#footer-bottom').toggleClass('hidden');
		});
	}
	function cms_section_offset() {
		if($(window).width() > 768) {
			var w_desktop = $(window).width();
			var w_padding = (w_desktop - 1170)/2;
			$('.section-offset-left').css('padding-left',w_padding+'px');
			$('.section-offset-right').css('padding-right',w_padding+'px');
		}
	}
	function cms_mega_resize() {
		if($(window).width() > 1340) {
			var w_desktop = $(window).width();
			var mg_padding = (w_desktop - 1200)/2;
			$('header.header2 .multicolumn.drop_full_width').css('padding-left',mg_padding+'px');
			$('header.header2 .multicolumn.drop_full_width').css('padding-right',mg_padding+'px');
			$('header.header3 .multicolumn.drop_full_width').css('padding-left',mg_padding+'px');
			$('header.header3 .multicolumn.drop_full_width').css('padding-right',mg_padding+'px');
		}
	}
	$('.menu-main-menu').on('hover','> li',function(){
		$(this).find('.multicolumn > li').matchHeight();
	});
	/* Woo - Add class */
	$('.plus').on('click', function(){
		$(this).parent().find('input[type="number"]').get(0).stepUp();
	});
	$('.minus').on('click', function(){
		$(this).parent().find('input[type="number"]').get(0).stepDown();
	});
	/* Hide search form. */

	$('body').on('click', function (e) {
		if($(e.target).parents('form').hasClass('searchform'))
			return;
		if($(e.target).parents('.nav-button-icon').length == 0){
			$( ".cshero-popup-search" ).removeClass("open");
			$( ".lnr-magnifier" ).removeClass("open");
			$( ".widget_shopping_cart" ).removeClass("open");
		}
	});
	function cms_carousel_image() {
		if($('.cms-carousel-images .images-item-wrap').length > 0) {
			$(".cms-carousel-images .images-item-wrap").owlCarousel({
				navigation : true,
				smartSpeed : 1100,
				paginationSpeed : 3000,
				rewindSpeed: 1000,
				singleItem:true,
				items : 1,
				dots: true,
				nav: false,
				margin: 0,
			});
		}
	}
	function cms_carousel_thumbnail_product() {
		if($('.cms-thumbnails').length > 0) {
			$(".cms-thumbnails").owlCarousel({
				navigation : true,
				smartSpeed : 1100,
				paginationSpeed : 3000,
				rewindSpeed: 1000,
				singleItem:true,
				items : 4,
				dots: false,
				nav: true,
				margin: 23,
			});
		}
	}
	function cms_carousel_related_product() {
		if($('.related-products ').length > 0) {
			$(".products").owlCarousel({
				navigation : true,
				smartSpeed : 1100,
				paginationSpeed : 3000,
				rewindSpeed: 1000,
				singleItem:true,
				items : 4,
				dots: true,
				nav: false,
				margin: 30,
				responsive: {
					0: {
						items: 1,
					},
					768: {
						items: 2,
					},
					992: {
						items: 3,
					},
					1200: {
						items: 4,
					}
				}
			});
		}
	}
	$('.row-arrow').append( "<svg class='row-svg-bottom' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 147.7 35.2' style='enable-background:new 0 0 147.7 35.2;' xml:space='preserve'><g><g><path class='st0' d='M147.7,35.2c-49.2,0-98.5,0-147.7,0c10.4-3.6,18.7-10.6,27.5-16.9c7.7-5.6,16.1-10,24.9-13.8c14.5-6.2,28.8-6.1,43.2,0.1c9.9,4.2,19.2,9.4,27.8,15.9C130.9,26.4,138.6,31.9,147.7,35.2z'/></g></g></svg>" );
    // fix conflic cms-galerry
	jQuery(document).on('click','.cms-gallery-item',function(){
        jQuery(this).find('a.cms-prettyphoto').click();
    })

	//scroll action
    jQuery(document).on('click','.scroll-bellow',function(){
        var $this=jQuery(this), bottom = $this.offset().top + $this.outerHeight()-jQuery('#cshero-header').outerHeight(),target = jQuery('html,body');
        target.animate({ scrollTop:bottom},{duration :'slow',step:function(){
            if(jQuery(document).scrollTop() >= $this.offset().top+$this.outerHeight()-jQuery('#cshero-header').outerHeight())
                target.stop(true,false);
        }});
    });
	//fix enscroll crash after add to cart
    jQuery(document).ajaxComplete(function(event, xhr, settings){
		/* width / height for iframe/video/audio */
        cms_enscroll();
    });
});

