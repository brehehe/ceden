<?php
/**
 * Template Name: Blog Grid Right Sidebar
 *
 * @package CMSSuperHeroes
 * @subpackage CMS Theme
 * @since 1.0.0
 * @author Fox
 */

get_header(); ?>

<section id="primary" class="container blog-standand blog-grid blog-minimal">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
            <main id="main" class="site-main" role="main">
                <div class="row">
                    <?php
                    $i=0;
                    global $wp_query, $wp;

                    if (!isset($wp->query_vars['paged'])){
                        $page=1;
                    }
                    else{
                        $page=$wp->query_vars['paged'];
                    }
                    $wp_query->query('post_type=post&showposts='.get_option('posts_per_page').'&paged='.$page );

                    if ( have_posts() ) :
                        while ( have_posts() ) : the_post(); $i=$i+1;?>
                            <div class="col-item col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <?php get_template_part( 'single-templates/content-grid/content', get_post_format() ); ?>
                                    </div>

                                   <?php if (($i % 2) ==0) { ?>
                                  <div class="clr"> </div>
                                <?php }

                        endwhile; // end of the loop.

                        /* blog nav. */
                        laboom_paging_nav();

                        /* reset custom postdata. */
                        wp_reset_postdata();

                    else :
                        /* content none. */
                        get_template_part( 'single-templates/content', 'none' );

                    endif; ?>
               </div>
            </main><!-- #content -->
        </div>
        <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                <div id="sidebar" class="widget-area">
                    <div class="sidebar-inner">
                        <?php dynamic_sidebar( 'sidebar-1' ); ?>

                    </div><!-- .widget-area -->

                </div><!-- .widget-area -->
            </div><!-- #sidebar -->
        <?php endif; ?>

    </div>
</section><!-- #primary -->

<?php get_footer(); ?>