<?php 
    /* get categories */
        $taxo = 'category';
        $_category = array();
        if(!isset($atts['cat']) || $atts['cat']==''){
            $terms = get_terms($taxo);
            foreach ($terms as $cat){
                $_category[] = $cat->term_id;
            }
        } else {
            $_category  = explode(',', $atts['cat']);
        }
        $atts['categories'] = $_category;
        /*ajax media*/
        wp_enqueue_style('wp-mediaelement');
        wp_enqueue_script('wp-mediaelement');
        /* js, css for load more */
        wp_register_script('cms-loadmore-js', get_template_directory_uri() . '/assets/js/cms_loadmore_gallery.js', array('jquery'), '1.0', true);
        // What page are we on? And what is the pages limit?
        global $wp_query;
        $max = $wp_query->max_num_pages;
        $limit = $atts['limit'];
        $paged = (get_query_var('paged') > 1) ? get_query_var('paged') : 1;

        // Add some parameters for the JS.
        $current_id = str_replace('-', '_', $atts['html_id']);
        wp_localize_script(
            'cms-loadmore-js',
            'cms_more_obj' . $current_id,
            array(
                'startPage' => $paged,
                'maxPages' => $max,
                'total' => $wp_query->found_posts,
                'perpage' => $limit,
                'nextLink' => next_posts($max, false),
                'masonry' => $atts['layout']
            )
        );
        wp_enqueue_script('cms-loadmore-js');
?>
<div class="cms-grid-wraper template-cms_grid--layout-default <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <?php if($atts['filter']=="true" and $atts['layout']=='masonry'):?>
        <div class="cms-grid-filter">
            <ul class="cms-filter-category list-unstyled list-inline">
                <li><a class="active" href="#" data-group="all">All</a></li>
                <?php foreach($atts['categories'] as $category):?>
                    <?php $term = get_term( $category, $taxo );?>
                    <li><a href="#" data-group="<?php echo esc_attr('category-'.$term->slug);?>">
                            <?php echo esc_html($term->name);?>
                        </a>
                    </li>
                <?php endforeach;?>
            </ul>
        </div>
    <?php endif;?>
    <div class="row cms-grid <?php echo esc_attr($atts['grid_class']);?>">
        <?php
        $posts = $atts['posts'];
        while($posts->have_posts()){
            $posts->the_post();
            $groups = array();
            $groups[] = '"all"';
            foreach(cmsGetCategoriesByPostID(get_the_ID(),$taxo) as $category){
                $groups[] = '"category-'.$category->slug.'"';
            }
            ?>
            <div class="cms-grid-item <?php echo esc_attr($atts['item_class']);?>" data-groups='[<?php echo implode(',', $groups);?>]'>
                <div class="cms-grid-item cms-grid-item-inner">
                    <?php
                    if(has_post_thumbnail() && !post_password_required() && !is_attachment() &&  wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full', false)):
                        $class = ' has-thumbnail';
                        $thumbnail = get_the_post_thumbnail(get_the_ID(),'wp_laboom_team700X467');
                    else:
                        $class = ' no-image';
                        $thumbnail = '<img src="'.get_template_directory_uri(). '/assets/images/no-image.jpg" alt="'.get_the_title().'" />';
                    endif;
                    echo '<div class="cms-grid-media '.esc_attr($class).'">'.$thumbnail;
                    ?>
                    <?php echo '</div>';?>
                    <div class="content-right">

                        <div class="content-main">
                            <header class="entry-header">
                                <h3 class="entry-title ft-helveticaneue-b">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php
                                        if(is_sticky()){
                                            echo "<i class='fa fa-thumb-tack'></i>";
                                        }
                                        ?>
                                        <?php the_title(); ?>
                                    </a>
                                </h3>
                                <div class="detail-date"><?php echo get_the_date(get_option( 'date_format' ));?></div>
                            </header><!-- .entry-header -->


                            <div class="entry-content">
                                <?php
                                echo laboom_get_limit_str(get_the_excerpt(), 0,150);
                                ?>
                            </div><!-- .entry-content -->
                            <div class="grid_bottom">

                                <a class=" btn more" href="<?php the_permalink(); ?>"><?php esc_html_e('More', 'laboom') ?></a>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <div class="cms_pagination"></div>
</div>