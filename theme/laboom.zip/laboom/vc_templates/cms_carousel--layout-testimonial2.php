<?php

$test_style = isset($atts['test_style']) ? $atts['test_style'] : '';
$testimonial_content_color = !empty($atts['testimonial_content_color']) ? $atts['testimonial_content_color']: '';
?>
<div class="cms-carousel cms-carousel-testimonial2 <?php echo esc_attr($test_style);?> <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <?php
    global $opt_meta_options;
    $posts = $atts['posts'];
    while($posts->have_posts()){
        $posts->the_post();
        ?>
        <div class="cms-carousel-item">
            <div class="cms-carousel-item-inner">
                <div class="cms-carousel-item-bottom">

                    <?php
                    if(has_post_thumbnail() && !post_password_required() && !is_attachment() &&  wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full', false)):
                        $class = ' has-thumbnail';
                        $thumbnail = get_the_post_thumbnail(get_the_ID(),'laboom_team400X400');
                    else:
                        $class = ' no-image';
                        $thumbnail = '<img src="'.get_template_directory_uri(). '/assets/images/no-image.jpg" alt="'.get_the_title().'" />';
                    endif;
                    echo '<div class="cms-grid-media '.esc_attr($class).'">'.$thumbnail.'</div>';
                    ?>
                    <div class="cms-carousel-right">
                        <h4 class="cms-carousel-title">
                            <?php the_title();?>

                        </h4>
                        <?php if (!empty($opt_meta_options['testimonial_position'])) { ?>
                            <div class="team-position">
                                <?php echo esc_attr($opt_meta_options['testimonial_position']) ; ?>
                            </div>
                        <?php } ?>
                    </div>

                </div>
                <div class="cms-carousel-item-top">
                    <div class="cms-carousel-des">
                       <span class="content" style="color:<?php echo esc_attr($testimonial_content_color);?>"><?php echo wp_trim_words(strip_tags(strip_shortcodes(get_the_content())),30,'.') ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php

    }
    ?>
</div>