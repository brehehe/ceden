<?php
/* get categories */
$taxo = 'category';
$_category = array();
if (!isset($atts['cat']) || $atts['cat'] == '') {
    $terms = get_terms($taxo);
    foreach ($terms as $cat) {
        $_category[] = $cat->term_id;
    }
} else {
    $_category = explode(',', $atts['cat']);
}
?>
<div class="cms-grid-wraper <?php echo esc_attr($atts['template']); ?>" id="<?php echo esc_attr($atts['html_id']); ?>">
    <?php if ($atts['filter'] == "true" and $atts['layout'] == 'masonry'): ?>
        <div class="cms-grid-filter">
            <ul class="cms-filter-category list-unstyled list-inline">
                <li><a class="active" href="#" data-group="all">All</a></li>
                <?php foreach ($atts['categories'] as $category): ?>
                    <?php $term = get_term($category, $taxo); ?>
                    <li><a href="#" data-group="<?php echo esc_attr('category-' . $term->slug); ?>">
                            <?php echo esc_html($term->name); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row cms-grid <?php echo esc_attr($atts['grid_class']); ?>">
        <?php
        $posts = $atts['posts'];
        while ($posts->have_posts()) {
            $terms = (isset($atts['choose_cat']))? wp_get_post_terms(get_the_ID(), array($atts['choose_cat'])) : '';
            $posts->the_post();
            $groups = array();
            $groups[] = '"all"';
            foreach (cmsGetCategoriesByPostID(get_the_ID(), $taxo) as $category) {
                $groups[] = '"category-' . $category->slug . '"';
            }
            ?>
            <div class="cms-grid-item <?php echo esc_attr($atts['item_class']); ?>"
                 data-groups='[<?php echo implode(',', $groups); ?>]'>
                <div class="cms-grid-item cms-grid-item-inner">
                    <div class="post-item">
                        <div class="img-thumb">
                            <?php
                            if (has_post_thumbnail() && !post_password_required() && !is_attachment() && wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full', false)):
                                $class = ' has-thumbnail';
                                $thumbnail = get_the_post_thumbnail(get_the_ID(), 'laboom_team400X400');
                            else:
                                $class = ' no-image';
                                $thumbnail = '<img src="' . get_template_directory_uri() . '/assets/images/no-image.jpg" alt="' . get_the_title() . '" />';
                            endif;
                            echo '' . $thumbnail;
                            $current_unit = fr_get_currency();
                            $post_meta = fr_get_post_meta(get_the_ID());
                            // var_dump(fr_get_term_meta());die;
                            ?>
                        </div>
                        <div class="content-right">
                            <h5><span class="title"><?php the_title(); ?> </span><span
                                        class="border"></span><span
                                        class="price"> <?php echo esc_html($current_unit['character']) . esc_html($post_meta['fr-menu-price'][0]); ?> </span>
                            </h5>
                            <div class="content-desc">  <?php
                                echo laboom_get_limit_str(get_the_excerpt(), 0, 90);
                                ?> </div>
                            <div class="ribbon"><?php the_terms( get_the_ID(), 'category_gallery', '', ', ' ); ?></div>
                            <?php if (isset($terms[0]) && isset($terms[0]->name)): ?>
                                <div class="detail-terms"><?php echo esc_html($terms[0]->name) ?></div>
                            <?php endif ?>
                        </div>
                    </div>

                </div>
            </div>
            <?php
        }
        ?>
    </div>
</div>