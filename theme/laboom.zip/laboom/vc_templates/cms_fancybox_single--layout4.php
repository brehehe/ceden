<?php
$icon_name = "icon_" . $atts['icon_type'];
$iconClass = isset($atts[$icon_name])?$atts[$icon_name]:'';
$icon_custom = isset($atts['icon_custom']) ? $atts['icon_custom'] : '';
$content_color = isset($atts['content_color']) ? $atts['content_color'] : '';
$title_color = isset($atts['title_color']) ? $atts['title_color'] : '';
$icon_color = isset($atts['icon_color']) ? $atts['icon_color'] : '';
?>
<div class="cms-fancyboxes-wraper cms-fancybox-layout3 <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <div class="cms-fancyboxes-body">
        <div class="cms-fancybox-item">
            <div class="cms-fancybox-content">

                <?php if($atts['title_item']):?>
                    <div class="cms-fancybox-title" style="color:<?php echo esc_attr($title_color);?>"><?php echo apply_filters('the_title',$atts['title_item']);?></div>

                <?php endif;?>

                <?php if($atts['description_item']): ?>
                    <div class="cms-fancybox-desc" style="color:<?php echo esc_attr($content_color);?>">
                        <?php echo apply_filters('the_content',$atts['description_item']);?>
                    </div>
                <?php endif; ?>
                <?php if($atts['button_text']!=''):?>
                    <div class="cms-fancyboxes-footer">
                        <?php
                        $class_btn = ($atts['button_type']=='button')?'btn btn-secondary btn-rounded':'';
                        ?>
                        <a href="<?php echo esc_url($atts['button_link']);?>" class="<?php echo esc_attr($class_btn);?>"><?php echo esc_attr($atts['button_text']);?></a>
                    </div>
                <?php endif;?>
            </div>
            <div class="cms-fancybox-icon">
                <?php
                $image_url = '';
                if (!empty($atts['image'])) {
                    $attachment_image = wp_get_attachment_image_src($atts['image'], 'full');
                    $image_url = $attachment_image[0];
                }
                ?>
                <?php if($image_url):?>
                    <div class="cms-fancybox-image">
                        <img src="<?php echo esc_attr($image_url);?>" alt=""/>
                    </div>
                <?php else:?>
                    <span class="fancy-box-icon">
                         <i class="<?php echo esc_attr($iconClass); echo esc_attr($icon_custom);?>" style="color:<?php echo esc_attr($icon_color);?>"></i>
                    </span>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>