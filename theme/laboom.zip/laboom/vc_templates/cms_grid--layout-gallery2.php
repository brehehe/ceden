<?php
global $opt_meta_options;
/* get categories */
$taxo = 'category_gallery';
$_category = array();
if(!isset($atts['cat']) || $atts['cat']==''){
    $terms = get_terms($taxo);
    foreach ($terms as $cat){
        $_category[] = $cat->term_id;
    }
} else {
    $_category  = explode(',', $atts['cat']);
}
$atts['categories'] = $_category;
/*ajax media*/
wp_enqueue_style('wp-mediaelement');
wp_enqueue_script('wp-mediaelement');
/* js, css for load more */
wp_register_script('cms-loadmore-js', get_template_directory_uri() . '/assets/js/cms_loadmore_gallery.js', array('jquery'), '1.0', true);
// What page are we on? And what is the pages limit?
global $wp_query;
$max = $wp_query->max_num_pages;
$limit = $atts['limit'];
$paged = (get_query_var('paged') > 1) ? get_query_var('paged') : 1;

// Add some parameters for the JS.
$current_id = str_replace('-', '_', $atts['html_id']);
wp_localize_script(
    'cms-loadmore-js',
    'cms_more_obj' . $current_id,
    array(
        'startPage' => $paged,
        'maxPages' => $max,
        'total' => $wp_query->found_posts,
        'perpage' => $limit,
        'nextLink' => next_posts($max, false),
        'masonry' => $atts['layout']
    )
);
wp_enqueue_script('cms-loadmore-js');
?>
<div class="cms-grid-wraper <?php if( isset($atts['padding_item']) && $atts['padding_item']=='yes') { echo 'has-padding-item';}?> <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <?php if($atts['filter']=="true" and $atts['layout']=='masonry'):?>
        <div class="cms-grid-filter">
            <ul class="cms-filter-category list-unstyled list-inline">
                <li><a class="active" href="#" data-group="all">ALL</a></li>
                <?php foreach($atts['categories'] as $category):?>
                    <?php $term = get_term( $category, $taxo );?>
                    <li><a href="#" data-group="<?php echo esc_attr('category-'.$term->slug);?>">
                            <?php echo esc_html($term->name);?>
                        </a>
                    </li>
                <?php endforeach;?>
            </ul>
        </div>
    <?php endif;?>
    <div class="cms-grid <?php echo esc_attr($atts['grid_class']);?>">
        <?php
        $posts = $atts['posts'];
        $size = 'laboom_blog555X400';
        $item_class='';

        while($posts->have_posts()){
            $posts->the_post();
            $groups = array();
            $groups[] = '"all"';
            foreach(cmsGetCategoriesByPostID(get_the_ID(),$taxo) as $category){
                $groups[] = '"category-'.$category->slug.'"';
            }
            if (!empty($opt_meta_options['gallery_thumb_size'])) {
                if ($opt_meta_options['gallery_thumb_size']=='2x') {
                    $size = 'laboom_blog555X200';
                    $item_class=" col-xs-12 col-sm-6 col-md-6 col-2x";
                }
                else if ($opt_meta_options['gallery_thumb_size']=='2x2y') {
                    $size = 'laboom_blog555X430';
                    $item_class="col-xs-12 col-sm-6 col-md-6";
                }
                else {
                    $size = 'laboom_blog260X200';
                    $item_class=" col-xs-12 col-sm-6 col-md-3";
                }
            }
            ?>
            <div class="cms-grid-item <?php echo esc_attr($item_class);?> " data-groups='[<?php echo implode(',', $groups);?>]'>
                <div class="cms-grid-3columns">
                    <?php
                    if(has_post_thumbnail() && !post_password_required() && !is_attachment() &&  wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), $size, false)):
                        $class = ' has-thumbnail';
                        $thumbnail = get_the_post_thumbnail(get_the_ID(),$size);
                        $thumbnail_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID(),$size));
                    else:
                        $class = ' no-image';
                        $thumbnail = '<img src="'.esc_url(CMS_IMAGES).'no-image.jpg" alt="'.get_the_title().'" />';
                        $thumbnail_url = '' .get_template_directory_uri(). '/assets/images/no-image.jpg';
                    endif;
                    echo '<div class="cms-grid-media '.esc_attr($class).'">'.$thumbnail.'</div>';
                    ?>
                    <div class="text-hide">
                        <div class="cms-gallery-item">
                            <a class="cms-prettyphoto p-view" href="<?php echo esc_url($thumbnail_url);?>"></a>
                        </div>
                        <div class="text-hide-inner">
                            <div class="cms-gallery-item-inner">
                                <h3 class="entry-title">
                                        <?php the_title(); ?>
                                </h3>
                                <div class="detail-terms"><?php echo wp_trim_words(strip_tags(get_the_term_list( get_the_ID(), 'category_gallery', '', ' / ' ))); ?></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <?php
    if($atts['filter']=="true"){
        laboom_paging_nav();
    }
   ?>
</div>