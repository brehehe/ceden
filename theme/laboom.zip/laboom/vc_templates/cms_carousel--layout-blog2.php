<?php
$blog2_style = !empty($atts['blog2_style']) ? $atts['blog2_style']: '';
?>
<div class="cms-carousel template-cms_carousel-blog <?php echo ''.$blog2_style;?> <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">

    <?php
    $posts = $atts['posts'];
    global $opt_theme_options;
    while($posts->have_posts()){
        $posts->the_post();
        ?>
        <div class="cms-carousel-item">
            <div class="cms-carousel-item-inner">
                <?php
                if(has_post_thumbnail() && !post_password_required() && !is_attachment() &&  wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full', false)):
                    $class = ' has-thumbnail';
                    $thumbnail_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID(),'full'));
                else:
                    $class = ' no-image';
                    $thumbnail_url = '' .get_template_directory_uri(). '/assets/images/no-image.jpg';
                endif;
                echo '<div class="cms-grid-media '.esc_attr($class).'"><div class="img" style="background-image:url('.$thumbnail_url.')"></div>';
                ?>

                <div class="detail-date"><span class="day"><?php echo get_the_date('d');?></span><span class="month"><?php echo get_the_date('M');?></span></div>


                <?php echo '</div>';?>
                <div class="content-right">

                    <div class="content-main">
                        <header class="entry-header">
                            <div class="entry-meta">

                                <div class="meta-info">
                                    <ul class="archive_detail">
                                            <li class="detail-author"><i class="fa fa-user" aria-hidden="true"></i> <?php echo esc_html__('By','laboom');?> <?php the_author_posts_link(); ?> </li>
                                            <li class="detail-comment"><i class="fa fa-comments-o" aria-hidden="true"></i> <?php echo esc_html(comments_number('0','1','%')); ?> <?php esc_html_e('Comments', 'laboom'); ?><a href="<?php the_permalink(); ?>"></a></li>

                                    </ul>
                                </div>

                            </div><!-- .entry-meta -->
                            <h3 class="entry-title ft-helveticaneue-b">
                                <a href="<?php the_permalink(); ?>">
                                    <?php
                                    if(is_sticky()){
                                        echo "<i class='fa fa-thumb-tack'></i>";
                                    }
                                    ?>
                                    <?php echo laboom_get_limit_str(get_the_title(), 0,20); ?>
                                </a>
                            </h3>

                        </header><!-- .entry-header -->


                        <div class="entry-content">
                            <?php
                            echo laboom_get_limit_str(get_the_excerpt(), 0,80);
                            ?>
                        </div><!-- .entry-content -->
                        <a class="more" href="<?php the_permalink(); ?>"> <?php esc_html_e('Read More', 'laboom') ?> <span class="lnr lnr-arrow-right"></span></a>

                    </div>

                </div>

            </div>

        </div>
        <?php
    }
    ?>
</div>