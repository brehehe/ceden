<?php
global $opt_meta_options;
$team_style = isset($atts['team_style']) ? $atts['team_style'] : '';
?>
<div class="cms-carousel cms-carousel-team  <?php echo esc_attr($team_style);?> <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <?php
    $posts = $atts['posts'];
    while($posts->have_posts()){
        $posts->the_post();
        $team_position = !empty($opt_meta_options['team_position']) ? $opt_meta_options['team_position']: '';
        ?>
        <div class="cms-carousel-item">
            <div class="team-item">
                <div class="team-item-top">
                    <?php
                    if(has_post_thumbnail() && !post_password_required() && !is_attachment() &&  wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full', false)):
                        $class = ' has-thumbnail';
                        $thumbnail = get_the_post_thumbnail(get_the_ID(),'laboom_team260X350');
                    else:
                        $class = ' no-image';
                        $thumbnail = '<img src="'.get_template_directory_uri(). '/assets/images/no-image.jpg" alt="'.get_the_title().'" />';
                    endif;
                    echo '<div class="cms-grid-media '.esc_attr($class).'">'.$thumbnail.'</div>';
                    ?>
                </div>
                <div class="team-item-bottom">
                    <h3>
                        <a href="<?php the_permalink(); ?>">
                            <?php the_title();?>
                        </a>
                    </h3>
                    <div class="team_position">
                        <?php echo esc_attr($team_position);?>
                    </div>
                    <div class="cms-team-social">
                        <?php laboom_social_team();?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
</div>

