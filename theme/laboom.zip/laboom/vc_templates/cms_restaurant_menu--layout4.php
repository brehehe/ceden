<?php

if (!function_exists('fr_get_posts_by_tax')) {
    return;
}
if (!isset($atts['choose_menu'])) {
    return;
}
$number_menu = (!empty($atts['number_menu']) && is_numeric($atts['number_menu']) && $atts['number_menu']> 0)  ? $atts['number_menu'] : 6;
$cat_slug = (isset($atts['choose_menu'])) ? $atts['choose_menu'] : '';
$data = fr_get_posts_by_tax($cat_slug,array(),$limit = $number_menu,'seperate','date','DESC');
$posts = laboom_get_post_from_query_seperate_data($data);
$posts_in_all_filter_view = laboom_cms_menu_get_posts_in_all_cat_filter_view($number_menu,$data);

$terms = $data['infor']['terms'];

?>
<div class="cms-menu-food cms-grid-wraper layout4">
    <div class="cms-grid-filter">
        <ul class="cms-filter-category list-unstyled list-inline">
            <li><a class="active" href="#" data-group="all-cat">All</a></li>
            <?php foreach ($terms as $term): ?>
                <li><a href="#" data-group="<?php echo esc_attr($term->slug); ?>">
                        <?php echo esc_html($term->name); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="cms-grid-masonry">
        <?php
        // limit cat for cat show in view
        $terms_limit_show = array();
        foreach ($posts as $post):
            $terms = fr_get_terms_by_post( $post->ID, $cat_slug );
            $groups= array();// array('"all"');
            if(in_array($post->ID,$posts_in_all_filter_view['ids']))
                $groups[] = '"all-cat"';
            foreach ( $terms as $term ) {
                $term_slug = $term->slug;
                if(empty($terms_limit_show[$term_slug]))
                    $terms_limit_show[$term_slug] = 0;
                if($terms_limit_show[$term_slug] < $number_menu)
                {
                    $groups[] = '"'.$term_slug.'"';
                    $terms_limit_show[$term_slug]++;
                }
            }
            ?>
            <div class="cms-grid-item col-xs-12 col-sm-6 col-md-4" data-groups='[<?php echo implode(',', $groups); ?>]'>
                <div class="menu-post">
                    <?php
                    $post_meta = fr_get_post_meta($post->ID);
                    $term = wp_get_post_terms($post->ID, $cat_slug);
                    $term = (isset($term[0]))? $term[0] : '';
                    ?>
                    <div class="post-item" >
                        <div class="post-item-inner">
                            <div class="img-thumb">
                                <?php  $thumbnail = wp_get_attachment_image($post_meta['_thumbnail_id'][0],'laboom_blog359X250');
                                echo  $thumbnail;
                                ?>
                            </div>
                            <div class="content-right">
                                <h3>
                                    <?php echo esc_html($post->post_title); ?>
                                    <span class="price"> <?php if(function_exists('fr_the_price'))fr_the_price($post->ID,false,'sale-regular') ?> </span>
                                </h3>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</div>

