<?php
extract(shortcode_atts(array(
    'hd_subtitle' => '',
    'hd_title' => '',
    'hd_subtitle' => '',
    'hd_description' => '',
    'heading_letter_spacing' => '',
    'heading_subtitle_color'=>'',
    'heading_color'=>'',
    'heading_line_color'=>'',
    'heading_size'=>'',
    'heading_lineheight'=>'',
    'desc_color'=>'',
    'desc_size'=>'',
    'subtitle_size'=>'',
    'desc_lineheight'=>'',
    'custom_class' => '',
    'cms_desc_font_family' => '',
    'layout_style' => '',

), $atts));
?>
<div class="cms-heading-wrapper heading-layout1 <?php echo esc_attr($custom_class); echo esc_attr($layout_style); ?>">
        <div class="cms-heading-inner">
            <div class="cms-heading-content">
                <?php if (!empty($hd_subtitle) && $hd_subtitle) { ?>
                    <div class="subtitle" style="color: <?php echo esc_attr($heading_subtitle_color)?>;font-size: <?php echo esc_attr($subtitle_size)?>;">
                        <?php echo esc_attr($hd_subtitle); ?>
                    </div>
                <?php } ?>
                <?php if (!empty($hd_title) && $hd_title) { ?>
                    <h2 class="title" style="color: <?php echo esc_attr($heading_color)?>;font-size: <?php echo esc_attr($heading_size)?>;line-height: <?php echo esc_attr($heading_lineheight)?>;letter-spacing:<?php echo esc_attr($heading_letter_spacing)?>; ">
                        <?php echo esc_attr($hd_title); ?>
                        <span class="border" style="background-color:<?php echo esc_attr($heading_line_color);?>"></span>
                    </h2>
                <?php } ?>
                <?php if (!empty($hd_description) && $hd_description) { ?>
                    <div class="description" style="color: <?php echo esc_attr($desc_color)?>;font-size: <?php echo esc_attr($desc_size)?>;line-height: <?php echo esc_attr($desc_lineheight)?>; ">
                        <?php echo apply_filters('the_content',$atts['hd_description']);?>
                    </div>
                <?php } ?>
            </div>

        </div>


</div>