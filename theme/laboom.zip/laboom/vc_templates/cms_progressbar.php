<?php
$icon_name = "icon_" . $atts['icon_type'];
$iconClass = isset($atts[$icon_name])?$atts[$icon_name]:'';
$value_color = isset($atts['value_color'])?$atts['value_color']:'';
$title_color = isset($atts['title_color'])?$atts['title_color']:'';
?>
<div class="cms-progress-wraper <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <div class=" cms-progress-body">
        <?php
        $item_class = 'cms-progress-item-wrap';
        $item_title     = $atts['item_title'];
        $show_value     = ($atts['show_value']=='true')?true:false;
        $value          = $atts['value'];
        $value_suffix   = $atts['value_suffix'];
        $bg_color       = $atts['bg_color'];
        $color          = $atts['color'];
        $striped        = ($atts['striped']=='yes')?true:false;
        ?>
        <div class="<?php echo esc_attr($item_class);?>">
            <?php if($item_title):?>
                <div class="cms-progress-title" style="color:<?php echo esc_attr($title_color);?>">
                    <?php if($iconClass):?>
                        <i class="<?php echo esc_attr($iconClass);?>"></i>
                    <?php endif;?>
                    <?php echo apply_filters('the_title',$item_title);?>
                    <span class="progress-couter" style="color:<?php echo esc_attr($value_color);?>">

                        <?php if($show_value): ?>
                            <?php echo esc_attr($value.$value_suffix);?>
                        <?php endif; ?>

                    </span>
                </div>
            <?php endif;?>
            <div class="progress-content">

                <div class="cms-progress progress <?php if($striped){echo ' progress-striped';}?>"
                     style="background-color:<?php echo esc_attr($bg_color);?>;
                         " >

                    <div id="item-<?php echo esc_attr($atts['html_id']); ?>"
                         class="progress-bar" role="progressbar"
                         data-valuetransitiongoal="<?php echo esc_attr($value); ?>"
                         style="background-color:<?php echo esc_attr($color);?>;"
                        >
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>