
<div class="cms-carousel cms-carousel-client <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
        <?php
        $posts = $atts['posts'];
        $wp_query = new WP_Query();
        while($posts->have_posts()){
            $posts->the_post();
            global $opt_meta_options;
            ?>
            <div class="cms-carousel-item">
                <div class="cms-carousel-item-inner">
                            <?php
                            if(has_post_thumbnail()):
                                $class = ' has-thumbnail';
                                $thumbnail = get_the_post_thumbnail(get_the_ID(),'full');
                            else:
                                $class = ' no-image';
                                $thumbnail = '<img src="'.esc_url(CMS_IMAGES).'no-image.jpg" alt="'.get_the_title().'" />';
                            endif;
                            echo '<div class="cms-carousel-media '.esc_attr($class).'">'.$thumbnail.'</div>';
                            ?>



                 </div>
            </div>
            <?php
        }
        ?>
</div>

