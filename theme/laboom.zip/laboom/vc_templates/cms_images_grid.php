<?php
extract(shortcode_atts(array(
    'image_item' => '',
    'image_item_tr' => '',
    'image_item_bl' => '',
), $atts));
?>
<div class="cms-images-grid">
    <?php
            if (empty($image_item)) return;

            $ids = explode(',', $image_item);
            $image = wp_get_attachment_url($ids[0]);
            echo '<div class="primary-item" style="background:url(' . esc_url($image) . ')"></div>';

    ?>
    <?php
    if (empty($image_item_tr)) return;

    $ids1 = explode(',', $image_item_tr);
        $image1 = wp_get_attachment_url($ids1[0]);
        echo '<div class="item-top-right" style="background:url(' . esc_url($image1) . ')"></div>';

    ?>
    <?php
    if (empty($image_item_bl)) return;

    $ids2 = explode(',', $image_item_bl);
        $image2 = wp_get_attachment_url($ids2[0]);
        echo '<div class="item-bottom-left" style="background:url(' . esc_url($image2) . ')"></div>';

    ?>
</div>