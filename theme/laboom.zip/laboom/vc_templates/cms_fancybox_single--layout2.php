<?php 
    $icon_name = "icon_" . $atts['icon_type'];
    $iconClass = isset($atts[$icon_name])?$atts[$icon_name]:'';
    $icon_custom = isset($atts['icon_custom']) ? $atts['icon_custom'] : '';
    $title_color = isset($atts['title_color']) ? $atts['title_color'] : '';
    $subtitle = isset($atts['subtitle']) ? $atts['subtitle'] : '';
?>
<div class="cms-fancyboxes-wraper clearfix <?php echo esc_attr($atts['template']);?>" id="<?php echo esc_attr($atts['html_id']);?>">
    <div class="cms-fancyboxes-body">
        <div class="cms-fancybox-item">
            <?php
            $image_url = '';
            if (!empty($atts['image'])) {
                $attachment_image = wp_get_attachment_image_src($atts['image'], 'full');
                $image_url = $attachment_image[0];
            }
            if($image_url):?>
                <div class="cms-fancybox-overlay" style="background-image: url(<?php echo esc_attr($image_url);?>);">
                </div>
            <?php endif;?>
            <div class="cms-fancybox-icon">
                <?php if (!empty($atts['image_icon1'])){
                    $ids1 = explode(',', $atts['image_icon1']);
                    $image1 = wp_get_attachment_url($ids1[0]);?>
                         <img src="<?php echo esc_url($image1);?>" alt=""/>
                <?php }else{?>
                      <i class="<?php echo esc_attr($iconClass); echo esc_attr($icon_custom);?>"></i>
                <?php }?>

            </div>
            <div class="cms-fancybox-right">
                <?php if (!empty($atts['image_icon_hover'])){
                    $ids2 = explode(',', $atts['image_icon_hover']);
                    $image2 = wp_get_attachment_url($ids2[0]);?>
                    <img class="img-hover" src="<?php echo esc_url($image2);?>" alt=""/>
                <?php }?>

                <?php if($atts['title_item']):?>
                    <div class="cms-fancybox-title" style="color:<?php echo esc_attr($title_color);?>">
                        <?php $title = apply_filters('the_title',$atts['title_item']);

                        $tmp = explode(' ', $title);
                        $last = $tmp[count($tmp)-1];
                        $tmp[count($tmp)-1] = '';
                        $first = implode(' ', $tmp);
                        $title_style = '';
                        ?>
                       <?php echo $first; ?><span><?php echo $last; ?></span>
                    </div>

                <?php endif;?>
        
                <?php if($atts['description_item']): ?>
                    <div class="cms-fancybox-content ft-pxi-r">
                        <?php echo apply_filters('the_content',$atts['description_item']);?>
                    </div>
                <?php endif; ?>
                <?php if($atts['button_text']!=''):?>
                    <div class="cms-fancyboxes-footer">
                        <?php
                        $class_btn = ($atts['button_type']=='button')?'btn btn-default':'';
                        ?>
                        <a href="<?php echo esc_url($atts['button_link']);?>" class="<?php echo esc_attr($class_btn);?>"><?php echo esc_attr($atts['button_text']);?></a>
                    </div>
                <?php endif;?>
            </div>

        </div>
    </div>
</div>