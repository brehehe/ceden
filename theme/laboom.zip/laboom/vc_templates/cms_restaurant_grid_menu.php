<?php
if (!function_exists('fr_get_tax_by')) {
    return;
}
if (!isset($atts['choose_menu'])) {
    return;
}
$cat_slug = (isset($atts['choose_menu'])) ? $atts['choose_menu'] : '';
$number_menu = (isset($atts['number_menu'])) ? $atts['number_menu'] : 3;
$carousel_restaurant_style = (isset($atts['carousel-restaurant-style'])) ? $atts['carousel-restaurant-style'] : '';
$posts = fr_get_posts_by_tax($cat_slug, array(), $limit = $number_menu, $type = 'all','date','DESC');
$current_unit = fr_get_currency();
// get term by cat
// get post by term
?>
<div class="template-cms_grid--layout-menu <?php echo esc_attr($carousel_restaurant_style);?>">
    <?php if (isset($posts['body']['posts']) && !empty($posts['body']['posts'])): ?>
        <?php foreach ($posts['body']['posts'] as $post): ?>

            <div class="menu-type-item cms-grid-item">
                <div class="menu-post">
                    <?php
                    $post_meta = fr_get_post_meta($post->ID);
                    $term = wp_get_post_terms($post->ID, $cat_slug);
                    $term = (isset($term[0]))? $term[0] : '';
                    ?>
                    <div class="post-item">
                        <div class="post-item-inner">
                            <div class="img-thumb">
                               <?php  $thumbnail = wp_get_attachment_image($post_meta['_thumbnail_id'][0],'laboom_team400X400');
                               echo  $thumbnail;

                               ?>
                            </div>
                            <div class="content-right">
                                <h3>
                                   <?php echo esc_html($post->post_title); ?>
                                </h3>
                                <div class="content-desc"><?php echo laboom_get_limit_str($post->post_content, 0, 90); ?></div>
                                <div class="price"> <?php if(function_exists('fr_the_price'))fr_the_price($post->ID,false,'sale-regular') ?> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif ?>
</div>
