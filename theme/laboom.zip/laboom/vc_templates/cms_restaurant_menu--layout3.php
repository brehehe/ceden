<?php

if (!function_exists('fr_get_posts_by_tax')) {
    return;
}
if (!isset($atts['choose_menu'])) {
    return;
}
$number_menu = (!empty($atts['number_menu']) && is_numeric($atts['number_menu']) && $atts['number_menu']> 0)  ? $atts['number_menu'] : 9;
$cat_slug = (isset($atts['choose_menu'])) ? $atts['choose_menu'] : '';
$data = fr_get_posts_by_tax($cat_slug,array(),$limit = $number_menu,'seperate','date','DESC');
$posts = laboom_get_post_from_query_seperate_data($data);
$posts_in_all_filter_view = laboom_cms_menu_get_posts_in_all_cat_filter_view($number_menu,$data);

$terms = $data['infor']['terms'];

// get term by cat
// get post by term
$link_button = isset($atts['link_button'])?$atts['link_button']:'';
$link = vc_build_link($atts['link_button']);
$a_href = '';
$a_title = '';
if ( strlen( $link['title'] ) > 0 ) {
    $a_title = $link['title'];
}
if ( strlen( $link['url'] ) > 0 ) {
    $a_href = $link['url'];
}
$filter_style = isset($atts['filter_style']) ? $atts['filter_style'] : '';
$menu_desc_color = isset($atts['menu_desc_color']) ? $atts['menu_desc_color'] : '';
?>
<div class="cms-menu-food cms-grid-wraper layout3">
    <div class="cms-grid-filter <?php echo esc_attr($filter_style);?>">
        <ul class="cms-filter-category list-unstyled list-inline">
            <li><a class="active" href="#" data-group="all-cat">
                    <span class="lnr lnr-dinner"></span>
                    <span><?php echo esc_html__('All','laboom');?></span>
                </a>
            </li>
            <?php foreach ($terms as $term):
                $term_meta = fr_get_term_meta($term->term_id)?>

                <li><a href="#" data-group="<?php echo esc_attr($term->slug); ?>">
                        <span class="img"><img src="<?php echo wp_get_attachment_url($term_meta['background']) ?>" alt="" title=""></span>
                        <span><?php echo esc_html($term->name); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="cms-grid-masonry">
        <?php
        // limit cat for cat show in view
        $terms_limit_show = array();
        foreach ($posts as $post):
            $terms = fr_get_terms_by_post( $post->ID, $cat_slug );
            $groups= array();// array('"all"');
            if(in_array($post->ID,$posts_in_all_filter_view['ids']))
                $groups[] = '"all-cat"';
            foreach ( $terms as $term ) {
                $term_slug = $term->slug;
                if(empty($terms_limit_show[$term_slug]))
                    $terms_limit_show[$term_slug] = 0;
                if($terms_limit_show[$term_slug] < $number_menu)
                {
                    $groups[] = '"'.$term_slug.'"';
                    $terms_limit_show[$term_slug]++;
                }
            }
            ?>
            <div class="cms-grid-item col-xs-12 col-md-6" data-groups='[<?php echo implode(',', $groups); ?>]'>
                <div class="menu-post">
                    <?php
                    $post_meta = fr_get_post_meta($post->ID);
                    $term = wp_get_post_terms($post->ID, $cat_slug);
                    $term = (isset($term[0]))? $term[0] : '';
                    ?>
                    <div class="post-item" >
                        <div class="post-item-inner">
                            <div class="img-thumb">
                                <?php  $thumbnail = wp_get_attachment_image($post_meta['_thumbnail_id'][0],'laboom_team400X400');
                                echo  $thumbnail;
                                ?>
                            </div>
                            <div class="content-right">
                                <h3>
                                    <?php echo esc_html($post->post_title); ?>
                                    <span class="price"> <?php if(function_exists('fr_the_price'))fr_the_price($post->ID,false,'sale-regular') ?> </span>
                                </h3>
                                <div class="content-desc" style="color:<?php echo esc_attr($menu_desc_color);?>"><?php echo laboom_get_limit_str($post->post_content, 0, 90) ; ?> </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</div>
<?php if ($link_button){?>
    <div class="link-full-menu text-center layout3 <?php echo esc_attr($filter_style);?>">
        <a class="btn btn-rounded" href="<?php echo esc_url($a_href);?>" title="<?php echo esc_attr($a_title);?>">
            <?php echo esc_attr($a_title);?>
        </a>
    </div>
<?php }?>
