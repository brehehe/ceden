<?php
extract(shortcode_atts(array(
	'process_title1' => '',
	'process_title2' => '',
	'process_title3' => '',
	'process_title4' => '',
	'process_description1' => '',
	'process_description2' => '',
	'process_description3' => '',
	'process_description4' => '',
	'image_item1' => '',
	'image_item2' => '',
	'image_item3' => '',
	'image_item4' => '',
	'process_style' => '',
), $atts));
?>
<div class="cms-process clearfix <?php echo esc_attr($process_style);?>">
	<ul class="cms-process-list">
		<li class="cms-process-item clearfix">
			<div class="cms-process-icon rda_scale">
				<?php if (empty($image_item1)) return;
				$ids1 = explode(',', $image_item1);
					$image1 = wp_get_attachment_url($ids1[0]);?>
					<img src="<?php echo esc_url($image1);?>" alt=""/>

			</div>
			<div class="cms-process-content">
				<h3 class="cms-process-title"><?php echo esc_attr($process_title1); ?></h3>
				<div class="cms-process-desc"><?php echo esc_attr($process_description1); ?></div>
			</div>
		</li>
		<li class="cms-process-item clearfix">
			<div class="cms-process-icon rda_scale">
				<?php if (empty($image_item2)) return;
				$ids2 = explode(',', $image_item2);
				$image2 = wp_get_attachment_url($ids2[0]);?>
				<img src="<?php echo esc_url($image2);?>" alt=""/>
			</div>
			<div class="cms-process-content">
				<h3 class="cms-process-title"><?php echo esc_attr($process_title2); ?></h3>
				<div class="cms-process-desc"><?php echo esc_attr($process_description2); ?></div>
			</div>
		</li>
		<li class="cms-process-item clearfix">
			<div class="cms-process-icon rda_scale">
				<?php if (empty($image_item3)) return;
				$ids3 = explode(',', $image_item3);
				$image3 = wp_get_attachment_url($ids3[0]);?>
				<img src="<?php echo esc_url($image3);?>" alt=""/>
			</div>
			<div class="cms-process-content">
				<h3 class="cms-process-title"><?php echo esc_attr($process_title3); ?></h3>
				<div class="cms-process-desc"><?php echo esc_attr($process_description3); ?></div>
			</div>
		</li>
		<li class="cms-process-item clearfix">
			<div class="cms-process-icon rda_scale">
				<?php if (empty($image_item4)) return;
				$ids4 = explode(',', $image_item4);
				$image4 = wp_get_attachment_url($ids4[0]);?>
				<img src="<?php echo esc_url($image4);?>" alt=""/>
			</div>
			<div class="cms-process-content">
				<h3 class="cms-process-title"><?php echo esc_attr($process_title4); ?></h3>
				<div class="cms-process-desc"><?php echo esc_attr($process_description4); ?></div>
			</div>
		</li>

	</ul>
</div>