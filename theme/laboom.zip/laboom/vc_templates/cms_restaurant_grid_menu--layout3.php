<?php
if (!function_exists('fr_get_tax_by')) {
    return;
}
$cat_slug = (isset($atts['choose_menu'])) ? $atts['choose_menu'] : '';
$number_menu = (isset($atts['number_menu'])) ? $atts['number_menu'] : 6;
$current_tax = fr_get_tax_by($cat_slug);
if(empty($current_tax['terms'])) { esc_html__('Please choose a category menu!','laboom');return;}
$terms = $current_tax['terms'];
// get term by cat
// get post by term
?>

<div class="cms-menu-food cms-grid-wraper cms-menu-food-layout2 cms-menu-food-layout3">
    <div class="cms-grid-masonry">
        <?php foreach ($terms as $term): ?>
            <?php $posts = fr_get_posts_by_term($current_tax['slug'], $term, $number_menu)  ?>
            <?php $term_meta = fr_get_term_meta($term->term_id) ;
            ?>
            <div class="menu-type-item cms-grid-item clearfix">
                <div class="menu-title">
                    <img src="<?php echo wp_get_attachment_url($term_meta['background']) ?>" alt="" title="">
                    <h3> <?php echo esc_html($term->name); ?></h3>
                    <div class="menu-desc">  <?php echo esc_html($term->description); ?></div>
                </div>
                <div class="menu-post">
                    <div class="row">
                        <?php foreach ($posts as $menu_item): ?>
                            <?php
                            $post_meta = fr_get_post_meta($menu_item->ID);
                            $current_unit = fr_get_currency();
                            ?>
                            <div class="post-item col-xs-12 col-md-4">
                                <div class="post-item-inner">
                                    <div class="content-right">
                                        <h3>
                                            <?php echo esc_html($menu_item->post_title); ?>
                                            <span class="price">
                                                <span>
                                                    <?php if (!empty($post_meta['fs_sale_price'][0])){ ?><span class="sale-price"><?php echo esc_html($current_unit['character']) . esc_html($post_meta['fs_sale_price'][0]); ?> </span><?php }?>
                                                    <span class="regular-price" <?php if (!empty($post_meta['fs_sale_price'][0])){ echo 'style="text-decoration: line-through;padding-left: 10px;';}?>"><?php echo esc_html($current_unit['character']) . esc_html($post_meta['fs_regular_price'][0]); ?> </span>
                                                </span>
                                            </span>

                                        </h3>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</div>
