<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $title
 * @var $nav_menu
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Wp_Custommenu
 */
$title = $nav_menu = $el_class = '';
$output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );

$attr['menu_class'] = 'nav-menu menu-main-menu '. $el_class;
$attr['menu'] = $nav_menu;
/* enable mega menu. */
if(class_exists('HeroMenuWalker')){ $attr['walker'] = new HeroMenuWalker(); }

/* main nav. */
echo '<div class="site-navigation">';
    wp_nav_menu( $attr );
echo '</div>';
