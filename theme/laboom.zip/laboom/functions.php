<?php
/**
 * Theme Framework functions and definitions
 *
 * Sets up the theme and provides some helper functions, which are used
 * in the theme as custom template tags. Others are attached to action and
 * filter hooks in WordPress to change core functionality.
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development and
 * http://codex.wordpress.org/Child_Themes), you can override certain functions
 * (those wrapped in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before the parent
 * theme's file, so the child theme functions would be used.
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are instead attached
 * to a filter or action hook.
 *
 * For more information on hooks, actions, and filters, @link http://codex.wordpress.org/Plugin_API
 *
 * @package CMSSuperHeroes
 * @subpackage CMS Themee
 * @since 1.0.0
 */

// Set up the content width value based on the theme's design and stylesheet.
if ( ! isset( $content_width ) )
	$content_width = 625;

/**
 * CMS Theme setup.
 *
 * Sets up theme defaults and registers the various WordPress features that
 * CMS Theme supports.
 *
 * @uses load_theme_textdomain() For translation/localization support.
 * @uses add_editor_style() To add a Visual Editor stylesheet.
 * @uses add_theme_support() To add support for post thumbnails, automatic feed links,
 * 	custom background, and post formats.
 * @uses register_nav_menu() To add support for navigation menus.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @since 1.0.0
 */
function laboom_setup() {

	// load language.
	load_theme_textdomain( 'laboom' , get_template_directory() . '/languages' );

	// Adds title tag
	add_theme_support( "title-tag" );

	// Add woocommerce
	add_theme_support('woocommerce');

	// Adds custom header
	add_theme_support( 'custom-header' );

	// Adds RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );

	// This theme supports a variety of post formats.
	add_theme_support( 'post-formats', array( 'video', 'audio' , 'gallery', 'quote') );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menu( 'primary', esc_html__( 'Primary Menu', 'laboom' ) );
	register_nav_menu( 'pr_menu_left', esc_html__( 'Main Menu Left', 'laboom' ) );
	register_nav_menu( 'pr_menu_right', esc_html__( 'Main Menu Right', 'laboom' ) );
	register_nav_menu( 'pr_menu_hidden_sidebar', esc_html__( 'Menu hidden sidebar', 'laboom' ) );
	register_nav_menu( 'pr_menu_footer', esc_html__( 'Menu Footer', 'laboom' ) );

	/*
	 * This theme supports custom background color and image,
	 * and here we also set up the default background color.
	 */
	add_theme_support( 'custom-background', array('default-color' => 'e6e6e6',) );

	// This theme uses a custom image size for featured images, displayed on "standard" posts.
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 624, 9999 ); // Unlimited height, soft crop
	add_image_size('laboom_blog1140X501',1140, 501, true);
	add_image_size('laboom_team400X400',400, 400, true);
	add_image_size('laboom_team260X350',260, 350, true);
	add_image_size('laboom_blog359X250',359, 250, true);
	add_image_size('laboom_blog553X350',553, 350, true);
	add_image_size('laboom_blog555X400',555, 400, true);
	add_image_size('laboom_blog555X430',555, 430, true);
	add_image_size('laboom_blog555X200',555, 200, true);
	add_image_size('laboom_blog260X200',260, 200, true);
	add_image_size('laboom_blog104X104',104, 104, true);


	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'assets/css/editor-style.css' ) );
}

add_action( 'after_setup_theme', 'laboom_setup' );

/**
 * Enqueue scripts and styles for front-end.
 * @author Fox
 * @since CMS SuperHeroes 1.0
 */
function laboom_front_end_scripts() {

	global $wp_styles, $opt_meta_options;

	/* one page. */
	if(is_page() && isset($opt_meta_options['page_one_page']) && $opt_meta_options['page_one_page']) {
		wp_register_script('jquery-singlePageNav', get_template_directory_uri() . '/assets/js/jquery.singlePageNav.js', array('jquery'), '1.2.0');
		wp_localize_script('jquery-singlePageNav', 'one_page_options', array('filter' => '.is-one-page', 'speed' => $opt_meta_options['page_one_page_speed']));
		wp_enqueue_script('jquery-singlePageNav');
	}

	/* Adds JavaScript Bootstrap. */
	wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '3.3.2');

	/* Add countdown.js */
	wp_enqueue_script('countdown-js', get_template_directory_uri() . '/assets/js/jquery.countdown.js', array('jquery'), '1.0.0', true);
	wp_enqueue_script('countdown-plugin-js', get_template_directory_uri() . '/assets/js/jquery.plugin.js', array('jquery'), '1.0.0', true);

	/* Add main.js */
	wp_enqueue_script('laboom-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true);
    wp_localize_script('laboom-main', 'ajax_data', array(
        'url' => admin_url('admin-ajax.php'),
        'add' => 'new_reservation'
    ));
	/* Add menu.js */
	wp_enqueue_script('laboom-menu', get_template_directory_uri() . '/assets/js/menu.js', array('jquery'), '1.0.0', true);

	wp_enqueue_script('placeholder', get_template_directory_uri() . '/assets/js/placeholders.min.js', array( 'jquery' ), '1.0.0', true);
	/*material icon*/
	wp_enqueue_style('strocke-gap-icon', get_template_directory_uri() . '/assets/css/strocke_gap_icon.css', array(), '1.0.1');
	/*linearicon*/
	wp_enqueue_style('linearicons', get_template_directory_uri() . '/assets/css/linearicons.css', array(), '1.0.1');
	/*elegant_icon*/
	wp_enqueue_style('elegant-icon', get_template_directory_uri() . '/assets/css/elegant_icon.css', array(), '1.0.1');
	/* Magnific Popup */
	wp_enqueue_script('magnific-image', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array( 'jquery' ), '1.0.0', true);
	/*pie chart*/
	wp_enqueue_script('progressCircle', get_template_directory_uri() . '/assets/js/process_cycle.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('vc-pie-custom', get_template_directory_uri() . '/assets/js/vc_pie_custom.js', array( 'jquery' ), '1.0.0', true);
	/* Style Scroll */
	wp_enqueue_script('scroll-bar', get_template_directory_uri() . '/assets/js/enscroll.js', array( 'jquery' ), '1.0.0', true);
	/* Same Height */
	wp_enqueue_script('matchHeight', get_template_directory_uri() . '/assets/js/jquery.matchHeight-min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('sameheight', get_template_directory_uri() . '/assets/js/sameheight.js', array( 'jquery' ), '1.0.0', true);
	/* Slick Carousel*/
	wp_enqueue_script('slick-js', get_template_directory_uri() . '/assets/js/slick.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('parallax-js', get_template_directory_uri() . '/assets/js/parallax.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('modernizr', get_template_directory_uri() . '/assets/js/modernizr.custom.min.js', array( 'jquery' ), '1.0.0', true);



	wp_enqueue_style('laboom-google-fonts', laboom_fonts_url());
	/* Comment */
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	/** ----------------------------------------------------------------------------------- */

	/* Loads Bootstrap stylesheet. */
	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '3.3.2');

	/* Loads Bootstrap stylesheet. */
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), '4.7.0');

	/* Loads our main stylesheet. */
	wp_enqueue_style( 'laboom-style', get_stylesheet_uri(), array( 'bootstrap' ));

	/* Loads the Internet Explorer specific stylesheet. */
	wp_enqueue_style( 'laboom-ie', get_template_directory_uri() . '/assets/css/ie.css', array( 'laboom-style' ), '20121010' );

	/* Loads Font Ionicons. */
	wp_enqueue_style('font-ionicons', get_template_directory_uri() . '/assets/css/ionicons.css', array(), '2.0.1');

	/* Loads Pe Icon. */
	wp_enqueue_style('pe-icon', get_template_directory_uri() . '/assets/css/pe-icon-7-stroke.css', array(), '1.0.1');
	/* Olw Carousel */
	wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.css', array(), '1.0.1');
	wp_enqueue_style('owl-theme', get_template_directory_uri() . '/assets/css/owl.theme.css', array(), '1.0.1');
	/* Popup Images Gallery */
	wp_enqueue_style('magnific-popup', get_template_directory_uri() . '/assets/css/magnific-popup.css', array(), '1.0.1');
	/* Slick Carousel*/
	wp_enqueue_style('slick', get_template_directory_uri() . '/assets/css/slick.css', array(), '1.0.1');
	wp_enqueue_style('slick-theme', get_template_directory_uri() . '/assets/css/slick-theme.css', array(), '1.0.1');
	/*countdown*/
	wp_enqueue_style('css-countdown', get_template_directory_uri() . '/assets/css/jquery.countdown.css', array(), '1.0.1');

	/* ie */
	$wp_styles->add_data( 'laboom-ie', 'conditional', 'lt IE 9' );

	/* Load static css*/
	wp_enqueue_style('laboom-static', get_template_directory_uri() . '/assets/css/static.css', array( 'laboom-style' ), '1.0.0');
}

add_action( 'wp_enqueue_scripts', 'laboom_front_end_scripts' );

/**
 * load admin scripts.
 *
 * @author FOX
 */
function laboom_admin_scripts(){

	/* Loads Bootstrap stylesheet. */
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), '4.3.0');

	$screen = get_current_screen();

	/* load js for edit post. */
	if($screen->post_type == 'post'){
		/* post format select. */
		wp_enqueue_script('post-format', get_template_directory_uri() . '/assets/js/post-format.js', array(), '1.0.0', true);
	}
}

add_action( 'admin_enqueue_scripts', 'laboom_admin_scripts' );

/**
 * Register sidebars.
 *
 * Registers our main widget area and the front page widget areas.
 *
 * @since Fox
 */
function laboom_widgets_init() {

	register_sidebar( array(
		'name' => esc_html__( 'Main Sidebar', 'laboom' ),
		'id' => 'sidebar-1',
		'description' => esc_html__( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'laboom' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h3 class="wg-title">',
		'after_title' => '</h3>',
	) );
	register_sidebar( array(
		'name' => esc_html__( 'Header Top Right ', 'laboom' ),
		'id' => 'header-right-top',
		'description' => esc_html__( 'Appears on header top right', 'laboom' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '',
		'after_title' => '',
	) );

	register_sidebar( array(
		'name' => esc_html__( 'Sidebar Shop', 'laboom' ),
		'id' => 'woocommerce-widget-area',
		'before_widget' => '<aside id="%1$s" class="widget %2$s"><div class="wg-wrap"><div class="wg-wrap-inner">',
		'after_widget' => '</div></div></aside>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	register_sidebar( array(
		'name' => esc_html__( 'Shop Cart', 'laboom' ),
		'id' => 'shop-cart',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	register_sidebar(array(
		'name' => esc_html__('Footer Top 1', 'laboom'),
		'id' => 'sidebar-footer-top-1',
		'description' => esc_html__('Appears on footer layout 4', 'laboom'),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h5 class="wg-title">',
		'after_title' => '</h5>',
	));
	register_sidebar(array(
		'name' => esc_html__('Footer Top 2', 'laboom'),
		'id' => 'sidebar-footer-top-2',
		'description' => esc_html__('Appears on footer layout 4', 'laboom'),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h5 class="wg-title">',
		'after_title' => '</h5>',
	));
	register_sidebar(array(
		'name' => esc_html__('Footer Top 1', 'laboom'),
		'id' => 'sidebar-footer-top-3',
		'description' => esc_html__('Appears on footer layout 5', 'laboom'),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h5 class="wg-title">',
		'after_title' => '</h5>',
	));
	register_sidebar(array(
		'name' => esc_html__('Footer Top 2', 'laboom'),
		'id' => 'sidebar-footer-top-4',
		'description' => esc_html__('Appears on footer layout 5', 'laboom'),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h5 class="wg-title">',
		'after_title' => '</h5>',
	));
	register_sidebar(array(
		'name' => esc_html__('Footer Top 3', 'laboom'),
		'id' => 'sidebar-footer-top-5',
		'description' => esc_html__('Appears on footer layout 5', 'laboom'),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h5 class="wg-title">',
		'after_title' => '</h5>',
	));
	register_sidebar(array(
		'name' => esc_html__('Footer Top 4', 'laboom'),
		'id' => 'sidebar-footer-top-6',
		'description' => esc_html__('Appears on footer layout 5', 'laboom'),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h5 class="wg-title">',
		'after_title' => '</h5>',
	));
}

add_action( 'widgets_init', 'laboom_widgets_init' );
/**
 * Custom params & remove VC Elements.
 *
 * @author FOX
 */
add_action('vc_after_init', 'laboom_vc_after_init');

function laboom_vc_after_init(){

	require( get_template_directory() . '/vc_params/vc_rows.php' );
	require( get_template_directory() . '/vc_params/vc_column.php' );
	require( get_template_directory() . '/vc_params/vc_column.php' );
	require( get_template_directory() . '/vc_params/vc_pie.php' );
	require( get_template_directory() . '/vc_params/vc_tta_section.php' );
	require( get_template_directory() . '/vc_params/cms_custom_pagram_vc.php' );

	vc_remove_element( "vc_button" );
	vc_remove_element( "vc_button2" );
	vc_remove_element( "vc_cta_button" );
	vc_remove_element( "vc_cta_button2" );
	vc_remove_element( "vc_cta" );
}
/**
 * Add new elements for VC
 *
 * @author FOX
 */
add_action('vc_before_init', 'laboom_vc_elements');

function laboom_vc_elements(){

	if(!class_exists('CmsShortCode'))
		return ;

    require( get_template_directory() . '/inc/elements/cms_carousel/cms_carousel.php' );

	require( get_template_directory() . '/inc/elements/button/cms_button.php' );
	require( get_template_directory() . '/inc/elements/heading/cms_heading.php' );
	require( get_template_directory() . '/inc/elements/social/cms_social.php' );
	require( get_template_directory() . '/inc/elements/process/cms_process.php' );
	require( get_template_directory() . '/inc/elements/googlemap/cms_googlemap.php' );
	require( get_template_directory() . '/inc/elements/restaurant_menu/restaurant_menu.php' );
	require( get_template_directory() . '/inc/elements/reservation/cms_reservation.php' );
	require( get_template_directory() . '/inc/elements/restaurant_grid_menu/restaurant_grid_menu.php' );
	require( get_template_directory() . '/vc_params/vc_custom_heading.php' );
}


/**
 * Display navigation to next/previous comments when applicable.
 *
 * @since 1.0.0
 */
function laboom_comment_nav() {
	// Are there comments to navigate through?
	if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<nav class="navigation comment-navigation" role="navigation">
			<h2 class="screen-reader-text"><?php esc_html_e( 'Comment navigation', 'laboom' ); ?></h2>
			<div class="nav-links">
				<?php
				if ( $prev_link = get_previous_comments_link( esc_html__( 'Older Comments', 'laboom' ) ) ) :
					printf( '<div class="nav-previous">%s</div>', $prev_link );
				endif;

				if ( $next_link = get_next_comments_link( esc_html__( 'Newer Comments', 'laboom' ) ) ) :
					printf( '<div class="nav-next">%s</div>', $next_link );
				endif;
				?>
			</div><!-- .nav-links -->
		</nav><!-- .comment-navigation -->
		<?php
	endif;
}

/**
 * Display navigation to next/previous set of posts when applicable.
 *
 * @since 1.0.0
 */
function laboom_paging_nav() {
	// Don't print empty markup if there's only one page.
	if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
		return;
	}

	$paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$query_args   = array();
	$url_parts    = explode( '?', $pagenum_link );

	if ( isset( $url_parts[1] ) ) {
		wp_parse_str( $url_parts[1], $query_args );
	}

	$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
	$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

	// Set up paginated links.
	$links = paginate_links( array(
		'base'     => $pagenum_link,
		'total'    => $GLOBALS['wp_query']->max_num_pages,
		'current'  => $paged,
		'mid_size' => 1,
		'add_args' => array_map( 'urlencode', $query_args ),
		'prev_text' => '<i class="lnr lnr-arrow-left"></i> <span>'.esc_html__('Prev Page','laboom').'</span>',
		'next_text' => '<span>'.esc_html__('Next Page','laboom').'</span><i class="lnr lnr-arrow-right"></i>',
	) );

	if ( $links ) :

		?>
		<nav class="navigation paging-navigation clearfix" role="navigation">
			<div class="pagination loop-pagination">
				<?php echo wp_kses_post($links); ?>
			</div><!-- .pagination -->
		</nav><!-- .navigation -->
		<?php
	endif;
}

/**
 * Display navigation to next/previous post when applicable.
 *
 * @since 1.0.0
 */
function laboom_post_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<nav class="navigation post-navigation" role="navigation">
		<div class="nav-links clearfix">
			<?php
			$prev_post = get_previous_post();
			if (!empty( $prev_post )): ?>
				<div class="prev">
					<a href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>"><i class="lnr lnr-arrow-left"></i> <span><?php  echo substr(get_the_title( $prev_post->ID ), 0,25); ?></span> </a>
				</div>
			<?php endif; ?>
			<?php
			$next_post = get_next_post();
			if ( is_a( $next_post , 'WP_Post' ) ) { ?>
				<div class="next">
					<a href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>"><span><?php  echo substr(get_the_title( $next_post->ID ), 0,25); ?></span> <i class="lnr lnr-arrow-right"></i></a>
				</div>
			<?php } ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
function laboom_portfolio_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<nav class="navigation post-navigation">

		<div class="nav-links clearfix">
			<?php
			$prev_post = get_previous_post();
			if (!empty( $prev_post )): ?>
				<div class="prev">
					<a class="portfolio-nav" href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>">
						<i class="fa fa-angle-left" aria-hidden="true"></i>
					</a>
					<div class="content-right">
						<a class="post-prev left" href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>"><?php esc_html_e('Prev', 'laboom'); ?></a>
						<h3><a href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>">

								<?php echo get_the_title( $prev_post->ID ); ?> </a>
						</h3>

					</div>

				</div>
			<?php endif; ?>
			<a class="all-portfolio" href="<?php echo esc_url(home_url('/')); ?>?post_type=portfolio"><i class="fa fa-th-large" aria-hidden="true"></i></a>
			<?php
			$next_post = get_next_post();
			if ( is_a( $next_post , 'WP_Post' ) ) { ?>
				<div class="next">
					<div class="content-right">
						<a class="post-next right" href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>"><?php esc_html_e('Next Post', 'laboom');?></a>
						<h3><a href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>">
								<?php echo get_the_title( $next_post->ID ); ?> </a>
						</h3>
					</div>
					<a class="portfolio-nav" href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>

				</div>
			<?php } ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
function laboom_product_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<nav class="navigation post-navigation">

		<div class="nav-links clearfix">
			<?php
			$prev_post = get_previous_post();
			if (!empty( $prev_post )): ?>
				<div class="prev">
					<a class="product-nav" href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>">
						<i class="fa fa-long-arrow-left" aria-hidden="true"></i>
					</a>
				</div>
			<?php endif; ?>
			<?php
			$next_post = get_next_post();
			if ( is_a( $next_post , 'WP_Post' ) ) { ?>
				<div class="next">
					<a class="product-nav" href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>">
						<i class="fa fa-long-arrow-right" aria-hidden="true"></i>
					</a>

				</div>
			<?php } ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
/*Add Custom Comment*/
function laboom_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	extract($args, EXTR_SKIP);

	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'li';
		$add_below = 'div-comment';
	}
	?>

	<<?php echo esc_attr($tag) ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
	<?php if ( 'div' != $args['style'] ) : ?>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-body clearfix">
	<?php endif; ?>
	<div class="comment-author-image">
		<?php echo get_avatar( $comment, 70 ); ?>

	</div>
	<?php if ( $comment->comment_approved == '0' ) : ?>
		<em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.' , 'laboom'); ?></em>
	<?php endif; ?>
	<div class="comment-main  pull-right">
		<div class="comment-meta commentmetadata">
			<h4 class="comment-author ft-helveticaneue-b"><?php echo get_comment_author_link(); ?></h4>
			<span class="comment-date">
				<?php comment_date('F d'); ?>
			  </span>
			<div class="reply">
				<?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
			</div>
		</div>
		<div class="comment-content">
			<?php comment_text(); ?>
		</div>
	</div>
	<?php if ( 'div' != $args['style'] ) : ?>
		</div>
	<?php endif; ?>
	<?php
}

/* core functions. */
require_once( get_template_directory() . '/inc/functions.php' );

/**
 * theme actions.
 */

/* add footer back to top. */
add_action('wp_footer', 'laboom_footer_back_to_top');


add_filter('cms-shorcode-list', 'laboom_shortcodes');
/**
 * support shortcodes
 * @return array
 */
function laboom_shortcodes(){
	return array(
		//'cms_carousel',
		'cms_grid',
		'cms_fancybox_single',
		'cms_counter_single',
		'cms_progressbar',
	);
}
/**
 * Loading.
 *
 * @author Fox
 */
function laboom_get_page_loading() {
	global $opt_theme_options;
	if($opt_theme_options['general_page_loading'] == '1'){
		echo '<div id="cms-loadding"><div class="cms-loader"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>';
	}
}
/**
 * Add field subtitle to post.
 *
 * @since 1.0.0
 */
function laboom_add_subtitle_field(){
	global $post, $cms_meta;

	/* get current_screen. */
	$screen = get_current_screen();

	/* show field in post. */
	if(in_array($screen->id, array('post'))){

		/* get value. */
		$value = get_post_meta($post->ID, 'post_subtitle', true);

		/* html. */
		echo '<div class="subtitle"><input type="text" name="post_subtitle" value="'.esc_attr($value).'" id="subtitle" placeholder = "'.esc_html__('Subtitle', 'laboom').'" style="width: 100%;margin-top: 4px;"></div>';
	}
}

add_action( 'edit_form_after_title', 'laboom_add_subtitle_field' );

/**
 * Save custom theme meta.
 *
 * @since 1.0.0
 */
function laboom_save_meta_boxes($post_id) {

	if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}
	/* update field subtitle */
	if(isset($_POST['post_subtitle'])){
		update_post_meta($post_id, 'post_subtitle', $_POST['post_subtitle']);
	}
}

add_action('save_post', 'laboom_save_meta_boxes');
/*
 * Limit Words
 */
if (!function_exists('laboom_string_limit_words')) {
	function laboom_string_limit_words($string, $word_limit) {
		$words = explode(' ', $string, ($word_limit + 1));
		if (count($words) > $word_limit) {
			array_pop($words);
		}
		return implode(' ', $words)."";
	}
}
/*woocomerce*/
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation', 10 );
remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
add_action( 'woocommerce_single_variation', 'woocommerce_single_variation', 20 );
add_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 10 );

if(class_exists('Woocommerce')){
	require( get_template_directory() . '/woocommerce/woocommerce-hook.php' );
}
/**
 * Ajax update cart total number
 * */
add_filter( 'woocommerce_add_to_cart_fragments', 'laboom_woocommerce_header_add_to_cart_fragment' );
function laboom_woocommerce_header_add_to_cart_fragment( $fragments ) {
	ob_start();
	?>
	<span class="couter_items"><?php echo sprintf (_n( '%d', '%d', WC()->cart->cart_contents_count, "laboom" ), WC()->cart->cart_contents_count ); ?></span>
	<?php

	$fragments['span.couter_items'] = ob_get_clean();

	return $fragments;
}
/* Woo commerce function */
if(class_exists('WooCommerce')){
	/**
	 * Get current users preference
	 * @return int
	 */
	function laboom_products_per_page(){

		global $opt_theme_options, $woocommerce;

		$default = $opt_theme_options['product_per_page'];
		$count = $default;
		$options = laboom_products_per_page_options();

		// capture form data and store in session
		if(isset($_POST['wp-laboom-woocommerce-products-per-page'])){

			// set products per page from dropdown
			$products_max = intval($_POST['wp-laboom-woocommerce-products-per-page']);
			if($products_max != 0 && $products_max >= -1){

				if(is_user_logged_in()){

					$user_id = get_current_user_id();
					$limit = get_user_meta( $user_id, '_product_per_page', true );

					if(!$limit){
						add_user_meta( $user_id, '_product_per_page', $products_max);
					}else{
						update_user_meta( $user_id, '_product_per_page', $products_max, $limit);
					}
				}

				$woocommerce->session->wp_laboom_product_per_page = $products_max;
				return $products_max;
			}
		}

		// load product limit from user meta
		if(is_user_logged_in() && !isset($woocommerce->session->wp_laboom_product_per_page)){

			$user_id = get_current_user_id();
			$limit = get_user_meta( $user_id, '_product_per_page', true );

			if(array_key_exists($limit, $options)){
				$woocommerce->session->wp_laboom_product_per_page = $limit;
				return $limit;
			}
		}

		// load product limit from session
		if(isset($woocommerce->session->wp_laboom_product_per_page)){

			// set products per page from woo session
			$products_max = intval($woocommerce->session->wp_laboom_product_per_page);
			if($products_max != 0 && $products_max >= -1){
				return $products_max;
			}
		}

		return $count;
	}
	add_filter('loop_shop_per_page','laboom_products_per_page');

	/**
	 * Fetch list of avaliable options
	 * @return array
	 */
	function laboom_products_per_page_options(){
		$cms_products_perpage = array(
			'12' => esc_html__('12 Products / page', 'laboom'),
			'16' => esc_html__('16 Products / page', 'laboom'),
			'20' => esc_html__('20 Products / page', 'laboom')
		);
		$options = apply_filters( 'laboom_products_per_page', $cms_products_perpage);
		return $options;
	}

	/**
	 * Display dropdown form to change amount of products displayed
	 * @return void
	 */
	function laboom_woocommerce_products_per_page(){
		global $wp_query;
		$paged    = max( 1, $wp_query->get( 'paged' ) );
		$total    = $wp_query->found_posts;
		$options = laboom_products_per_page_options();
		$current_value = laboom_products_per_page();
		?>
		<form action="" method="POST" class="woocommerce-products-per-page">
			<label><select name="wp-laboom-woocommerce-products-per-page"  class="filter-products-per-page" onchange="this.form.submit()">
					<?php foreach($options as $value => $name):
						if ($value == $current_value){
							$label = $name;
						} else {
							$label = $name;
						}
						?>
						<?php if(ceil($total/$value) >= $paged): ?>
						<option value="<?php echo esc_attr($value); ?>" <?php selected($value, $current_value); ?>><?php echo esc_html($label); ?></option>
					<?php endif; ?>
					<?php endforeach; ?>
				</select></label>
		</form>
		<?php
	}
}
remove_action('tgmpa_register', 'newsletter_register_required_plugins');

if ( ! function_exists( 'laboom_fonts_url' ) ) :
	/**
	 * Register Google fonts for coupon.
	 *
	 * Create your own  laboom_fonts_url() function to override in a child theme.
	 *
	 * @since  laboom 1.1
	 *
	 * @return string Google fonts URL for the theme.
	 */
	function laboom_fonts_url()
	{
		$fonts_url = '';
		$fonts     = array();
		$subsets   = 'latin,latin-ext';

		// / translators: If there are characters in your language that are not supported by Molle, translate this to 'off'. Do not translate into your own language. /
		if ( 'off' !== _x( 'on', 'Quicksand font: on or off', 'laboom' ) )
		{
			$fonts[] = 'Quicksand:400,700';
		}
		// / translators: If there are characters in your language that are not supported by Roboto, translate this to 'off'. Do not translate into your own language. /
		if ( 'off' !== _x( 'on', 'Source Sans Pro font: on or off', 'laboom' ) )
		{
			$fonts[] = 'Source Sans Pro:400,600';
		}

		if ( $fonts ) {
			$fonts_url = add_query_arg( array(
				'family' => urlencode( implode( '|', $fonts ) ),
				'subset' => urlencode( $subsets ),
			), 'https://fonts.googleapis.com/css' );
		}

		return $fonts_url;
	}
endif;

function laboom_get_limit_str($str,$start,$limit,$add_tag = '...')
{
    $str = trim($str);
    if(strlen($str) <= $limit)
        return $str;
    return substr(wp_strip_all_tags($str),$start,$limit).$add_tag;
}
function laboom_shortcode_loading_element()
{
    ?>
     <div class="grid-row-loading">
		  <div class="col"> 
		    <ul class="loading">
		      <li></li>
		      <li></li>
		      <li></li>
		    </ul>
		    
		</div>
	</div>
    <?php
}
function laboom_get_post_from_query_seperate_data($data)
{
    $posts = array();
    if(is_array($data) && !empty($data['body'])  && is_array($data['body']))
    {
        $posts_id_added = array();
        foreach ($data['body'] as $cat_data)
        {
            if(!empty( $cat_data['posts']) && is_array( $cat_data['posts']))
            {
                foreach ( $cat_data['posts'] as $cat_post)
                {
                    if(!in_array($cat_post->ID,$posts_id_added))
                    {
                        $posts[] = $cat_post;
                        $posts_id_added[]= $cat_post->ID;;
                    }
                }
            }
        }
    }
    return $posts;
}
function laboom_cms_menu_get_posts_in_all_cat_filter_view($menu_limit,$data)
{
    $posts =  laboom_get_post_from_query_seperate_data($data);
    if(count($posts) <= $menu_limit)
    {
        $posts_in_all_filter_view = array(
            'ids'=>array(),
            'posts'=>$posts
        );
        foreach ($posts as $post)
            $posts_in_all_filter_view['ids'][] = $post->ID;
    }
    else
    {
        $posts_in_all_filter_view = array(
            'ids'=> array(),
            'posts'=>array()
        );
        for ($i = 0;$i<$menu_limit;$i++)
        {
            if(is_array($data) && !empty($data['body'])  && is_array($data['body']))
            {
                foreach ($data['body'] as $cat_data)
                {
                    if(!empty( $cat_data['posts']) && is_array( $cat_data['posts']))
                    {
                        foreach ( $cat_data['posts'] as $cat_post)
                        {
                            if(!in_array($cat_post->ID,$posts_in_all_filter_view['ids']))
                            {
                                $posts_in_all_filter_view['posts'][] = $cat_post;
                                $posts_in_all_filter_view['ids'][]= $cat_post->ID;
                                break;
                            }
                        }
                    }
                    if(count($posts_in_all_filter_view['ids']) >= $menu_limit)
                        break;
                }
            }
            if(count($posts_in_all_filter_view['ids']) >= $menu_limit)
                break;
        }
    }
    return $posts_in_all_filter_view;
}
/**
 * End Demo Data
 */