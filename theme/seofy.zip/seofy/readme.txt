Version 1.2.1 - 31 January 2019
- Added RTL Support
- Fixed issue with links after demo import

Version 1.2 - 2 January 2019
- Added New Page
- Fixed issue with mobile menu
- Improved the design of the "Demo Item" module
- Minor fixes

Version 1.0.4 - 2 January 2019
- Fixed color of highlighted text
- Fixed minor issue with the demo import
- Fixed issue with a background image at video popup module
- Added custom link for portfolio items

Version 1.0.3 - 9 December 2018
- Fixed issues with pricing table module
- Added option for footer's mountain color
- Updated Header builder
- Updated plugins

Version 1.0
- Initial release